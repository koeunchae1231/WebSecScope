"""Local evidence comparison. No product or historical evaluation files are written."""
import base64
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import http.client
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
HOLD = ROOT/'docs/validation/final_holdout'
RUN = OUT/'final_run'
sys.path.insert(0, str(ROOT))
sys.path.insert(1, str(HOLD))

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, value):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
def now(): return datetime.now(timezone.utc).isoformat()

def register():
    cases = read(HOLD/'cases.json')
    selected = {f'FH-HDR-{i:02}' for i in (1,2,5,7,8,9)}
    selected |= {f'FH-CSP-{i:02}' for i in range(1,11)}
    selected |= {f'FH-COOKIE-{i:02}' for i in range(2,11)}
    selected.add('FH-BODY-08')
    rows=[]
    for c in cases:
        ident=c['id']; group='primary' if ident in selected else 'excluded'
        if ident=='FH-COOKIE-05': group='policy_supplement'
        if ident in selected:
            if 'CSP' in ident: ids=['10038','10055']; refs=['10055-4','10055-5','10055-7','10055-9','10055-10','10055-13']
            elif 'COOKIE' in ident: ids=['10010','10054']; refs=['10054-1','10054-3']
            elif ident in ('FH-HDR-02','FH-HDR-07','FH-HDR-09'): ids=['10020']; refs=[]
            else: ids=['10021']; refs=[]
            reason='Shared response configuration check; unknown truth retained outside confusion matrix.'
        else:
            ids=[]; refs=[]
            reason=('HTTPS required by ZAP HSTS/Secure rule; fixture is HTTP' if ident.startswith('FH-HDR') or ident=='FH-COOKIE-01' else
                    'Service policy/active multi-request semantics or resource/body interpretation not equivalent to installed passive rules')
        rows.append(dict(id=ident,group=group,truth=c['truth'],scenario=c['scenario'],selector=c['selector'],zap_plugin_ids=ids,zap_alert_refs=refs,reason=reason))
    protected={str(p.relative_to(ROOT)):sha(p) for folder in ('websecscope','tests','tools/validation') for p in (ROOT/folder).rglob('*.py')}
    protected.update({str(p.relative_to(ROOT)):sha(p) for p in HOLD.rglob('*') if p.is_file() and '__pycache__' not in p.parts})
    save(RUN/'protected_hashes.json',protected)
    save(RUN/'preregistration.json',dict(registered_at=now(),cases=rows,primary_cases=25,policy_supplement=1,
        source_sha256=sha(HOLD/'cases.json'),runner_sha256=sha(Path(__file__)),modes=['none','headers'],repeats=1,
        mapping='Case-level, duplicate findings/alerts collapse. WSS frozen prefix selector: FAIL > WARNING > PASS; missing=ERROR. ZAP mapped alert on root URL only (cookies root or /api/login), riskcode>=1 => FAIL, else completed imported evidence => NO_ALERT. NO_ALERT is operational negative, not proof of safety. Cookie SameSite=None 10054-2 is advice and excluded. CSP 10055 refs 4/5/7/9/10/13 only; 10038 missing/report-only included; other CSP advice excluded. Other selected plugin IDs all positive risk alerts included.',
        truth='Original unchanged ground truth. vulnerable FAIL=TP, PASS/NO_ALERT=FN; safe FAIL=FP, PASS/NO_ALERT=TN. WARNING=ABSTAIN. Unknown excluded, outputs reported. Error excluded and reported.',
        metrics='Primary known cases only. precision TP/(TP+FP), conditional recall TP/(TP+FN), coverage (TP+FP+FN+TN)/known; vulnerable detection TP/all vulnerable also reported. Zero denominator null. Supplemental preference-cookie policy case separate.',
        evidence='Capture HTTPConnection responses actually consumed by WSS; duplicate response fields and base64 body in HAR. Import into ZAP importHar sendRequests=false after fixture closes. Require GET bytes=Content-Length and imported message count=HAR count, queue empty and no running scan. No spider/active scan. No fake HTTPS.',
        timing='WSS run_scan wall time includes HTTP acquisition; ZAP import+queue+running wait wall time excludes acquisition and startup, includes polling overhead. Not a speed ranking. ZAP persistent JVM per batch; per-trial sampled RSS and batch process peak; WSS fresh process including fixture/imports. Single repetition, no inferential significance.',
        policy='none is equal-input primary; headers passes existing P1/header requirements only to WSS, separately reported. ZAP has no equivalent service contract input. Policy supplement excluded from primary.',
        sources=['https://www.zaproxy.org/docs/desktop/addons/import-export/','https://www.zaproxy.org/docs/api/'],
        local_rule_sources={p.name:sha(p) for p in (OUT/'rule_sources').glob('*.java')}))
    print('Preregistered 25 primary + 1 policy supplemental; no results accessed.')

def api(port, component, kind, name, **params):
    url=f'http://127.0.0.1:{port}/JSON/{component}/{kind}/{name}/?'+urllib.parse.urlencode(params)
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(url,timeout=40) as r: value=json.load(r)
    if 'code' in value: raise RuntimeError(value)
    return value

def start():
    runtime=ROOT/'.tool-comparison-runtime'
    with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
    home=RUN/'zap-home'; home.mkdir()
    command=['C:/Program Files/Java/jdk-24/bin/java.exe','-Xmx768m','-Djava.awt.headless=true','-jar',str(runtime/'ZAP_2.17.0/zap-2.17.0.jar'),'-daemon','-silent','-dir',str(home),'-host','127.0.0.1','-port',str(port),'-config','api.disablekey=true','-config','api.addrs.addr.name=127.0.0.1','-config','api.addrs.addr.regex=false','-config','connection.timeoutInSecs=1']
    began=time.perf_counter()
    with (RUN/'zap_stdout.log').open('wb') as log:
        proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    for _ in range(120):
        if proc.poll() is not None: raise RuntimeError('ZAP exited')
        try: version=api(port,'core','view','version'); break
        except Exception: time.sleep(1)
    else: raise TimeoutError('ZAP startup')
    api(port,'core','action','setMode',mode='safe')
    save(RUN/'environment.json',dict(at=now(),pid=proc.pid,port=port,command=command,version=version,startup_seconds=time.perf_counter()-began,python=sys.version,archive_sha256=sha(runtime/'ZAP_2.17.0_Crossplatform.zip')))
    for comp, name in [('pscan','scanners'),('autoupdate','installedAddons')]: save(RUN/(name+'.json'),api(port,comp,'view',name))
    print('ZAP ready',port,flush=True)

def memory(pid):
    import ctypes
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
    k=ctypes.WinDLL('kernel32',use_last_error=True); p=ctypes.WinDLL('psapi',use_last_error=True)
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]; k.OpenProcess.restype=wintypes.HANDLE
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    p.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
    handle=k.OpenProcess(0x410,False,pid)
    if not handle: return None
    try:
        c=Counters(); c.cb=ctypes.sizeof(c)
        if not p.GetProcessMemoryInfo(handle,ctypes.byref(c),c.cb): return None
        return dict(current_bytes=c.WorkingSetSize,peak_bytes=c.PeakWorkingSetSize)
    finally: k.CloseHandle(handle)

def worker(ident,mode):
    from fixture import start as fixture_start, stop
    from websecscope.scanner import orchestrator
    from websecscope.policy import ScanPolicy
    c=next(c for c in read(HOLD/'cases.json') if c['id']==ident)
    service,thread=fixture_start(c['fixture']); target=f'http://127.0.0.1:{service.server_port}/'
    entries=[]; denied=[]
    original_response=http.client.HTTPConnection.getresponse
    original_put=http.client.HTTPConnection.putrequest
    original_connect=socket.socket.connect
    def guarded(sock,address):
        if address[0] not in ('127.0.0.1','localhost','::1'): denied.append(str(address)); raise OSError('External connection forbidden')
        return original_connect(sock,address)
    def put(conn,method,url,*args,**kwargs):
        conn._comparison_method=method; conn._comparison_path=url
        return original_put(conn,method,url,*args,**kwargs)
    def response(conn,*args,**kwargs):
        r=original_response(conn,*args,**kwargs)
        entry=dict(startedDateTime=now(),time=0,request=dict(method=conn._comparison_method,url=f'http://{conn.host}:{conn.port}'+conn._comparison_path,httpVersion='HTTP/1.1',headers=[],queryString=[],cookies=[],headersSize=-1,bodySize=0),
            response=dict(status=r.status,statusText=r.reason,httpVersion='HTTP/1.0',headers=[dict(name=k,value=v) for k,v in r.getheaders()],cookies=[],content=dict(size=0,mimeType=r.getheader('Content-Type',''),text='',encoding='base64'),redirectURL=r.getheader('Location',''),headersSize=-1,bodySize=0),cache={},timings=dict(send=0,wait=0,receive=0))
        # Capture actual outbound request headers from fixture events, after scan.
        entries.append(entry); chunks=[]; original_read=r.read
        def captured(*a,**kw):
            data=original_read(*a,**kw); chunks.append(data); body=b''.join(chunks)
            entry['response']['content'].update(size=len(body),text=base64.b64encode(body).decode())
            entry['response']['bodySize']=len(body)
            return data
        original_read1=r.read1
        def captured1(*a,**kw):
            data=original_read1(*a,**kw); chunks.append(data); body=b''.join(chunks)
            entry['response']['content'].update(size=len(body),text=base64.b64encode(body).decode())
            entry['response']['bodySize']=len(body)
            return data
        r.read=captured
        r.read1=captured1
        return r
    policy_data=None; policy=None
    if mode=='headers':
        policy_data=read(HOLD/'policies'/f'{ident}-headers.json'); policy_data['target_origin']=target
        policy=ScanPolicy(policy_data,target)
    before=memory(os.getpid()); began=time.perf_counter(); error=None; scan=None
    try:
        with ExitStack() as stack:
            stack.enter_context(patch.object(socket.socket,'connect',guarded))
            stack.enter_context(patch.object(http.client.HTTPConnection,'putrequest',put))
            stack.enter_context(patch.object(http.client.HTTPConnection,'getresponse',response))
            scan=orchestrator.run_scan(target,include_linux=False,include_docker=False,include_service_detect=False,include_cve=False,**({'policy':policy} if policy else {}))
    except Exception as e: error=repr(e)
    seconds=time.perf_counter()-began; after=memory(os.getpid()); stop(service,thread)
    assert not denied,denied
    assert len(entries)==len(service.events),(len(entries),len(service.events))
    for entry,event in zip(entries,service.events):
        assert entry['request']['method']==event['method']
        assert urllib.parse.urlsplit(entry['request']['url']).path==urllib.parse.urlsplit(event['path']).path
        entry['request']['headers']=[dict(name=k,value=v) for k,v in event['request_headers']]
        if entry['request']['method']!='HEAD':
            length=next(int(h['value']) for h in entry['response']['headers'] if h['name'].lower()=='content-length')
            assert entry['response']['content']['size']==length,(ident,entry['request']['url'])
    chosen=[f.to_dict('en') for f in scan.findings if any(f.check_id.startswith(p) for p in c['selector'])] if scan else []
    status='ERROR' if error or not chosen else 'FAIL' if any(f['status']=='FAIL' for f in chosen) else 'WARNING' if any(f['status']=='WARNING' for f in chosen) else 'PASS'
    save(RUN/'har'/f'{ident}-{mode}.har',dict(log=dict(version='1.2',creator=dict(name='WebSecScope actual HTTP capture',version='1'),entries=entries)))
    save(RUN/'wss'/f'{ident}-{mode}.json',dict(case_id=ident,mode=mode,target=target,truth=c['truth'],status=status,error=error,seconds=seconds,rss_before=before,rss_after=after,http_requests=len(service.events),http_events=service.events,selected=chosen,scan=scan.to_dict('en') if scan else None,policy=policy_data,denied_connections=denied))

def verify():
    manifest=read(RUN/'protected_hashes.json')
    changes=[rel for rel,digest in manifest.items() if sha(ROOT/rel)!=digest]
    assert not changes, changes
    return dict(checked=len(manifest),changed=changes,at=now())

def run():
    verify(); reg=read(RUN/'preregistration.json'); env=read(RUN/'environment.json'); port=env['port']
    assert sha(Path(__file__))==read(RUN/'instrumentation_amendment_2.json')['runner_sha256']
    enabled={s['id'] for s in read(RUN/'scanners.json')['scanners'] if s['enabled']=='true'}
    assert {'10010','10020','10021','10038','10054','10055'}<=enabled
    for row in reg['cases']:
        if row['group']=='excluded': continue
        for mode in reg['modes']:
            ident=row['id']; stem=f'{ident}-{mode}'
            proc=subprocess.run([sys.executable,str(Path(__file__)),'worker',ident,mode],cwd=ROOT,capture_output=True,text=True,timeout=90)
            if proc.returncode: raise RuntimeError(proc.stdout+proc.stderr)
            wss=read(RUN/'wss'/f'{stem}.json'); har=RUN/'har'/f'{stem}.har'
            before_count=int(api(port,'core','view','numberOfMessages')['numberOfMessages'])
            before=memory(env['pid']); began=time.perf_counter()
            imported=api(port,'exim','action','importHar',filePath=str(har),sendRequests='false')
            polls=[]
            for _ in range(600):
                queue=api(port,'pscan','view','recordsToScan')
                running=api(port,'pscan','view','currentTasks')
                polls.append(dict(queue=queue,running=running))
                if int(queue['recordsToScan'])==0 and not running.get('currentTasks'): break
                time.sleep(.05)
            else: raise TimeoutError(stem)
            seconds=time.perf_counter()-began; after=memory(env['pid'])
            after_count=int(api(port,'core','view','numberOfMessages')['numberOfMessages'])
            messages=api(port,'core','view','messages',baseurl=wss['target'],start=0,count=10000)['messages']
            real=[m for m in messages if m['type']=='15']
            entries=read(har)['log']['entries']; expected=len(entries)
            assert len(real)==expected,(stem,len(real),expected)
            for entry,message in zip(entries,real):
                assert message['requestHeader'].splitlines()[0].split()[:2]==[entry['request']['method'],entry['request']['url']]
                assert int(message['responseHeader'].split()[1])==entry['response']['status']
                assert message['responseBody'].encode('utf-8')==base64.b64decode(entry['response']['content']['text'])
            save(RUN/'zap_messages'/f'{stem}.json',messages)
            alerts=api(port,'core','view','alerts',baseurl=wss['target'],start=0,count=10000)['alerts']
            mapped=[]
            for a in alerts:
                path=urllib.parse.urlsplit(a['url']).path
                if path not in (('/','/api/login') if 'COOKIE' in ident else ('/',)): continue
                if str(a['pluginId']) not in row['zap_plugin_ids'] or int(a.get('riskcode',0))<1: continue
                if a['pluginId'] in ('10055','10054') and a.get('alertRef') not in row['zap_alert_refs']: continue
                mapped.append(a)
            save(RUN/'zap'/f'{stem}.json',dict(case_id=ident,mode=mode,status='FAIL' if mapped else 'NO_ALERT',seconds=seconds,rss_before=before,rss_after=after,http_requests=0,imported_messages=expected,import_response=imported,message_count_before=before_count,message_count_after=after_count,polls=polls,alerts=alerts,mapped_alerts=mapped,har_sha256=sha(har)))
            print(stem,wss['status'],'FAIL' if mapped else 'NO_ALERT',flush=True)
    save(RUN/'integrity.json',verify())
    save(RUN/'complete.json',dict(at=now(),trials=52,zap_memory=memory(env['pid'])))

if __name__=='__main__':
    {'register':register,'start':start,'run':run,'worker':lambda:worker(*sys.argv[2:])}[sys.argv[1]]()
