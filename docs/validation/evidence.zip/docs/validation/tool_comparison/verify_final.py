"""Independent consistency checks and final seal; never rewrites prior artifacts."""
from collections import Counter
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import final_compare as f

def main():
    run=f.RUN; reg=f.read(run/'preregistration.json'); analysis=f.read(run/'analysis.json')
    primary=[r for r in reg['cases'] if r['group']=='primary']
    assert len(primary)==25
    assert Counter(r['truth'] for r in primary)==dict(vulnerable=9,safe=11,unknown=5)
    frozen=f.read(f.HOLD/'source_hashes.json')
    frozen_changes=[rel for rel,digest in frozen.items() if f.sha(f.ROOT/rel)!=digest]
    history=f.read(f.OUT/'protected_history.json')
    history_changes=[rel for rel,digest in history.items() if f.sha(f.ROOT/rel)!=digest]
    assert not frozen_changes,frozen_changes
    assert not history_changes,history_changes
    rows=analysis['case_results']; assert len(rows)==52
    requests=0; imported=0
    for row in rows:
        stem=row['id']+'-'+row['mode']; har=run/'har'/f'{stem}.har'
        w=f.read(run/'wss'/f'{stem}.json'); z=f.read(run/'zap'/f'{stem}.json')
        messages=f.read(run/'zap_messages'/f'{stem}.json')
        n=len(f.read(har)['log']['entries'])
        assert n==w['http_requests']==z['imported_messages']==len([m for m in messages if m['type']=='15'])
        assert f.sha(har)==z['har_sha256']
        assert not w['denied_connections'] and not w['error']
        assert z['polls'][-1]['queue']['recordsToScan']=='0'
        assert z['polls'][-1]['running']['currentTasks']==[]
        requests+=w['http_requests']; imported+=z['imported_messages']
    assert requests==imported==1196
    for mode in ('none','headers'):
        for tool in ('wss','zap'):
            subset=[r for r in rows if r['mode']==mode and r['group']=='primary' and r['truth']!='unknown']
            totals=Counter()
            for row in subset:
                status=row[tool]
                if status=='WARNING':totals['ABSTAIN']+=1
                elif status=='ERROR':totals['ERROR']+=1
                elif row['truth']=='vulnerable':totals['TP' if status=='FAIL' else 'FN']+=1
                else:totals['FP' if status=='FAIL' else 'TN']+=1
            # Recompute explicitly to avoid relying on analyzer helper functions.
            expected=analysis['metrics'][mode][tool]
            for key in ('TP','FP','FN','TN','ABSTAIN','ERROR'):
                assert totals[key]==expected[key],(mode,tool,key,totals,expected)
            assert sum(expected[k] for k in ('TP','FP','FN','TN','ABSTAIN','ERROR'))==20
    env=f.read(run/'environment.json')
    before_shutdown=f.memory(env['pid'])
    shutdown=f.api(env['port'],'core','action','shutdown')
    f.save(run/'shutdown.json',dict(at=f.now(),response=shutdown,last_memory=before_shutdown))
    f.save(run/'verification.json',dict(at=f.now(),primary=25,known=20,unknown=5,supplemental=1,trials=52,http_requests=requests,imported_messages=imported,frozen_source_files=len(frozen),frozen_changes=frozen_changes,historical_files=len(history),historical_changes=history_changes,protected=f.verify(),metrics_checked=True,har_and_queue_checks=True))
    # Hash durable artifacts; runtime DB/log files may still flush during shutdown.
    files=[p for p in f.OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'zap-home' not in p.parts and p.name not in ('artifact_hashes.json','zap_stdout.log')]
    f.save(run/'artifact_hashes.json',{str(p.relative_to(f.OUT)):f.sha(p) for p in files})
    print('Verified, stopped owned ZAP daemon, and sealed',len(files),'artifacts.')

if __name__=='__main__':main()
