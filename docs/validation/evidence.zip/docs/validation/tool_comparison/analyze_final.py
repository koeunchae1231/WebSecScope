"""Recompute metrics from raw evidence using preregistered semantics."""
import csv
from collections import Counter
import json
from pathlib import Path
import statistics
import sys
from urllib.parse import urlsplit
sys.path.insert(0,str(Path(__file__).resolve().parent))
import final_compare as f

RUN=f.RUN
def positive(a):
    # This installed core API provides risk labels, not riskcode.
    return int(a['riskcode'])>=1 if 'riskcode' in a else a.get('risk') in ('Low','Medium','High')

def mapped(row,raw):
    selected=[]
    for a in raw['alerts']:
        if urlsplit(a['url']).path not in (('/','/api/login') if 'COOKIE' in row['id'] else ('/',)): continue
        if str(a['pluginId']) not in row['zap_plugin_ids'] or not positive(a): continue
        if str(a['pluginId']) in ('10055','10054') and a.get('alertRef') not in row['zap_alert_refs']: continue
        selected.append(a)
    return selected

def ratio(a,b): return a/b if b else None
def metrics(rows,tool):
    known=[r for r in rows if r['truth']!='unknown']; counts=Counter()
    for r in known:
        status=r[tool]
        if status in ('ERROR','WARNING'): counts['ERROR' if status=='ERROR' else 'ABSTAIN']+=1
        elif r['truth']=='vulnerable': counts['TP' if status=='FAIL' else 'FN']+=1
        else: counts['FP' if status=='FAIL' else 'TN']+=1
    for key in ('TP','FP','FN','TN','ABSTAIN','ERROR'): counts.setdefault(key,0)
    tp,fp,fn,tn=[counts[k] for k in ('TP','FP','FN','TN')]
    return dict(counts,known=len(known),unknown=len(rows)-len(known),precision=ratio(tp,tp+fp),recall=ratio(tp,tp+fn),coverage=ratio(tp+fp+fn+tn,len(known)),vulnerable_detection=ratio(tp,sum(r['truth']=='vulnerable' for r in known)),conservative_accuracy=ratio(tp+tn,len(known)),unknown_outputs=dict(Counter(r[tool] for r in rows if r['truth']=='unknown')))

def perf(rows,tool):
    raws=[f.read(RUN/tool/(r['id']+'-'+r['mode']+'.json')) for r in rows]
    secs=[r['seconds'] for r in raws]; peaks=[r['rss_after']['peak_bytes']/1048576 for r in raws if r['rss_after']]
    current=[r['rss_after']['current_bytes']/1048576 for r in raws if r['rss_after']]
    return dict(trials=len(raws),seconds_total=sum(secs),seconds_median=statistics.median(secs),seconds_min=min(secs),seconds_max=max(secs),target_http_requests=sum(r['http_requests'] for r in raws),imported_messages=sum(r.get('imported_messages',0) for r in raws),rss_after_median_mib=statistics.median(current) if current else None,peak_mib_max=max(peaks) if peaks else None,memory_unavailable=sum(r['rss_after'] is None for r in raws))

def main():
    assert (RUN/'complete.json').exists()
    reg=f.read(RUN/'preregistration.json'); rows=[]; corrected=[]
    for row in reg['cases']:
        if row['group']=='excluded':continue
        for mode in reg['modes']:
            stem=row['id']+'-'+mode; w=f.read(RUN/'wss'/f'{stem}.json'); z=f.read(RUN/'zap'/f'{stem}.json')
            alerts=mapped(row,z); status='FAIL' if alerts else 'NO_ALERT'
            if status!=z['status']: corrected.append(stem)
            rows.append(dict(id=row['id'],group=row['group'],mode=mode,truth=row['truth'],scenario=row['scenario'],wss=w['status'],zap=status,zap_alert_refs=sorted(set(a.get('alertRef','') for a in alerts)),wss_evidence=[v['evidence'] for v in w['selected']]))
    result={}
    for mode in reg['modes']:
        primary=[r for r in rows if r['group']=='primary' and r['mode']==mode]
        result[mode]=dict(wss=metrics(primary,'wss'),zap=metrics(primary,'zap'),performance={t:perf(primary,t) for t in ('wss','zap')},disagreements=[r['id'] for r in primary if (r['wss']=='FAIL')!=(r['zap']=='FAIL') or r['wss'] in ('WARNING','ERROR')])
    f.save(RUN/'analysis.json',dict(metrics=result,case_results=rows,policy_supplement=[r for r in rows if r['group']=='policy_supplement'],adapter_correction=dict(reason='Raw ZAP API risk is a label (Low/Medium/High), not riskcode. Runner defaulted missing riskcode to 0 and its convenience status/mapped_alerts are invalid. Recompute from preserved full alerts; original positivity rule risk>=1 and all IDs/refs unchanged. No scan or truth changed.',corrected_status_trials=corrected),integrity=f.verify()))
    with (RUN/'case_results.csv').open('w',encoding='utf-8-sig',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=['id','group','mode','truth','wss','zap','zap_alert_refs','scenario']);writer.writeheader()
        for r in rows:writer.writerow({k:r[k] for k in writer.fieldnames})
    with (RUN/'selection.csv').open('w',encoding='utf-8-sig',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=['id','group','truth','scenario','reason']);writer.writeheader()
        for r in reg['cases']: writer.writerow({k:r[k] for k in writer.fieldnames})
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
