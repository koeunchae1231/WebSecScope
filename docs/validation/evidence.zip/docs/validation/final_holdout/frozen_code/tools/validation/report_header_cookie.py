"""Phase 3 audit and report; read measured artifacts without relabeling cases."""
import json
from pathlib import Path

from baseline import metrics,stats
from header_cookie_validation import ROOT,OUT,sha,frozen


def summary(d):
    first=[r for r in d['runs'] if r['repeat']==1]
    cases={c['id']:c for c in d['cases'] if c['vulnerable'] is not None and c['family']!='unsupported'}
    rows=[r for r in first if r['case_id'] in cases]
    assert len(rows)==38
    m=metrics(rows)
    negative=[dict(classification=('FN' if cases[r['case_id']]['vulnerable'] else 'TN')
                   if r['classification']=='ABSTAIN' else r['classification']) for r in rows]
    return dict(metrics=m,warning_negative=metrics(negative),conservative_accuracy=(m['TP']+m['TN'])/38,
                timing=d['timing'],non_fault=stats([r['seconds'] for r in d['runs'] if not r['case_id'].startswith('E-')]),
                requests=sum(len(r['requests']) for r in d['runs']),server_requests=sum(len(r['server_events']) for r in d['runs']),
                request_errors=d['request_errors'],timeout_errors=d['timeout_errors'],scan_exceptions=d['scan_exceptions'])


def main():
    frozen()
    previous_path=ROOT/'docs/validation/improvement_02/results/baseline_results.json'
    current_path=OUT/'results/baseline_results.json'
    old,new=[json.loads(p.read_text(encoding='utf-8')) for p in (previous_path,current_path)]
    assert old['cases']==new['cases']
    oldmap={(r['case_id'],r['repeat']):r for r in old['runs']}
    assert len(oldmap)==len(new['runs'])==123
    assert len({(r['case_id'],r['repeat']) for r in new['runs']})==123
    expected_changes={'H-13','H-14','C-03','C-04'}
    actual_changes=set()
    for r in new['runs']:
        previous=oldmap[(r['case_id'],r['repeat'])]
        if (previous['status'],previous['classification'])!=(r['status'],r['classification']):
            actual_changes.add(r['case_id'])
        # Exposure and API/Auth observations must remain identical, not merely final metrics.
        before_unrelated=[f for f in previous['findings'] if f['category']!='web' or f['check_id']=='WEB_SENSITIVE_PATHS']
        after_unrelated=[f for f in r['findings'] if f['category']!='web' or f['check_id']=='WEB_SENSITIVE_PATHS']
        assert before_unrelated==after_unrelated,(r['case_id'],r['repeat'])
        assert len(previous['requests'])==len(r['requests']),(r['case_id'],r['repeat'])
    assert actual_changes==expected_changes,actual_changes
    assert new['regression_exit_code']==0 and new['production_and_existing_tests_unchanged']
    for name,digest in new['source_hashes'].items():
        assert sha(ROOT/name)==digest,name
    for c in new['cases']:
        rows=[r for r in new['runs'] if r['case_id']==c['id']]
        assert len({(r['status'],r['classification']) for r in rows})<=1,c['id']
    b,a=summary(old),summary(new)
    first=[r for r in new['runs'] if r['repeat']==1]
    changed_files=[]
    for rel,digest in json.loads((OUT/'before/manifest.json').read_text(encoding='utf-8')).items():
        if sha(ROOT/rel)!=digest:
            changed_files.append(Path(rel).as_posix())
    assert changed_files==['websecscope/scanner/web.py'],changed_files
    data=dict(before=b,after=a,changed_existing_files=changed_files,changed_cases=sorted(actual_changes),
              immutable_history=True,unchanged_cases_and_policy=True,unchanged_sensitive_and_api_auth_findings=True,
              before_sha256=sha(previous_path),after_sha256=sha(current_path),case_comparison=[])
    fmt=lambda v:'N/A' if v is None else f'{v*100:.2f}%'
    text='''# 3차 개선: HTTP 보안 헤더와 쿠키 검사

## 분석과 변경 범위

브랜치 `improve/sensitive-path-validation`에서 수행했으며 main에 병합하지 않았다. [소스 스냅샷](before/manifest.json) 74개 파일과 [과거 결과 해시](history_manifest.json) 273개를 보존하고 실행 전후 일치를 검사했다. Baseline v1·1차·2차 결과는 변경하지 않았다. baseline.py의 서버·정답 계약·38개 보안 사례·타임아웃·집계 정책도 그대로다.

기존 `_scan_security_headers`는 6개 헤더가 비어 있지 않으면 PASS였고 루트 HEAD만 확인했다. `_scan_cookie_flags`는 전체 문자열에서 secure/httponly/samesite가 발견되면 PASS여서 쿠키 이름·값과 속성을 구분하지 못했다. 검사 항목을 삭제하지 않고 다음과 같이 확장했다.

|헤더|기존 조건|개선한 설정 검증|범위·한계|
|---|---|---|---|
|X-Content-Type-Options|값 존재|대소문자 무관 nosniff만 인정|응답 MIME 및 브라우저 실제 sniffing 미검증|
|X-Frame-Options|값 존재|DENY/SAMEORIGIN만 인정, obsolete ALLOW-FROM 및 잘못된 값 FAIL|프레이밍 공격 성공·CSP와의 우선순위 미검증|
|Content-Security-Policy|값 존재|빈 값/명백한 구문 오류/따옴표 불균형/알려진 강제 지시어 부재/보고 전용 지시어만 존재 시 FAIL. 알려진 기본 구문 PASS. 알 수 없거나 중복된 지시어·합쳐진 정책 WARNING|전체 source 표현식·nonce/hash·우회·브라우저 정책 조합 미분석. 값 없는 source-list 지시어는 차단 정책이므로 유효하게 인정|
|Strict-Transport-Security|값 존재|양의 숫자 max-age, includeSubDomains/preload flag 구문 검증. 누락/음수/0/숫자 아님 FAIL, 중복 WARNING|HTTP fixture에서는 유효한 설정값도 보호 효과를 증명하지 않음. scheme·hsts_https_context·browser_enforcement_verified=false를 분리 기록. 인증서·HTTPS 강제·preload 가입 미검증|
|Referrer-Policy|값 존재|인식되는 정책 및 마지막 유효 fallback 값 확인|unsafe-url 등 구문상 유효 값의 개인정보 보호 강도는 평가하지 않음|
|Permissions-Policy|값 존재|feature=(), feature=*, feature=(self "origin") 기본 구문, 중복 feature WARNING|전체 Structured Fields 파서나 브라우저 feature registry가 아님. 알 수 없는 feature 지원·실제 권한 효과 미검증|

각 헤더의 빈 값과 누락은 FAIL이다. HEAD·GET 각각을 검증하여 하나라도 명백한 설정 결함이면 FAIL, 둘 다 유효하더라도 값이 다르면 WARNING이다. GET 관측 실패는 정상 PASS로 결론내리지 않는다. HEAD 네트워크 실패로 GET fallback을 사용한 경우 initial_method=GET으로 기록하며 HEAD를 관측했다고 주장하지 않는다. FAIL은 설정 결함 판정이며 실제 공격 가능성 확정이 아니다.

### 쿠키

새 `rules/web/cookie_values.py:cookie_attributes`는 Set-Cookie 필드별로 첫 cookie-pair와 뒤 속성을 구분하고, 따옴표 밖 세미콜론만 구분자로 사용한다. Expires 날짜의 쉼표나 여러 Set-Cookie를 무조건 합쳐 파싱하지 않는다. 보안 속성 이름은 대소문자 무관이다. Secure/HttpOnly/SameSite 누락 및 SameSite의 Strict/Lax/None 외 값은 FAIL, None인데 Secure가 없으면 FAIL이다. 여러 필드 중 하나가 취약하면 기존 WEB_COOKIE_FLAGS 하나를 FAIL로 집계한다. 쿠키 이름/값의 키워드는 속성으로 인정하지 않는다.

보안 속성 중복·충돌은 유지해 WARNING으로 표시한다(명백한 누락·잘못된 SameSite가 함께 있으면 FAIL 우선). Secure=false 등 flag에 값이 붙는 비정형 설정은 WARNING이다. 브라우저가 이를 단순 false로 처리한다고 가정하지 않는다. 필드 자체가 파싱 불가능하면 WARNING이며 정상으로 인정하지 않는다. 쿠키 값은 finding 증거·metadata에 저장하지 않고 이름과 보안 속성만 기록한다. 쿠키 발급이 없으면 관측 범위에서 PASS다. 쿠키 용도·Domain/Path·접두사·브라우저 저장/전송 효과는 전체 검증하지 않는다.

HEAD 및 실제 GET 문서 양쪽의 Set-Cookie를 검사한다. 완전히 같은 헤더는 메서드 간 중복만 합치고, 서로 다른 쿠키/속성은 각각 검사하며 메서드별 개수·차이·오류를 metadata에 기록한다. SameSite=None과 Secure가 존재해도 실제 cross-site 전달이 보장되는 것은 아니다. 모든 쿠키에 세 속성을 요구하는 기존 정책을 유지했으며 의도된 비세션/JavaScript 접근 쿠키는 정책상 경고 또는 실패가 될 수 있다.

### 파일·인터페이스·요청

- `scanner/web.py:scan_web_target`: 기존 대조군 루트 GET을 한 번 요청해 헤더·쿠키와 민감 경로 양쪽에 사용한다. 일반 경로의 HTTP 요청 수는 늘리지 않았다.
- `_scan_security_headers`: 기존 1인자 호출을 유지하면서 GET 헤더·scheme·오류·initial_method 선택 인자를 추가했다. 기존 6개 check_id를 유지한다.
- `_scan_cookie_flags`: 구조 파서 결과로 동일 WEB_COOKIE_FLAGS를 집계한다. API/Auth의 별도 쿠키 검사는 변경하지 않았다.
- `_scan_sensitive_paths`: 선택 인자 root_response로 동일 요청 정책의 루트 GET 관측을 전달한다. 경로/본문 판정·후보 HEAD/GET 및 없는 경로 조건부 요청 로직은 유지한다.
- `_request`: 성공 응답의 최종 URL을 추가 기록해 리디렉션 후 scheme을 확인한다. 기존 필드는 유지한다.
- 새 규칙 `rules/web/header_values.py:validate_header`, `rules/web/cookie_values.py:cookie_attributes`. 기존 SECURITY_HEADERS/SENSITIVE_PATHS 규칙은 그대로다.

Finding 모델·check_id·orchestrator·JSON의 기존 필드를 유지하고 metadata를 확장했다. 헤더·쿠키의 상세 evidence와 status는 의도적으로 변경된다. 루트 HEAD는 기존 리디렉션 추적 정책, 대조군 GET은 추적하지 않는 정책을 유지한다. 루트가 리디렉션하면 원래 대조군과 실제 문서를 혼동하지 않도록 추가 follow-redirect GET이 필요하다. 그 경우 논리 요청 1건과 리디렉션 hop만큼 실제 요청이 더 생길 수 있다. 고정 41개 사례에는 루트 리디렉션이 없으므로 이 비용은 포함되지 않고 신규 로컬 테스트에서 동작만 검증했다.

## 정확도: 동일 38개 보안 사례

각 첫 회만 일대일 집계하고 WARNING=ABSTAIN, ERROR 별도, 분모0=N/A 정책을 유지했다. 가용성 3개는 제외, 미지원 선언 1개는 미실행이다. 보안 사례의 반복 실행을 추가 TP로 가산하지 않았다.

|항목|2차 최적화|3차 개선|
|---|---|---|
'''
    for key in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','abstained','errors'):
        f=fmt if key in {'precision','recall','fpr','accuracy','coverage'} else str
        text+=f"|{key}|{f(b['metrics'][key])}|{f(a['metrics'][key])}|\n"
    text+=f"|WARNING=음성 Accuracy|{fmt(b['warning_negative']['accuracy'])}|{fmt(a['warning_negative']['accuracy'])}|\n"
    text+=f"|WARNING=오답 보수적 Accuracy|{fmt(b['conservative_accuracy'])}|{fmt(a['conservative_accuracy'])}|\n"
    text+='''
기본 이진 지표는 보류를 제외한 32개에 대한 조건부 성능이고 Coverage는 32/38이다. WARNING=음성 정책은 취약 경고를 FN·정상 경고를 TN으로 처리한다. 보수적 Accuracy는 WARNING/ERROR를 모두 오답으로 취급한 (TP+TN)/38이다. ERROR는 음성으로 자동 치환하지 않는다. Recall 100%는 이진 분모에 대해서만 성립하며, 취약하지만 WARNING인 O-03은 남아 있다.

H-13/H-14/C-03/C-04는 모두 FN→TP로 바뀌며, 다른 34개 보안 사례와 가용성 3개는 선택 판정이 같다. 보류는 6개로 동일하므로 개선이 판정 보류 증가만으로 발생한 것이 아니다. 기존 고정 표본에서는 신규 FP·ABSTAIN이 없다. 다만 확장된 정책은 고정 표본 밖에서 새 FAIL/WARNING을 낼 수 있으며 아래 한계와 경계 테스트로 구분한다.

|사례|2차 상태/집계|3차 상태/집계|
|---|---|---|
'''
    for r in first:
        previous=oldmap[(r['case_id'],1)]
        data['case_comparison'].append(dict(id=r['case_id'],before_status=previous['status'],before_classification=previous['classification'],after_status=r['status'],after_classification=r['classification']))
        text+=f"|{r['case_id']}|{previous['status']} / {previous['classification']}|{r['status']} / {r['classification']}|\n"
    text+='\n## 성능과 비용 (41개 × 3회 = 123회)\n\n|항목|2차|3차|\n|---|---|---|\n'
    for key in ('requests','server_requests','request_errors','timeout_errors','scan_exceptions'):
        text+=f"|{key}|{b[key]}|{a[key]}|\n"
    for key,label in [('mean','평균'),('p95','P95')]:
        text+=f"|전체 {label}(초)|{b['timing']['total'][key]:.6f}|{a['timing']['total'][key]:.6f}|\n"
        text+=f"|장애 제외 {label}(초), 각114회|{b['non_fault'][key]:.6f}|{a['non_fault'][key]:.6f}|\n"
    text+='\n|모듈|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|\n|---|---|---|---|---|\n'
    for name,v in b['timing']['modules'].items():
        w=a['timing']['modules'][name]
        text+=f"|{name}|{v['mean']:.6f}|{w['mean']:.6f}|{v['p95']:.6f}|{w['p95']:.6f}|\n"
    text+=f"\n전체 평균 변화 {(a['timing']['total']['mean']/b['timing']['total']['mean']-1)*100:+.2f}%, 장애 제외 평균 변화 {(a['non_fault']['mean']/b['non_fault']['mean']-1)*100:+.2f}%. HTTP 요청 수는 123회 모두 동일하다. 추가 네트워크 비용 없이 기본 파싱·HEAD/GET 값 비교 CPU 작업만 추가했지만, 독립적인 CPU 프로파일링은 하지 않았으므로 벽시계 차이를 전부 파서 비용으로 해석하지 않는다. 서로 다른 측정 시점의 부하·계측 비용이 포함된다. P95는 nearest-rank이며 의도적 장애가 포함된 전체 분포와 장애 제외 분포를 함께 봐야 한다.\n"
    text+='\n## 테스트와 검증 로그\n\n'
    text+='''신규 `tests/test_header_cookie_validation.py`의 64개 테스트는 기존 표본과 분리했다. 헤더 26개 값 경계, 기존 6종 헤더 × 빈 값2개=12개, 쿠키17개 경계, 복수 쿠키·HSTS HTTP 문맥·유효하지만 다른 HEAD/GET 각1개, 실제 로컬 HTTP 5개 변형, GET 관측 실패1개를 포함한다. 기존49개 테스트 파일은 변경하지 않았다. 실제 서버 테스트는 GET에만 두 쿠키 발급, 누락 CSP·잘못된 XFO, 루트 리디렉션, 루트 GET 1회 재사용을 검사한다. 추가된 테스트는 기존 38개 사례의 정확도 분모에 합치지 않았다.

전체 pytest 실제 출력:

```text
'''
    text+=(OUT/'results/regression.log').read_text(encoding='utf-8')+'\n```\n'
    text+='```text\n'+(OUT/'results/verification.log').read_text(encoding='utf-8')+'\n```\n'
    text+=f"\n측정 환경: {new['platform']}; Python {new['python']}; 생성 시각 {new['generated_at']} UTC. 정확도·소요시간은 baseline.py의 기존 동일 실행 흐름으로 측정했다. pytest 캐시 권한 경고가 있다면 저장 제한이며 테스트 실패와 구분한다. 소스 해시·반복 안정성·CSV/JSON·기존 결과 무결성 및 모든 민감 경로/API/Auth finding의 일치를 검증했다.\n"
    text+='''
## 한계·남은 사례·다음 단계

이번 검사는 구성 검증이다. CSP는 source-list 전체 구문, 잘못된 키워드/호스트/nonce/hash, 실제 페이지 동작·공격 우회·브라우저 조합까지 판별하지 않는다. 기본 구문 PASS는 완전한 안전성 보장이 아니다. 지원하지 않는 최신 지시어·합쳐진 정책을 WARNING으로 처리하므로 적법한 정책에도 보류가 생길 수 있다. Permissions-Policy도 전체 Structured Fields 파서가 아니어서 복잡한 유효 입력을 잘못 거부할 수 있으며 기능 지원·allowlist의 실질 강도를 보장하지 않는다. Referrer-Policy의 구문상 유효 unsafe-url을 개인정보 관점에서 안전하다고 확정하지 않는다.

Cookie 파서는 중복을 보존하지만 완전한 브라우저 구현은 아니다. 일부 비정형/따옴표/결합 헤더를 WARNING 또는 FAIL로 처리하며 브라우저가 쿠키 자체를 거부하거나 기본 SameSite를 적용하는 경우까지 모사하지 않는다. 중복 속성·Secure=false에 대한 WARNING은 확정 취약점과 구분한다. API/Auth의 별도 문자열 쿠키 검사는 이번 범위에서 유지하여 여전히 같은 한계가 남는다. GET 본문 읽기 실패 시 헤더를 일부 받았어도 비교가 불완전하다고 보류한다.

같은 스캔 안에서도 HEAD와 GET 사이 서버 상태가 바뀔 수 있다. 유효한 정책끼리 달라졌을 때 WARNING은 검토 신호이지 취약 확정이 아니다. 로컬 HTTP만 사용하므로 TLS 인증서·HSTS 실제 적용·Secure 쿠키 전송·SameSite의 실제 cross-site 보호를 검증하지 않았다. HTTPS scheme metadata만으로 실제 브라우저 보호를 주장하지 않는다.

고정 표본의 남은 오탐은 A-04(API 관리자 SPA)이며, 보류는 P-03/P-04/P-08/P-09 및 O-03/O-04다. 실제 취약한 O-03은 보류이므로 모든 취약점 탐지를 완료한 것은 아니다. 일반 민감 경로 형식 휴리스틱·4096바이트 본문 한계·동적 SPA·소켓 timeout과 절대 deadline의 차이도 남아 있다.

전체 회귀와 고정 표본 개선 검증을 통과했으므로 다음 단계 진행은 가능하다. API/Auth의 쿠키 규칙 통합은 별도 정답/회귀 표본을 먼저 만들고, A-04와 CORS 보류의 의미를 다루는 독립 변경으로 비교하는 것이 적절하다. 운영 반영이나 main 병합을 자동 수행하지 않는다.

## 재현·원시 근거·기준 문서

- [원시 JSON](results/baseline_results.json), [CSV](results/baseline_summary.csv), [실행 로그](results/execution.log), [pytest](results/regression.log), [verify](results/verification.log), [비교 JSON](comparison.json), [감사 로그](audit.log)
- 보존: `python tools/validation/header_cookie_validation.py preserve`; 측정: `python tools/validation/header_cookie_validation.py run`; 문서: `python tools/validation/report_header_cookie.py`. 기존 산출물이 있으면 보존/측정 덮어쓰기를 거부하므로 새 실험은 OUT을 별도 위치로 지정한다.
- 읽기 전용 검증: `python tools/validation/verify.py --results docs/validation/improvement_03/results`.
- 원래 `baseline.py`를 직접 실행하면 원래 results를 덮어쓸 수 있어 위 wrapper를 사용한다. 이후 소스를 변경하면 이전 측정에 대한 해시 검증 실패는 정상적인 provenance 보호다.
- [W3C CSP](https://www.w3.org/TR/2021/WD-CSP3-20210629/): 빈 source list와 기본 지시어 해석 참고. 전체 정책 분석을 구현한 것은 아니다.
- [RFC 6797 HSTS](https://www.rfc-editor.org/info/rfc6797/): max-age와 HTTPS 적용 문맥을 구분한다.
- [MDN Set-Cookie](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Set-Cookie): 속성과 SameSite=None/Secure 관계를 참고했다.
'''
    (OUT/'comparison.md').write_text(text,encoding='utf-8')
    (OUT/'comparison.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    log='PASS: 273 historical files and 74 source snapshots unchanged; fixed cases and policy unchanged; only H-13/H-14/C-03/C-04 changed FN to TP; 123 request counts unchanged; sensitive-path/API/Auth findings unchanged; source hashes and repeat stability checked.\n'
    (OUT/'audit.log').write_text(log,encoding='utf-8')
    print(log)
    print(json.dumps(dict(before=b,after=a),indent=2))


if __name__=='__main__':
    main()
