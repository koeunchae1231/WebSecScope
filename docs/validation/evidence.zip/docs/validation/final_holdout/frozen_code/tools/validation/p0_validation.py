"""P0-only regression adapter; historical runners, fixtures and policies stay frozen."""
import argparse
import contextlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone

import independent_evaluation as ie

ROOT=ie.ROOT
OUT=ROOT/'docs/validation/post_independent/p0_improvement'


def write(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')


def initialize():
    assert not OUT.exists(), 'No overwrite'
    assert ie.git('branch','--show-current').strip()=='improve/sensitive-path-validation'
    ie.verify()
    for rel,h in ie.read('artifact_manifest.json').items():
        assert ie.sha(ie.OUT/rel)==h,rel
    rca=ie.OUT/'root_cause_analysis'
    for rel,h in json.loads((rca/'analysis_manifest.json').read_text(encoding='utf-8')).items():
        assert ie.sha(rca/rel)==h,rel
    OUT.mkdir(parents=True)
    sources={str(p.relative_to(ROOT)):ie.sha(p) for folder in ('websecscope','tests','tools/validation')
             for p in (ROOT/folder).rglob('*.py')}
    for rel in sources:
        dest=OUT/'before'/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(ROOT/rel,dest)
    write(OUT/'before_hashes.json',sources)
    history={str(p.relative_to(ROOT)):ie.sha(p) for folder in ('results','baseline_v1','improvement_01','improvement_02','improvement_03','improvement_04','independent_evaluation')
             for p in (ROOT/'docs/validation'/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    write(OUT/'history_hashes.json',history)
    (OUT/'git_before.log').write_text(ie.git('status','--porcelain=v1')+'\n'+ie.git('diff'),encoding='utf-8')
    write(OUT/'environment.json',dict(recorded_at=datetime.now(timezone.utc).isoformat(),python=sys.version,
          executable=sys.executable,platform=platform.platform(),branch=ie.git('branch','--show-current').strip(),
          revision=ie.git('rev-parse','HEAD').strip(),corpus_role='Original independent 72 is now development/regression data.'))
    p=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT,capture_output=True,text=True)
    (OUT/'pytest_before.log').write_text(p.stdout+p.stderr,encoding='utf-8')
    assert p.returncode==0 and '153 passed' in p.stdout
    print(f'Before preserved: {len(sources)} sources, {len(history)} historical artifacts, 153 tests passed.')


def check():
    history=json.loads((OUT/'history_hashes.json').read_text(encoding='utf-8'))
    for rel,h in history.items():
        assert ie.sha(ROOT/rel)==h,rel
    old=json.loads((OUT/'before_hashes.json').read_text(encoding='utf-8'))
    for rel,h in old.items():
        assert ie.sha(OUT/'before'/rel)==h,rel
        if rel!='websecscope\\analyzer\\api_auth_analyzer.py' and rel.replace('\\','/')!='websecscope/analyzer/api_auth_analyzer.py':
            assert ie.sha(ROOT/rel)==h,rel
    frozen=OUT/'measured_source_hashes.json'
    if frozen.exists():
        for rel,h in json.loads(frozen.read_text(encoding='utf-8')).items():
            assert ie.sha(ROOT/rel)==h,rel


def freeze():
    check()
    assert not (OUT/'measured_source_hashes.json').exists()
    sources={str(p.relative_to(ROOT)):ie.sha(p) for folder in ('websecscope','tests') for p in (ROOT/folder).rglob('*.py')}
    write(OUT/'measured_source_hashes.json',sources)
    (OUT/'changes.patch').write_text(ie.git('diff','--','websecscope/analyzer/api_auth_analyzer.py'),encoding='utf-8')
    # The full diff includes earlier work; preserve a precise P0-only diff as well.
    import difflib
    rel='websecscope/analyzer/api_auth_analyzer.py'
    before=(OUT/'before'/rel).read_text(encoding='utf-8').splitlines(True)
    after=(ROOT/rel).read_text(encoding='utf-8').splitlines(True)
    (OUT/'p0_only.patch').write_text(''.join(difflib.unified_diff(before,after,fromfile='before/'+rel,tofile=rel)),encoding='utf-8')
    print('Measured sources frozen.')


def fixed():
    import baseline as b
    check()
    folder=OUT/'fixed'
    assert not folder.exists()
    folder.mkdir()
    b.OUT=folder
    with (folder/'execution.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        b.main()
    p=subprocess.run([sys.executable,'tools/validation/verify.py','--results',str(folder)],cwd=ROOT,capture_output=True,text=True)
    (folder/'verification.log').write_text(f'Exit: {p.returncode}\n'+p.stdout+p.stderr,encoding='utf-8')
    check()
    assert p.returncode==0
    assert json.loads((folder/'baseline_results.json').read_text(encoding='utf-8'))['regression_exit_code']==0
    print('Fixed 38 + availability 3, each 3 repeats, verified.')


def independent():
    check()
    original=ie.OUT
    folder=OUT/'independent'
    assert not folder.exists()
    folder.mkdir()
    for name in ('cases.json','policy.json'):
        shutil.copy2(original/name,folder/name)
    shutil.copy2(original/'preregistration.json',folder/'original_preregistration.json')
    # Only output location and provenance guard change in memory. Selectors, fixture,
    # trial order, classifications and the original runner implementation do not.
    ie.OUT=folder
    ie.verify=check
    ie.run()
    for name in ('cases.json','policy.json'):
        assert ie.sha(folder/name)==ie.sha(original/name)
    print('72 consumed development/regression cases, 216 trials, frozen v1 policy retained.')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['initialize','freeze','fixed','independent','check'])
    globals()[parser.parse_args().action]()
