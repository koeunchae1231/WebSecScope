"""Read-only consistency and provenance checks for a completed baseline."""
import csv
import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).parent))
from baseline import metrics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--results', type=Path, default=ROOT / 'docs/validation/results')
parser.add_argument('--revalidation', type=Path, help='Explicit later test-only change and current regression evidence; preserves historical result.')
args = parser.parse_args()
out = args.results
d = json.loads((out/'baseline_results.json').read_text(encoding='utf-8'))
assert d['production_and_existing_tests_unchanged']
later = json.loads(args.revalidation.read_text(encoding='utf-8')) if args.revalidation else None
if later:
    assert later['measurement_sha256'] == hashlib.sha256((out/'baseline_results.json').read_bytes()).hexdigest()
    assert set(later['authorized_test_changes']) == {'tests/test_http_status.py'}
    current_sources = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for folder in ('websecscope', 'tests') for p in (ROOT/folder).rglob('*.py')}
    assert current_sources == later['current_source_hashes']
for name, digest in d['source_hashes'].items():
    current = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    change = later['authorized_test_changes'].get(Path(name).as_posix()) if later else None
    if change:
        assert change['before'] == digest and change['after'] == current, name
    else:
        assert current == digest, name
ids = [c['id'] for c in d['cases']]
assert len(ids) == len(set(ids))
assert len({(r['case_id'],r['repeat']) for r in d['runs']}) == len(d['runs'])
assert all(urlparse(r['target']).hostname == '127.0.0.1' for r in d['runs'])
assert all(urlparse(q['url']).hostname == '127.0.0.1' for r in d['runs'] for q in r['requests'])
for c in d['cases']:
    rows = [r for r in d['runs'] if r['case_id']==c['id']]
    assert len(rows) == (0 if c['config'].get('unsupported') else 3), c['id']
    assert len({(r['status'],r['classification']) for r in rows}) <= 1, c['id']
assert metrics([r for r in d['runs'] if r['repeat']==1]) == d['metrics']
with (out/'baseline_summary.csv').open(encoding='utf-8-sig', newline='') as f:
    csvrows = list(csv.DictReader(f))
assert len(csvrows) == len(d['runs'])
for row, run in zip(csvrows, d['runs']):
    assert row['case_id'] == run['case_id']
    assert row['classification'] == run['classification']
    assert float(row['seconds']) == run['seconds']
assert sum(r['request_errors'] for r in d['runs']) == d['request_errors']
assert sum(r['timeout_errors'] for r in d['runs']) == d['timeout_errors']
if later:
    assert later['pytest_exit_code'] == 0
    assert hashlib.sha256((ROOT/later['pytest_log']).read_bytes()).hexdigest() == later['pytest_log_sha256']
    print(f"Historical regression exit: {d['regression_exit_code']}; current regression exit: {later['pytest_exit_code']}. Authorized test-only change verified; historical result was not rewritten.")
else:
    assert d['regression_exit_code'] == 0
print(f"Verified {len(ids)} case definitions, {len(d['runs'])} runs, CSV/JSON metrics, loopback-only requests, stable repetitions and measured source provenance.")
