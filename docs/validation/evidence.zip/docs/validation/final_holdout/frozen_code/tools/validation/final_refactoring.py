"""Preserve the current dirty tree and reuse the frozen loopback regression runner."""
from pathlib import Path
import hashlib
import json
import platform
import runpy
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/validation/post_independent/final_refactoring'
PRIOR = OUT.parent / 'p2_header_requirements'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def initialize():
    OUT.mkdir(exist_ok=False)
    files = [p for folder in ('websecscope', 'tests', 'tools', 'docs')
             for p in (ROOT / folder).rglob('*') if p.is_file()
             and '__pycache__' not in p.parts and OUT not in p.parents]
    files += [ROOT / n for n in ('README.md', 'README_EN.md', 'main.py', 'requirements.txt', 'pytest.ini')]
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in files}
    (OUT / 'before_hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
    for p in files:
        if p.relative_to(ROOT).parts[0] in ('websecscope', 'tests', 'tools') or p.parent == ROOT:
            dest = OUT / 'before' / p.relative_to(ROOT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
    (OUT / 'git_before.log').write_text(subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True), encoding='utf-8')
    (OUT / 'environment.json').write_text(json.dumps(dict(python=sys.version, executable=sys.executable,
        platform=platform.platform()), indent=2), encoding='utf-8')
    for stage in ('baseline', 'after'):
        folder = OUT / stage
        folder.mkdir()
        for name in ('preregistered_policy.json', 'preregistered_header_profile.json',
                     'header_profile_sha256.txt', 'policy_sha256.txt'):
            shutil.copy2(PRIOR / name, folder / name)


def regression(stage):
    ns = runpy.run_path(str(PRIOR / 'run_regression.py'))
    ns['main'].__globals__['OUT'] = OUT / stage
    ns['main']()


if __name__ == '__main__':
    if sys.argv[1] == 'initialize':
        initialize()
    else:
        regression(sys.argv[1])
