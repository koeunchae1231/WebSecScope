"""Generate phase 2 audit report from immutable measured JSON and paired timings."""
import json
from pathlib import Path
import subprocess
import sys

from optimize_requests import ROOT, OUT, SNAP, verify_frozen, digest
from baseline import metrics,stats


def main():
    verify_frozen()
    old=json.loads((ROOT/'docs/validation/improvement_01/results/baseline_results.json').read_text(encoding='utf-8'))
    new=json.loads((OUT/'results/baseline_results.json').read_text(encoding='utf-8'))
    perf=json.loads((OUT/'performance.json').read_text(encoding='utf-8'))
    assert old['cases']==new['cases']
    assert old['metrics']==new['metrics']
    assert new['regression_exit_code']==0 and new['production_and_existing_tests_unchanged']
    oldmap={(r['case_id'],r['repeat']):r for r in old['runs']}
    assert len(oldmap)==len(new['runs'])==123
    assert len({(r['case_id'],r['repeat']) for r in new['runs']})==123
    assert all(oldmap[(r['case_id'],r['repeat'])]['status']==r['status'] and oldmap[(r['case_id'],r['repeat'])]['classification']==r['classification'] for r in new['runs'])
    changed=[]
    manifest=json.loads((SNAP/'manifest.json').read_text(encoding='utf-8'))
    for name,sha in manifest.items():
        if name.startswith(('websecscope','tests')) and digest(ROOT/name)!=sha:
            changed.append(Path(name).as_posix())
    assert set(changed)=={'websecscope/scanner/web.py','tests/test_sensitive_paths_content.py'},changed
    for name,sha in new['source_hashes'].items():
        assert digest(ROOT/name)==sha,name
    for r in new['runs']:
        previous=oldmap[(r['case_id'],r['repeat'])]
        assert [f for f in r['findings'] if f['category']!='web']==[f for f in previous['findings'] if f['category']!='web']
        oldpaths=next((f['metadata']['paths'] for f in previous['findings'] if f['check_id']=='WEB_SENSITIVE_PATHS'),[])
        newpaths=next((f['metadata']['paths'] for f in r['findings'] if f['check_id']=='WEB_SENSITIVE_PATHS'),[])
        assert oldpaths==newpaths,(r['case_id'],r['repeat'])
    assert metrics([r for r in new['runs'] if r['repeat']==1])==new['metrics']
    def summarize(d):
        m=d['metrics']
        return dict(metrics=m,conservative_accuracy=(m['TP']+m['TN'])/38,
                    requests=sum(len(r['requests']) for r in d['runs']),
                    server_observed_requests=sum(len(r['server_events']) for r in d['runs']),timing=d['timing'],
                    non_fault=stats([r['seconds'] for r in d['runs'] if not r['case_id'].startswith('E-')]))
    before,after=summarize(old),summarize(new)
    data=dict(before=before,after=after,performance=perf['summary'],changed_existing_sources=changed,
              cases_and_policy_unchanged=True,all_123_selected_classifications_unchanged=True,
              all_117_sensitive_path_observations_unchanged=True,api_auth_findings_unchanged=True,
              old_artifacts_unchanged=True,case_comparison=[])
    report='''# 2차 개선: 민감 경로 요청 최적화

## 변경 요약과 보존

작업 브랜치는 `improve/sensitive-path-validation`이며 main 병합은 하지 않았다. 2차 개선 전 소스·44개 테스트·검증 도구·v1/1차 결과 167개 파일을 [before/manifest.json](before/manifest.json)과 상대 경로 복사본으로 보존했다. 원래 v1·1차 결과·revalidation 문서는 실행 전후 SHA-256이 동일하다. baseline.py fixture·정답 계약·후보·1초 timeout·WARNING=ABSTAIN 정책을 바꾸지 않았다.

## 요청 구조 분석

|요청|목적|중복 여부·결정|
|---|---|---|
|루트 HEAD, 오류일 때 GET fallback|도달성 및 헤더/쿠키 관측|헤더를 GET으로 바꾸면 기존 진단 의미가 달라져 유지. fallback은 follow_redirects=True|
|민감 경로 대조용 루트 GET|실제 문서 표본|HEAD와 메서드가 다르고 fallback GET과도 follow_redirects=False 정책이 달라 단순 재사용하지 않음|
|.git/HEAD, .env, backup.zip, admin, phpinfo.php 각각 HEAD 및 GET|메서드 불일치·본문·HTTP/네트워크 오류 기록|200/404 중 하나를 생략하면 HEAD/GET 차이 근거를 잃으므로 모두 유지|
|무작위 없는 경로 GET|루트와 같은 HTML catch-all/SPA인지 검증|기존에는 무조건 요청. 후보 GET 본문이 루트와 다르면 전체 일치 조건이 이미 거짓이므로 생략 가능|
|SPA 응답 비교|후보=루트=없는 경로인 HTML인지 확인|두 실제 응답을 모두 확보한 경우에만 SPA 판정. 하나만으로 PASS로 확정하지 않음|
|API 9개 후보 GET|API/Auth 자료 수집|web /admin GET과 URL은 겹치지만 API는 리디렉션 추적·독립 시점 관측. 공유하지 않음|
|CORS 추가 Origin GET|반사 검사|같은 URL이라도 Origin 헤더가 다르므로 별도 요청 유지|
|auth 후보 /api/login,/api/auth|API 관측값 재사용|기존 scan_auth_controls가 API 결과를 이미 재사용하며 /login,/signin만 추가 요청. 개선할 중복이 아님|

전역 캐시·스캔 간 캐시·메서드/헤더/인증/리디렉션 정책을 넘는 재사용은 도입하지 않았다. 응답의 시간 변화·Set-Cookie·동적 콘텐츠·Origin/Authorization 차이를 같은 응답으로 취급하지 않기 위해서다. HTTP 연결/오프너 재사용도 이번 변경 범위가 아니다.

## 최적화 코드

`websecscope/scanner/web.py:_scan_sensitive_paths`에서 루트 GET은 유지하고, 없는 경로 GET은 성공한 후보의 비어 있지 않은 본문이 성공한 루트 GET 본문과 정확히 같을 때에만 한 번 요청한다. 이 대조군은 해당 함수 호출 안에서 나머지 후보에 재사용하며 호출이 끝나면 폐기한다. 기존에도 대조군은 스캔당 한 번 관측했으며 이번에는 그 시점이 첫 관련 후보 뒤로 이동한다. 후보별 요청 순서 HEAD→GET은 유지한다.

`_classify_sensitive_response`의 catch-all 조건에 `len(controls)==2`를 추가해 대조군 하나만으로 SPA 확정하는 것을 막았다. 기존 판정 형식·임계값은 유지했다. metadata.missing_control_requested와 control_policy를 추가해 요청 생략을 명시한다. 계획된 조건부 생략은 네트워크 오류가 아니며, 실제 요청한 대조군/후보의 오류와 complete=false는 계속 기록한다.

`tests/test_sensitive_paths_content.py`는 mock 응답을 호출 순번 대신 URL로 배정하도록 바꿨다. 기존 24개 테스트의 보안 기대값은 바꾸지 않았다. `tests/test_request_optimization.py`에 5개 테스트를 추가하여 요청 수, 두 대조군 유지, 관련 대조군 오류, 스캔 사이 상태 변화, 실제 로컬 HTTP의 Origin/Authorization 변화와 동일 헤더 반복 시 본문 변화를 검증한다. 기존 44개를 모두 포함한다. 다른 프로덕션 모듈은 변경하지 않았다.

## 정확도: 동일 38개 보안 사례

|지표|1차 개선|2차 최적화|
|---|---|---|
'''
    fmt=lambda v:'N/A' if v is None else f'{v*100:.2f}%'
    for key in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','abstained','errors'):
        f=fmt if key in {'precision','recall','fpr','accuracy','coverage'} else str
        report+=f"|{key}|{f(before['metrics'][key])}|{f(after['metrics'][key])}|\n"
    report+=f"|WARNING=오답 보수적 Accuracy|(12+15)/38 = {fmt(before['conservative_accuracy'])}|(12+15)/38 = {fmt(after['conservative_accuracy'])}|\n"
    report+='''
기본 이진 분모는 32개, Coverage는 32/38이다. WARNING 6개는 기본 지표에서 제외되지만 보수적 Accuracy에서는 오답이다. 가용성 3개는 정확도 분모에 원래부터 포함하지 않는다. 전체 41개 × 3회 = 123회 모두 선택 상태·집계가 1차와 동일하다. 루트에 도달한 117회에서 후보별 HEAD/GET 상태·오류·Location·본문 길이/해시·개별 outcome 및 reason도 모두 동일하다. API/Auth finding도 123회 모두 같다. 대조군 요청 유무 metadata 차이는 의도한 변경이다.

## 요청 수·성능 (동일 41개 사례)

|항목|1차 개선|2차 최적화|
|---|---|---|
'''
    report+=f"|총 논리 HTTP 요청|{before['requests']}|{after['requests']}|\n"
    report+=f"|fixture 서버에서 기록한 실제 요청|{before['server_observed_requests']}|{after['server_observed_requests']}|\n"
    for key,label in [('total','전체 혼합')]:
        b,a=before['timing'][key],after['timing'][key]
        report+=f"|{label} 평균(초)|{b['mean']:.6f}|{a['mean']:.6f}|\n|{label} P95(초)|{b['p95']:.6f}|{a['p95']:.6f}|\n"
    for k in ('mean','p95'):
        report+=f"|장애 제외 {k}(초), 각114회|{before['non_fault'][k]:.6f}|{after['non_fault'][k]:.6f}|\n"
    saved=before['requests']-after['requests']
    report+=f"\n요청 {saved}건 ({saved/before['requests']*100:.2f}%) 감소. 전체 평균 변화 {(after['timing']['total']['mean']/before['timing']['total']['mean']-1)*100:+.2f}%, 장애 제외 평균 변화 {(after['non_fault']['mean']/before['non_fault']['mean']-1)*100:+.2f}%. 감소 폭이 작거나 실행 시간이 늘어난 항목도 그대로 기록했다.\n"
    report+='\n논리 요청 수는 baseline의 request 래퍼 호출 수이며 연결 실패 시도도 포함한다. 서버 기록은 도착한 응답 처리 이벤트이며, API의 자동 리디렉션 후속 요청도 포함하므로 두 수는 같지 않다. TCP 재시도/패킷 수를 측정한 것은 아니다.\n'
    report+='\n|모듈|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|\n|---|---|---|---|---|\n'
    for name,b in before['timing']['modules'].items():
        a=after['timing']['modules'][name]
        report+=f"|{name}|{b['mean']:.6f}|{a['mean']:.6f}|{b['p95']:.6f}|{a['p95']:.6f}|\n"
    report+='\n|사례|전 요청/회|후 요청/회|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|선택 판정 변화|\n|---|---|---|---|---|---|---|---|\n'
    for c in new['cases']:
        oldrows=[r for r in old['runs'] if r['case_id']==c['id']]
        newrows=[r for r in new['runs'] if r['case_id']==c['id']]
        if not newrows:
            continue
        os,ns=stats([r['seconds'] for r in oldrows]),stats([r['seconds'] for r in newrows])
        oq,nq=[len(r['requests']) for r in oldrows],[len(r['requests']) for r in newrows]
        data['case_comparison'].append(dict(id=c['id'],before_requests=oq,after_requests=nq,before_timing=os,after_timing=ns,status=newrows[0]['status'],classification=newrows[0]['classification']))
        report+=f"|{c['id']}|{'/'.join(map(str,oq))}|{'/'.join(map(str,nq))}|{os['mean']:.6f}|{ns['mean']:.6f}|{os['p95']:.6f}|{ns['p95']:.6f}|동일 ({newrows[0]['status']})|\n"
    report+='\n각 요청/회 셀은 반복1/2/3의 실제 수이다. SPA 사례는 없는 경로 대조군을 유지하며, 루트 도달 실패는 기존처럼 민감 경로 검사를 시작하지 않는다.\n'
    report+='\n## 성능 전용 실험 (정확도 표본과 분리)\n\n|웹 진단 30회씩|평균(초)|P95(초)|실제 요청/회|\n|---|---|---|---|\n'
    for name,label in [('before','1차 소스 스냅샷'),('after','2차 현재 소스')]:
        s=perf['summary'][name]
        reqs=sorted({r['requests'] for r in perf['rows'] if r['variant']==name})
        report+=f"|{label}|{s['mean']:.6f}|{s['p95']:.6f}|{reqs}|\n"
    report+=f"\n짝지은 평균 시간 변화 {(perf['summary']['after']['mean']/perf['summary']['before']['mean']-1)*100:+.2f}%. 같은 루프백 fixture 서버(민감 경로 모두404)에서 30쌍/60회, 순서를 번갈아 실행했고 warmup을 제외하지 않았다. API/Auth는 제외한 웹 전용 실험이며 전체 진단의 결과로 일반화하지 않는다. 개별 측정값·실행 순서는 [performance.json](performance.json)의 rows에 있다.\n"
    report+='''
## 해석·부작용·남은 한계

대조군 요청을 하나 줄이는 범위만 적용했으므로 요청·시간 개선 폭이 제한된다. 서로 다른 시점의 전체 재측정은 머신 부하/계측 비용의 영향을 받으며 모든 시간 차이를 최적화 효과로 단정할 수 없다. 별도 교차 실행 실험이 이를 보완하지만 한 가지 404 프로파일에 한정된다. P95는 nearest-rank다. 전체 혼합 P95는 의도적 timeout/연결 오류에 지배될 수 있다.

스캔 단위 대조군 표본은 관측 시점의 응답이며 정적 안전성을 보장하지 않는다. 없는 경로 GET 시점이 지연되므로 시간에 따라 바뀌는 서버에서 이전 버전과 완전히 동일한 관측을 보장할 수는 없다. 스캔 간 캐시가 없다는 테스트와 별개로 스캔 도중 dynamic shell/nonce 변화는 WARNING이 될 수 있다. 원래 4096바이트 표본 비교와 형식 휴리스틱의 오탐·미탐 한계는 유지된다.

루트와 후보가 서로 다른 경우에는 없는 경로 검증이 판정에 영향을 줄 수 없어 수행하지 않는다. 따라서 그 미요청 경로의 서버 오류까지 별도로 감시하는 기능은 제공하지 않는다. 그 요청을 생략하면서 관측했다고 주장하지 않는다. 후보 자체의 HTTP 500·연결 오류·timeout은 그대로 관측한다. 두 대조군을 요구하는 SPA 판정 근거는 줄이지 않았다.

헤더 H-13/H-14, 쿠키 C-03/C-04 미탐과 API 관리자 SPA A-04 오탐, 401/403·리디렉션·일부 CORS 보류는 남아 있다. 이번 최적화로 이들을 해결했다고 주장하지 않는다. 테스트·고정 표본의 탐지 근거와 지표가 유지되어 헤더·쿠키 개선 단계를 진행할 수 있다. 현재 결과만으로 다른 실제 서버의 정확도 유지나 운영 배포 적합성을 보장할 수 없으며 후속 변경도 독립 측정해야 한다.

## 테스트·실행 환경·검증

'''
    report+='```text\n'+(OUT/'results/regression.log').read_text(encoding='utf-8')+'\n```\n'
    report+='```text\n'+(OUT/'results/verification.log').read_text(encoding='utf-8')+'\n```\n'
    report+=f"\n전체 측정 환경: {new['platform']}, Python {new['python']}, 생성 시각 {new['generated_at']} (UTC). 전체 진단 타이밍은 서버 시작/종료/파일 저장/pytest를 제외한 기존 baseline.py run_scan 구간이다. Security Score는 원시 JSON/CSV의 기존 별도 필드로 보존한다.\n"
    report+='''
- [전체 원시 JSON](results/baseline_results.json), [CSV](results/baseline_summary.csv), [실행 로그](results/execution.log), [검증 로그](results/verification.log)
- [기계 판독 비교 JSON](comparison.json), [성능 전용 원시 기록](performance.json), [실행 전 보존 manifest](before/manifest.json)
- 재현: `python tools/validation/optimize_requests.py preserve`, 소스 변경 후 `python tools/validation/optimize_requests.py run`, 완료 후 `python tools/validation/optimize_requests.py perf`, `python tools/validation/report_optimization.py`. 기존 결과 덮어쓰기를 피하려면 새 OUT 디렉터리를 지정한다. 기존 baseline.py는 직접 실행하면 원래 results를 덮어쓸 수 있으므로 이 wrapper를 사용한다.
- 읽기 전용 재검증: `python tools/validation/verify.py --results docs/validation/improvement_02/results`.
- 신규 파일: `tests/test_request_optimization.py`, `tools/validation/optimize_requests.py`, `tools/validation/report_optimization.py` 및 improvement_02 산출물. 기존 검증 도구 verify.py와 fixture는 이번 단계에 변경하지 않았다.
'''
    (OUT/'comparison.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    (OUT/'comparison.md').write_text(report,encoding='utf-8')
    log='PASS: historical artifacts unchanged; 41 cases and contracts unchanged; 123 statuses/classifications unchanged; 117 detailed HEAD/GET path observations unchanged; API/Auth findings unchanged; current source hashes verified.\n'
    (OUT/'audit.log').write_text(log,encoding='utf-8')
    print(log)
    print(json.dumps(dict(before=before,after=after),indent=2))


if __name__=='__main__':
    main()
