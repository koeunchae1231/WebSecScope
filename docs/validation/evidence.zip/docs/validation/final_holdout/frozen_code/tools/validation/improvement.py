"""Preserve v1, rerun its unchanged harness, and compare measured artifacts."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

import baseline

ROOT = baseline.ROOT
DOC = ROOT / 'docs/validation'
ARCHIVE = DOC / 'baseline_v1'
AFTER = DOC / 'improvement_01/results'


def preserve():
    if ARCHIVE.exists():
        raise SystemExit('Archive already exists; refusing to overwrite v1.')
    required = [ROOT/'tools/validation'/name for name in ('baseline.py','report.py','verify.py')]
    required += list((DOC/'results').glob('*'))
    required += [DOC/name for name in ('01_baseline.md','02_test_methodology.md','03_results_before.md')]
    required += list((ROOT/'websecscope').rglob('*.py')) + list((ROOT/'tests').rglob('*.py'))
    assert all(p.is_file() for p in required)
    result = subprocess.run([sys.executable, str(ROOT/'tools/validation/verify.py')], cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        raise SystemExit(result.stdout+result.stderr)
    manifest = {}
    for src in required:
        rel = src.relative_to(ROOT)
        dest = ARCHIVE/rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        manifest[rel.as_posix()] = hashlib.sha256(src.read_bytes()).hexdigest()
    (ARCHIVE/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (ARCHIVE/'verification_before_changes.log').write_text(result.stdout+result.stderr, encoding='utf-8')
    (ARCHIVE/'git_before_changes.log').write_text(subprocess.check_output(['git','status','--short'], cwd=ROOT, text=True), encoding='utf-8')
    print(f'Preserved {len(manifest)} files and successful v1 verification under {ARCHIVE}')


def check_archive():
    manifest = json.loads((ARCHIVE/'manifest.json').read_text(encoding='utf-8'))
    for rel, digest in manifest.items():
        assert hashlib.sha256((ARCHIVE/rel).read_bytes()).hexdigest() == digest, rel
    return manifest


def run():
    check_archive()
    assert (ARCHIVE/'tools/validation/baseline.py').read_bytes() == (ROOT/'tools/validation/baseline.py').read_bytes()
    if AFTER.exists():
        raise SystemExit('After results already exist; refusing to overwrite measured data.')
    AFTER.mkdir(parents=True)
    baseline.OUT = AFTER
    with (AFTER/'execution.log').open('w', encoding='utf-8') as log, contextlib.redirect_stdout(log):
        baseline.main()
    data = json.loads((AFTER/'baseline_results.json').read_text(encoding='utf-8'))
    before = json.loads((ARCHIVE/'docs/validation/results/baseline_results.json').read_text(encoding='utf-8'))
    assert data['cases'] == before['cases']
    data['invocation'] = [sys.executable, 'tools/validation/improvement.py', 'run']
    data['harness_output_override'] = str(AFTER.relative_to(ROOT))
    (AFTER/'baseline_results.json').write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    verify = subprocess.run([sys.executable, 'tools/validation/verify.py', '--results', str(AFTER)], cwd=ROOT, capture_output=True, text=True)
    (AFTER/'verification.log').write_text(f'Exit code: {verify.returncode}\n'+verify.stdout+verify.stderr, encoding='utf-8')
    print(json.dumps(dict(metrics=data['metrics'], timing=data['timing'], regression_exit_code=data['regression_exit_code'], verification_exit_code=verify.returncode), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['preserve','run'])
    action = parser.parse_args().action
    preserve() if action == 'preserve' else run()
