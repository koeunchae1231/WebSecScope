"""Freeze and evaluate a new synthetic holdout without modifying the scanner."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/validation/final_holdout'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, value):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')


def freeze():
    OUT.mkdir(exist_ok=False)
    sources = [p for folder in ('websecscope', 'tests', 'tools/validation')
               for p in (ROOT / folder).rglob('*.py')]
    sources += [ROOT / name for name in ('main.py', 'pytest.ini', 'requirements.txt', '.gitignore', 'README.md', 'README_EN.md')]
    manifest = {}
    for p in sources:
        rel = p.relative_to(ROOT)
        dest = OUT / 'frozen_code' / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
        manifest[str(rel)] = sha(p)
    save(OUT / 'source_hashes.json', manifest)
    old = [p for p in (ROOT / 'docs/validation').rglob('*') if p.is_file()
           and OUT not in p.parents and '__pycache__' not in p.parts]
    with ThreadPoolExecutor(max_workers=8) as pool:
        historical = dict(pool.map(lambda p: (str(p.relative_to(ROOT)), sha(p)), old))
    save(OUT / 'historical_hashes.json', historical)
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=ROOT, text=True)
    save(OUT / 'freeze.json', dict(frozen_at=datetime.now(timezone.utc).isoformat(),
        branch=git('branch', '--show-current').strip(), commit=git('rev-parse', 'HEAD').strip(),
        dirty_status=git('status', '--short'), python=sys.version, executable=sys.executable,
        platform=platform.platform(), dependencies=subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'], text=True),
        policy_schema=1, score_policy='scope-risk-v2-explicit-skip-v1',
        designation='코드 동결 후 생성한 신규 합성 홀드아웃 평가', external_independence=False))
    result = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
        '--basetemp='+str(OUT / 'tmp-tests')], cwd=ROOT, capture_output=True, text=True)
    (OUT / 'pytest_frozen.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    save(OUT / 'pytest_frozen.json', dict(exit_code=result.returncode, command=result.args))
    assert result.returncode == 0
    check_code()
    print('Code frozen before new case creation; pytest passed.')


def check_code():
    manifest = json.loads((OUT / 'source_hashes.json').read_text(encoding='utf-8'))
    for rel, digest in manifest.items():
        assert sha(ROOT / rel) == sha(OUT / 'frozen_code' / rel) == digest, rel


if __name__ == '__main__':
    {'freeze': freeze, 'check': check_code}[sys.argv[1]]()
