"""Audit and report phase 4 without changing baseline cases or scoring policy."""
import json
import subprocess
from pathlib import Path

from api_auth_validation import ROOT, OUT, frozen, sha
from baseline import stats
from report_header_cookie import summary


def main():
    frozen()
    old_path = ROOT / 'docs/validation/improvement_03/results/baseline_results.json'
    new_path = OUT / 'results/baseline_results.json'
    old, new = [json.loads(p.read_text(encoding='utf-8')) for p in (old_path, new_path)]
    assert old['cases'] == new['cases']
    assert new['regression_exit_code'] == 0 and new['production_and_existing_tests_unchanged']
    before = {(r['case_id'], r['repeat']): r for r in old['runs']}
    assert len(before) == len(new['runs']) == 123
    changed = set()
    comparisons = []
    for r in new['runs']:
        previous = before[r['case_id'], r['repeat']]
        if (r['status'], r['classification']) != (previous['status'], previous['classification']):
            changed.add(r['case_id'])
        assert [f for f in previous['findings'] if f['category'] == 'web'] == [
            f for f in r['findings'] if f['category'] == 'web'], (r['case_id'], r['repeat'])
        if r['repeat'] == 1:
            comparisons.append(dict(id=r['case_id'], before_status=previous['status'], after_status=r['status'],
                                    before_classification=previous['classification'], after_classification=r['classification']))
    assert changed == {'A-04'}, changed
    for case in new['cases']:
        assert len({(r['status'], r['classification']) for r in new['runs'] if r['case_id'] == case['id']}) <= 1
    for name, digest in new['source_hashes'].items():
        assert sha(ROOT / name) == digest, name
    changed_files = [Path(rel).as_posix() for rel, digest in json.loads(
        (OUT / 'before/manifest.json').read_text(encoding='utf-8')).items() if sha(ROOT / rel) != digest]
    assert set(changed_files) == {'websecscope/scanner/api_scanner.py', 'websecscope/analyzer/api_auth_analyzer.py'}
    b, a = summary(old), summary(new)
    request_deltas = {c['id']: sum(len(r['requests']) - len(before[r['case_id'], r['repeat']]['requests'])
                                  for r in new['runs'] if r['case_id'] == c['id']) for c in new['cases']}
    audit = dict(before=b, after=a, changed_existing_files=changed_files, changed_cases=sorted(changed),
                 case_comparison=comparisons, request_deltas=request_deltas,
                 immutable_history=True, unchanged_cases_and_policy=True, unchanged_web_findings=True,
                 before_sha256=sha(old_path), after_sha256=sha(new_path))
    (OUT / 'comparison.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    percent = lambda v: 'N/A' if v is None else f'{100*v:.2f}%'
    report = '''# 4차 개선: API/Auth 진단

## 1. 기존 검사 문제와 데이터 흐름

작업 브랜치는 `improve/sensitive-path-validation`이다. main 병합은 수행하지 않았다.
`api_scanner.scan_api_endpoints`가 9개 후보에 무인증 GET을 수행하여 상태·헤더·쿠키·본문 샘플을 수집하고, CORS 헤더가 있으면 Origin 요청을 추가한다.
`auth_scanner.scan_auth_controls`는 API의 login/auth 관측 객체를 재사용하며 /login·/signin을 추가 수집한다.
`analyze_api_auth`가 관리자·문서 노출, 인증, 쿠키, JWT, CORS, IDOR 및 rate-limit 관측을 Finding으로 변환한다.
웹의 `rules/web/cookie_values.cookie_attributes`는 별도의 구조적 속성 파서였다.

기존 관리자 검사는 admin 경로의 성공 상태만으로 FAIL을 생성하여 공개 SPA도 노출로 오인했다.
Origin 반사는 항상 WARNING이었고 비공개 응답 근거와 credentials를 결합하지 않았다. O-02 설명은 브라우저의 credentialed wildcard 차단 동작을 잘못 표현했다.
API 쿠키 검사는 문자열 포함 여부에 의존하고 /login·/signin에서만 발급된 쿠키를 분석에서 빠뜨렸다.
요청 실패로 쿠키/CORS 관측이 불완전해도 정상으로 보일 수 있었다.

## 2. 변경 파일과 함수

- `scanner/api_scanner.py:scan_api_endpoints`: 관리자 HTML이 성공한 경우에만 루트·임의의 없는 경로 GET 두 개를 추가하고, 두 응답과 완전한 HTML이 일치하면 공개 shell로 분류한다. 4096바이트 이후 한 바이트를 더 읽어 잘린 공통 prefix를 완전 일치로 오인하지 않는다. Origin 반사가 처음 관측되면 다른 출처로 두 번째 확인을 수행한다. 요청 오류·최종 URL·리디렉션·본문 잘림과 probe 관측을 기록한다.
- `_request_observation_direct`: HTTPError 응답의 본문 읽기 오류도 기록한다. 네이티브 1초 timeout과 외부 1.5초 deadline은 유지한다.
- 새 `rules/api_evidence.py`: `response_kind`, `private_response`, `public_response`, `html_response`. 인증 요구·거부·없음·리디렉션·오류·공개 shell·비공개 근거·불명확 응답을 구분한다. 비공개 근거는 비어 있지 않은 본문에 대한 명시적 Cache-Control private 또는 JSON의 일반적인 비공개/자격 증명 필드이다. 이름 규칙은 fixture와 무관한 휴리스틱이며 값은 finding 근거에 복사하지 않는다.
- `analyzer/api_auth_analyzer.py`: `_analyze_endpoint_exposure`, `_analyze_auth_access`, `_analyze_cookie_security`, `_analyze_cors`, `analyze_api_auth`를 개선했다. 기존 Finding/check_id/orchestrator 인자는 유지하고 관측 JSON과 metadata에 필드만 추가했다. 공개 shell 인증 관측에만 `AUTH_PUBLIC_SHELL_*`를 추가한다. 문서 결과와 관리자 baseline은 별도로 출력한다.
- `tests/test_api_auth_evidence.py`: 단위 및 실제 loopback 서버 기반 경계 검증. `tools/validation/api_auth_validation.py`, `report_api_auth.py`: 별도 보존·측정·감사 도구.

## 3. A-04 및 O-03

A-04는 루트 및 없는 경로와 같은 공개 HTML이므로 FAIL/FP에서 PASS/TN으로 바뀐다. A-03은 관리자 경로의 비공개 JSON 근거로 FAIL을 유지한다.
HTTP 200만 있고 관리자 데이터 근거가 없거나 리디렉션·서버 오류·요청 실패이면 WARNING이다. 401·403은 해당 무인증 요청이 거부되었다는 관측이며 우회 불가능성을 보장하지 않는다.

O-03은 기존과 동일하게 WARNING/ABSTAIN이다. 고정 fixture의 O-01·O-03·O-04는 본문이 같고 O-03에 별도의 비공개 응답 근거가 없다. 정답 vulnerable=true는 변경하지 않았다.
새 경계 테스트에서는 서로 다른 두 Origin 모두 정확히 반사되고, credentials의 값이 정확한 소문자 true이며, 성공한 비리디렉션 응답 각각에 독립적인 비공개 근거가 있을 때만 FAIL로 판정한다. 단일 반사·credentials 누락/잘못된 값·공개/불명확 본문·실패한 probe는 WARNING이다.
실제 인증 쿠키를 보내거나 브라우저 악용을 검증하지 않았으므로 FAIL도 관측된 설정 결함과 비공개로 표시된 응답의 조합을 뜻한다.

O-02는 FAIL을 유지하되 wildcard+credentials 설정 결함과 실제 브라우저 읽기를 구분한다. 이 조합의 credentialed 응답 읽기는 브라우저가 차단한다. [Fetch 표준](https://fetch.spec.whatwg.org/#cors-protocol-and-credentials)을 근거로 설명을 수정했다.
O-04도 기존처럼 WARNING이다. 명시적인 공개 Cache-Control 및 비공개 근거 부재가 추가 확인된 신규 사례는 wildcard/no credentials를 PASS로 처리한다. 단순 wildcard만으로 공개 데이터라고 추정하지 않는다.

## 4. 쿠키 통합과 호환성

기존 `cookie_attributes`를 그대로 호출하며 복제 파서는 만들지 않았다. 웹 파서와 웹 검사는 변경하지 않았다.
기존 `AUTH_COOKIE_ATTRIBUTES` 한 개로 집계하고, 보안 속성 누락·잘못된 SameSite·None/Secure 의존성 위반은 FAIL, 중복/충돌/값을 가진 flag 등 모호한 설정은 WARNING이다. 대소문자와 복수 Set-Cookie, 쿠키 값에만 등장하는 속성 키워드를 구분한다.
API 후보와 추가 Auth 후보 모두 검사한다. 재사용된 API 관측 객체는 중복 집계하지 않는다. Set-Cookie가 없으면 관측 범위에서 PASS이지만 요청 오류가 있으면 WARNING이다.
따라서 문자열 검사에서 통과하던 잘못된 속성은 FAIL/WARNING으로 바뀌며 추가 Auth 경로 때문에 기존 점수가 달라질 수 있다. JSON 필드는 유지하고 세부 오류와 parser 결과를 metadata에 추가했다. 속성 존재와 실제 브라우저 보호 적용은 구분한다.

## 5. 정확도: 고정 38개 보안 사례

첫 번째 반복만 집계한다. WARNING=ABSTAIN, ERROR 별도, 분모 0=N/A 정책과 모든 fixture/정답을 유지했다. 가용성 3개는 제외하고, 미지원 선언 U-01은 실행하지 않는다.
기본 Precision/Recall/Accuracy는 이진 판정 범위의 조건부 지표다. WARNING=음성은 보류를 취약 FN/정상 TN으로 치환하고 보수적 Accuracy는 모든 보류·오류를 오답으로 취급하여 (TP+TN)/38이다.

|지표|3차|4차|
|---|---:|---:|
'''
    for key in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','abstained','errors'):
        fmt = percent if key in {'precision','recall','fpr','accuracy','coverage'} else str
        report += f"|{key}|{fmt(b['metrics'][key])}|{fmt(a['metrics'][key])}|\n"
    report += f"|WARNING=음성 Accuracy|{percent(b['warning_negative']['accuracy'])}|{percent(a['warning_negative']['accuracy'])}|\n"
    report += f"|WARNING=오답 보수적 Accuracy|{percent(b['conservative_accuracy'])}|{percent(a['conservative_accuracy'])}|\n"
    report += '''
고정 사례에서 바뀐 판정은 A-04 하나뿐이다. 새 FP·ABSTAIN·ERROR는 없고 보류 수와 Coverage는 동일하다. 정확도 개선이 보류 증가로 발생한 것은 아니다. 보류 6개는 P-03/P-04/P-08/P-09/O-03/O-04이다. O-03은 취약하지만 보류하므로 조건부 Recall 100%를 전체 취약 사례 탐지율로 해석하면 안 된다.

## 6. 성능: 동일 41개 × 3회

같은 Python·OS·timeout·후보·반복·계측을 사용했다. 전체 실행 시간은 실제 scan 시간이며 fixture 준비/종료와 pytest를 제외한다. P95는 nearest-rank이다. 장애 제외는 E-01~E-03을 제외한 114회이다.

|항목|3차|4차|
|---|---:|---:|
'''
    for key in ('requests','server_requests','request_errors','timeout_errors','scan_exceptions'):
        report += f'|{key}|{b[key]}|{a[key]}|\n'
    for key in ('mean','p95'):
        report += f"|전체 {key} (초)|{b['timing']['total'][key]:.6f}|{a['timing']['total'][key]:.6f}|\n"
        report += f"|장애 제외 {key} (초)|{b['non_fault'][key]:.6f}|{a['non_fault'][key]:.6f}|\n"
        for module in ('scan_web_target','scan_api_endpoints','scan_auth_controls','analyze_api_auth'):
            report += f"|{module} {key} (초)|{b['timing']['modules'][module][key]:.6f}|{a['timing']['modules'][module][key]:.6f}|\n"
    report += '\n논리 요청 수 증가(사례별 3회 합계): ' + ', '.join(f'{k}: +{v}' for k,v in request_deltas.items() if v) + '.\n'
    report += '''
공개 SPA가 나타나는 P-05/A-04는 관리자 HTML 비교용 두 요청씩, O-03은 반사 확인용 한 요청씩 추가된다. 나머지 요청 수는 동일하다. 서버 요청 수는 리디렉션 hop을 포함하며 연결 거부처럼 서버에 도달하지 못한 요청은 포함하지 않는다.
네트워크·스케줄링 변동이 있으므로 전체 시간 차이를 파서 CPU 비용만으로 해석하지 않는다. 요청 수 증가가 가장 직접적인 비용이다. 이 비교는 앞선 3차 측정과의 동일 설정 비교이며 교차 순서 paired benchmark는 아니다.

## 7. 전체 pytest와 보존 검증

'''
    report += '```text\n' + (OUT / 'results/regression.log').read_text(encoding='utf-8').strip() + '\n```\n\n'
    report += '''기존 113개 테스트의 소스는 변경하지 않았다. 신규 테스트는 상태만 200인 응답, SPA 두 대조군, 잘린 본문, 관리자 비공개 JSON, 인증/거부/리디렉션, 두 Origin 반사·불완전 probe·credentials 대소문자, 공개 정책, 쿠키 속성과 추가 Auth 경로, 요청 deadline을 검증한다.
실제 loopback 서버 테스트와 독립 단위 테스트를 함께 사용하며 사례 ID나 합성 본문 문자열로 제품 코드를 분기하지 않는다. 브라우저 기반 테스트는 수행하지 않았다.

- [원시 JSON](results/baseline_results.json), [123회 CSV](results/baseline_summary.csv), [실행 로그](results/execution.log), [pytest 로그](results/regression.log), [독립 검증 로그](results/verification.log)
- [비교 원시 데이터](comparison.json), [직전 소스 및 기존 테스트 해시](before/manifest.json), [과거 결과 해시](history_manifest.json)

기존 Baseline v1 및 1~3차 결과 해시, 직전 소스 스냅샷, fixture/정답, 기존 테스트, 반복별 판정 일관성, 모든 웹 Finding 불변, 측정 전후 소스 불변을 검증했다. 결과는 이 디렉터리에만 새로 보존한다.

## 8. 남은 한계

비공개 판단은 Cache-Control과 JSON 필드명의 휴리스틱이다. public 샘플·문서에 secret 필드가 등장하면 오탐 가능성이 있고, 필드가 일반 이름이거나 HTML/바이너리·중첩 10단계 이후에만 비공개 정보가 있으면 놓칠 수 있다. Cache-Control private는 공유 캐시 정책이며 인증 필요성 자체를 증명하지 않는다. 독립적인 데이터 소유권·접근 정책이 없으므로 관리자 FAIL은 검토할 노출 신호이지 권한 우회 성공의 증명이 아니다.
공개 shell은 서로 다른 두 URL의 완전한 HTML 일치라는 제한된 관측이다. 동적 HTML은 일치하지 않아 WARNING이 될 수 있고 동일 HTML에 비공개 정보가 섞인 잘못된 서버 구성도 완전히 구분하지 못한다. 응답 본문 수집은 4096바이트이며 이를 초과한 HTML은 shell로 확정하지 않는다. 리디렉션은 기존 urllib 동작으로 추적하고 최초/최종 URL 차이를 기록하지만 전체 중간 hop 인증 흐름은 분석하지 않는다.
CORS는 실제 로그인 사용자·브라우저·preflight·SameSite·캐시/프록시를 결합한 악용 검증이 아니다. 명시적인 공개/비공개 표시는 앱 정책을 대체하지 않으며 O-03/O-04의 고정 fixture에는 정책을 확정할 독립 증거가 부족하다.
공개 API의 무인증 200에 대한 일반 인증 WARNING, rate-limit 헤더 부재 경고, 문서 정책 판정 등은 이번 작업에서 모두 해결하지 않았다. 쿠키 용도·Domain/Path·접두사·브라우저 저장/전송 정책과 웹 민감 경로 보류 4건도 남아 있다. SQLi 미지원 U-01은 탐지 성공으로 집계하지 않는다.

## 9. 다음 단계

현재 변경은 테스트와 회귀·보존 검증을 통과하여 다음 개선 단계로 진행할 수 있다. 다음에는 정책 입력(공개 API/비공개 경로), 실제 인증 컨텍스트를 제공하는 별도 경계 corpus와 브라우저 검증을 추가하는 것이 적절하다. main 병합은 사용자 확인 전 수행하지 않는다.

## 실행 환경과 재현

'''
    environment = {k:new[k] for k in ('generated_at','python','platform','invocation','repeats')}
    environment['branch'] = subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()
    environment['revision'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    (OUT / 'environment.json').write_text(json.dumps(environment,indent=2),encoding='utf-8')
    report += '```json\n' + json.dumps(environment,indent=2,ensure_ascii=False) + '\n```\n'
    report += '''
측정 명령: `python tools/validation/api_auth_validation.py run` (기존 결과가 있으면 덮어쓰지 않고 중단).
감사/보고 재생성: `python tools/validation/report_api_auth.py`.
독립 결과 검증: `python tools/validation/verify.py --results docs/validation/improvement_04/results`.
보존 단계는 이미 실행했으며 `preserve`를 재실행하지 않는다.
'''
    (OUT / 'README.md').write_text(report,encoding='utf-8')
    (OUT / 'audit.log').write_text('PASS: historical files, snapshots, existing tests, baseline cases and policy unchanged.\n'
                                 'PASS: 123 runs, stable classifications, only A-04 changed, web findings identical.\n'
                                 'PASS: measured source hashes and regression exit code.\n',encoding='utf-8')
    print(json.dumps(dict(before=b,after=a,changed_cases=sorted(changed),requests=request_deltas),indent=2))


if __name__ == '__main__':
    main()
