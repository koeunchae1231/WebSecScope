"""Reanalyze the immutable 38-case cohort and record test-only revalidation."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from baseline import ROOT, metrics, stats
from improvement import ARCHIVE, AFTER, check_archive

DEST = AFTER.parent / 'revalidation'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(name, args):
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    proc = subprocess.run([sys.executable, *args], cwd=ROOT, capture_output=True,
                          text=True, encoding='utf-8', errors='replace', env=env)
    (DEST/name).write_text('Command: '+json.dumps(args)+'\nExit code: '+str(proc.returncode)+'\n'+proc.stdout+proc.stderr, encoding='utf-8')
    return proc.returncode


def evaluate(data):
    cohort = {c['id']:c for c in data['cases'] if c['vulnerable'] is not None and c['family'] != 'unsupported'}
    rows = [r for r in data['runs'] if r['repeat']==1 and r['case_id'] in cohort]
    assert len(cohort) == len(rows) == len({r['case_id'] for r in rows}) == 38
    assert all(r['classification'] in {'TP','FP','FN','TN','ABSTAIN','ERROR'} for r in rows)
    binary = metrics(rows)
    negative, conservative = [], []
    for r in rows:
        vulnerable = cohort[r['case_id']]['vulnerable']
        # An ERROR is never silently turned into a successful negative prediction.
        neg = ('FN' if vulnerable else 'TN') if r['classification']=='ABSTAIN' else r['classification']
        penalty = ('FN' if vulnerable else 'FP') if r['classification'] in {'ABSTAIN','ERROR'} else r['classification']
        negative.append(dict(classification=neg))
        conservative.append(dict(classification=penalty))
    penalized = metrics(conservative)
    return dict(binary=binary, warning_negative=metrics(negative), conservative=penalized,
                conservative_correct_over_38=(binary['TP']+binary['TN'])/38), rows


def main():
    if (DEST/'analysis.json').exists():
        raise SystemExit('Refusing to overwrite prior revalidation; choose a new DEST for another run.')
    DEST.mkdir(parents=True, exist_ok=True)
    manifest = check_archive()
    frozen = {p:sha(p) for folder in (ROOT/'docs/validation/results', AFTER, ARCHIVE)
              for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    bpath = ARCHIVE/'docs/validation/results/baseline_results.json'
    apath = AFTER/'baseline_results.json'
    before, after = [json.loads(p.read_text(encoding='utf-8')) for p in (bpath,apath)]
    assert before['cases'] == after['cases']
    assert sha(ROOT/'tools/validation/baseline.py') == manifest['tools/validation/baseline.py']
    assert sha(ROOT/'tools/validation/report.py') == manifest['tools/validation/report.py']
    # Native detection code and every measured test except the explicitly authorized one must match.
    for name, digest in after['source_hashes'].items():
        if Path(name).as_posix() != 'tests/test_http_status.py':
            assert sha(ROOT/name) == digest, name
    current = {str(p.relative_to(ROOT)):sha(p) for folder in ('websecscope','tests') for p in (ROOT/folder).rglob('*.py')}
    test_key = next(k for k in after['source_hashes'] if Path(k).as_posix()=='tests/test_http_status.py')
    pytest_exit = command('pytest.log', ['-m','pytest','-q','-p','no:cacheprovider'])
    v1_exit = command('v1_verification.log', [str(ARCHIVE/'tools/validation/verify.py')])
    record = dict(measurement_sha256=sha(apath), current_source_hashes=current,
                  authorized_test_changes={'tests/test_http_status.py':dict(before=after['source_hashes'][test_key], after=sha(ROOT/test_key))},
                  pytest_exit_code=pytest_exit, pytest_log=str((DEST/'pytest.log').relative_to(ROOT)), pytest_log_sha256=sha(DEST/'pytest.log'))
    (DEST/'revalidation.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    # Preserve strict historical failure as evidence, then run explicit current revalidation.
    strict_exit = command('historical_strict_verify.log',['tools/validation/verify.py','--results',str(AFTER)])
    verify_exit = command('current_verification.log',['tools/validation/verify.py','--results',str(AFTER),'--revalidation',str(DEST/'revalidation.json')])
    bm, br = evaluate(before)
    am, ar = evaluate(after)
    for recalculated, measured in ((bm['binary'],before['metrics']), (am['binary'],after['metrics'])):
        # The 3 availability cases have been removed from this fixed security cohort.
        assert recalculated['excluded'] == 0 and measured['excluded'] == 3
        assert {k:v for k,v in recalculated.items() if k!='excluded'} == {k:v for k,v in measured.items() if k!='excluded'}
    changes = []
    for old,new in zip(br,ar):
        assert old['case_id']==new['case_id']
        changes.append(dict(case_id=old['case_id'],before_status=old['status'],after_status=new['status'],
                            before_classification=old['classification'],after_classification=new['classification']))
    def performance(d):
        return dict(requests=sum(len(r['requests']) for r in d['runs']), timing=d['timing'],
                    non_fault=stats([r['seconds'] for r in d['runs'] if not r['case_id'].startswith('E-')]),
                    request_errors=d['request_errors'],timeout_errors=d['timeout_errors'],scan_exceptions=d['scan_exceptions'])
    bp,ap = performance(before),performance(after)
    assert all(sha(p)==digest for p,digest in frozen.items())
    assert check_archive() == manifest
    payload = dict(cohort_size=38, before=bm,after=am,case_comparison=changes,before_performance=bp,after_performance=ap,
                   pytest_exit_code=pytest_exit,v1_verification_exit_code=v1_exit,historical_strict_verify_exit_code=strict_exit,
                   current_verification_exit_code=verify_exit,original_artifacts_unchanged=True,
                   input_hashes={str(p.relative_to(ROOT)):digest for p,digest in frozen.items()})
    (DEST/'analysis.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    fmt = lambda value:'N/A' if value is None else f'{value*100:.2f}%'
    report = '''# 1차 개선 검증 및 회귀 테스트 정리

## 결론과 실패 원인

작업 브랜치 `improve/sensitive-path-validation`에서 수행했다. 진단 소스는 이번 단계에서 수정하지 않았다. 이전 실패는 `tests/test_http_status.py::test_sensitive_path_200_is_exposed`로, 본문 없는 mock 응답 200에 FAIL/HIGH 및 exposed 증거를 요구했다. 실제는 WARNING/LOW, metadata.paths[0].outcome=unconfirmed였다. 이는 **기존 구현 방식에 종속된 테스트**이며 실제 회귀 결함이 아니다.

이전 `_scan_sensitive_paths`는 상태 200을 곧바로 exposed로 취급했다. 현재 `_classify_sensitive_response`는 GET의 파일 형식 근거가 없으면 unconfirmed를 반환하고 `_scan_sensitive_paths`는 WARNING/LOW로 집계한다. 새 요구사항 “HEAD 200만으로 확정 금지”, “HTTP 200을 무조건 FAIL 처리 금지”, “근거 부족은 WARNING”에 일치한다. 따라서 FAIL로 되돌리면 오히려 요구사항을 위반한다. 실제 환경 파일·Git 참조·ZIP·PHP 진단 내용의 노출을 FAIL로 검증하는 별도 24개 신규 회귀 사례는 그대로 유지했다.

수정한 테스트 이름은 `test_sensitive_path_200_without_content_requires_review`다. mock·후보·상태 코드를 유지하고, FAIL→WARNING, HIGH→LOW, exposed 문자열→unconfirmed 및 근거 부족 설명 검증으로 갱신했다. 테스트를 삭제하거나 xfail 처리하지 않았다. 원본은 v1 스냅샷의 동일 파일에 보존되어 있고 Git diff로 기대값 변경을 확인할 수 있다.

## 동일 38개 보안 사례 재분석

v1과 개선 후 JSON의 cases 전체가 동일함을 확인했다. 보안 정답이 정의된 38개 고유 사례만 사용하고 각 첫 회를 한 번 집계했다. 동일한 가용성 3개·미지원 선언 1개 제외를 유지했다. 반복 123회를 정확도 표본으로 부풀리지 않았다. 원래 fixture·정답·후보·타임아웃·기본 판정 정책은 변경하지 않았다.

|정책|시점|TP|FP|FN|TN|Precision|Recall|FPR|Accuracy|
|---|---|---|---|---|---|---|---|---|---|
'''
    for label,key in [('기본 이진','binary'),('WARNING=음성','warning_negative'),('보류/오류=오답 벌점','conservative')]:
        for tag,m in [('v1',bm),('개선 후',am)]:
            v=m[key]
            report+=f"|{label}|{tag}|{v['TP']}|{v['FP']}|{v['FN']}|{v['TN']}|{fmt(v['precision'])}|{fmt(v['recall'])}|{fmt(v['fpr'])}|{fmt(v['accuracy'])}|\n"
    report+='\n|시점|전체 보안 사례|이진 분모|Coverage|ABSTAIN|ERROR|보수적 정답/38|\n|---|---|---|---|---|---|---|\n'
    for tag,m in [('v1',bm),('개선 후',am)]:
        v=m['binary']
        report+=f"|{tag}|38|{sum(v[k] for k in ('TP','FP','FN','TN'))}|{fmt(v['coverage'])}|{v['abstained']}|{v['errors']}|{v['TP']+v['TN']}/38 ({fmt(m['conservative_correct_over_38'])})|\n"
    report+='''
기본 이진 지표는 보류/오류를 제외한 **판정 가능 표본에 조건부인 성능**이다. Coverage는 (TP+FP+FN+TN)/38이며, 가용성 장애까지 포함한 41이 분모가 아니다. 분모 0은 N/A다.

WARNING=음성 보조 지표는 경고가 실제 조치/양성 탐지로 이어지지 않는 운영 상황을 가정한다. 취약 WARNING은 FN, 정상 WARNING은 TN으로 바꾸며 ERROR는 정상으로 바꾸지 않고 제외한다(이번 ERROR=0). 경고를 사람이 검토해 탐지할 수 있다는 이점은 반영하지 못한다.

보수적 평가는 WARNING/ERROR를 실제 정답에 관계없이 오답으로 벌점 처리한다. 취약 보류는 FN, 정상 보류는 FP에 가산한 **가상 벌점 행렬**이며 원래 탐지기의 FP/FN과 혼동하면 안 된다. 보수적 Accuracy=(원래 TP+TN)/38이 가장 직접적인 평가다. 벌점 Precision/Recall/FPR은 정책 비교를 위한 값이며 실제 경고가 양성/음성이었다는 뜻이 아니다. 두 보조 지표는 대안 평가이며 기존 정책을 수정하지 않는다.

WARNING은 5→6개로 증가했다. P-08의 일반 500은 FP→ABSTAIN이며 TN으로 해결된 것이 아니다. P-05와 P-07은 FP→TN, P-06은 FN→TP다. 따라서 이진 Accuracy만 보고 개선을 과장하지 않아야 하지만, 전체 38개 보수적 평가에서도 정답 수가 24→27개로 늘었다. 다른 34개 사례의 선택 판정은 동일하다.

## 사례별 비교 (38개 전부)

|ID|v1 상태/집계|개선 후 상태/집계|변화|
|---|---|---|---|
'''
    for r in changes:
        diff = (r['before_status'],r['before_classification']) != (r['after_status'],r['after_classification'])
        report+=f"|{r['case_id']}|{r['before_status']} / {r['before_classification']}|{r['after_status']} / {r['after_classification']}|{'변경' if diff else '동일'}|\n"
    report+='\n## 기존 측정으로 확인한 성능 비용\n\n|항목|v1|개선 후|\n|---|---|---|\n'
    report+=f"|전체 요청 수 (123회)|{bp['requests']}|{ap['requests']}|\n"
    for key,label in [('total','전체 혼합')]:
        b,a=bp['timing'][key],ap['timing'][key]
        report+=f"|{label} 평균(초)|{b['mean']:.6f}|{a['mean']:.6f}|\n|{label} P95(초)|{b['p95']:.6f}|{a['p95']:.6f}|\n"
    report+=f"|장애 제외 평균(초), 각 114회|{bp['non_fault']['mean']:.6f}|{ap['non_fault']['mean']:.6f}|\n|장애 제외 P95(초)|{bp['non_fault']['p95']:.6f}|{ap['non_fault']['p95']:.6f}|\n"
    report+='\n|모듈|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|\n|---|---|---|---|---|\n'
    for name,b in bp['timing']['modules'].items():
        a=ap['timing']['modules'][name]
        report+=f"|{name}|{b['mean']:.6f}|{a['mean']:.6f}|{b['p95']:.6f}|{a['p95']:.6f}|\n"
    oldweb=bp['timing']['modules']['scan_web_target']['mean']
    newweb=ap['timing']['modules']['scan_web_target']['mean']
    report+=f"\n추가 요청 {ap['requests']-bp['requests']}건 ({(ap['requests']/bp['requests']-1)*100:.1f}% 증가). 루트 도달 가능한 117회 × 추가 GET 7건=819건으로 실행 로그와 일치한다. 전체 평균은 {(ap['timing']['total']['mean']/bp['timing']['total']['mean']-1)*100:.1f}%, 장애 제외 평균은 {(ap['non_fault']['mean']/bp['non_fault']['mean']-1)*100:.1f}% 증가했다. 웹 모듈 평균 증가 {newweb-oldweb:.6f}초는 전체 평균 증가 {ap['timing']['total']['mean']-bp['timing']['total']['mean']:.6f}초와 거의 같다. API/Auth 평균은 큰 변화가 없다.\n"
    report+='''
추가 GET과 timeout 누적이 주요 비용이라는 해석은 요청 수·웹 모듈 시간·E-03 관측에 의해 뒷받침된다. 다만 네트워크/본문 읽기/정규식/대조군 비교/계측 비용을 독립적으로 분해한 실험은 없어 각 비용의 정확한 인과적 비중은 **추정**이다. 전체 P95가 거의 같아도 일반 요청 지연 증가를 부정하지 않는다. 혼합 분포의 상위 구간은 의도적 장애에 지배되며, tail보다 적은 수의 긴 실행은 P95에 전부 반영되지 않는다. P95는 nearest-rank, 반복 3회라 사례별 P95는 최대치다. 두 측정 시점의 머신 부하 차이도 통제하지 않았다. 이번 단계에서 전체 진단을 재실행해 새 성능 숫자를 만들지 않았다.

## 전체 pytest 및 검증

'''
    report+=(DEST/'pytest.log').read_text(encoding='utf-8').join(['```text\n','\n```\n'])
    report+=f"\n전체 pytest 종료 코드 {pytest_exit}, v1 보존본 verify 종료 코드 {v1_exit}, 명시적 현재 재검증 verify 종료 코드 {verify_exit}. `-p no:cacheprovider`는 캐시 쓰기만 끄며 테스트를 제외하지 않는다.\n"
    report+='''
과거 개선 후 JSON은 당시 회귀 종료 코드 1과 당시 테스트 해시를 그대로 유지한다. 따라서 현재 파일로 strict verify를 실행하면 변경된 테스트 해시에서 실패한다([실제 로그](revalidation/historical_strict_verify.log)). 과거 결과의 1을 0으로 수정하거나 테스트 해시를 덮어쓰지 않았다.

`verify.py --revalidation`은 기록된 단일 허용 테스트 변경의 이전/이후 해시, 해당 측정 JSON 해시, 현재 전체 소스 해시, 새 pytest 로그 해시 및 종료 코드 0을 명시적으로 검증한다. 다른 측정 소스는 원래 해시와 일치해야 한다. 기존 지표·CSV·반복·루프백 검사도 계속 수행한다. 과거 실패와 현재 성공을 출력에서 구분한다. 옵션 없는 strict 검증 조건은 유지했다. 이는 이전 측정 당시 pytest가 성공했다는 주장이 아니다.

|이번 변경 파일|이유|
|---|---|
|tests/test_http_status.py|허용된 구현 종속 테스트 하나의 이름·기대값을 새 보안 요구사항에 맞게 수정|
|tools/validation/verify.py|과거 결과를 보존하면서 승인된 테스트 전용 변경과 현재 회귀 증거를 검증하는 명시적 옵션 추가|
|tools/validation/revalidate_improvement.py|38개 고정 표본·대안 정책·성능 재분석 및 실행 로그 생성|
|docs/validation/improvement_01/revalidation.md 및 revalidation/*|분석 JSON·원본 파일 해시·pytest·v1/현재/strict 검증 로그 보존|

`websecscope/scanner/web.py` 등 진단 코드, baseline.py/report.py, 원래 결과와 v1 아카이브는 이번 단계에서 변경하지 않았다. 이전 comparison.md 및 실패 로그도 역사적 기록으로 남기며, 테스트 수정 후 상태는 본 문서가 후속 기록이다. 이전 compare_improvement.py는 측정 당시 소스와의 엄격한 일치를 요구하므로 테스트 수정 이후에는 본 재검증 도구를 사용해야 한다.

## 남은 문제와 다음 단계

헤더 값 관련 H-13/H-14, 쿠키 속성 C-03/C-04 미탐과 API 관리자 SPA A-04 오탐이 남는다. P-03/P-04/P-08/P-09 및 CORS O-03/O-04는 보류다. 파일 형식 휴리스틱·4096바이트 표본·동적 SPA·공개 ZIP의 정책 차이 한계는 기존 보고서와 같다. 1초는 소켓 timeout이며 절대 진단 deadline이 아니다. 공통 GET 본문 읽기가 루트 fallback에 미치는 영향도 남아 있다.

다음 개선 단계는 진행 가능하다. 다만 성능 비용이 큰 상태이므로 탐지 근거와 coverage를 보존하는 중복 요청 절감 실험을 우선하고, 이후 헤더·쿠키·API 노출을 각각 독립 변경으로 비교하는 것이 적절하다. 성능 개선은 별도 측정으로 검증해야 하며 이번 수치만으로 운영 배포 적합성을 확정하지 않는다. 사용자 확인 전 main 병합은 수행하지 않는다.

## 재현 및 원시 근거

- [재분석 JSON 및 모든 입력 해시](revalidation/analysis.json)
- [현재 테스트 변경·소스·pytest 증거 manifest](revalidation/revalidation.json)
- [pytest 로그](revalidation/pytest.log), [v1 검증 로그](revalidation/v1_verification.log), [현재 검증 로그](revalidation/current_verification.log)
- [v1 측정 JSON](../baseline_v1/docs/validation/results/baseline_results.json), [개선 후 측정 JSON](results/baseline_results.json)
- 실행: `python tools/validation/revalidate_improvement.py`. 기존 후속 결과가 있으면 덮어쓰기를 거부하므로 새 실행은 DEST를 새 디렉터리로 지정한다.
- 읽기 전용 재검증: `python tools/validation/verify.py --results docs/validation/improvement_01/results --revalidation docs/validation/improvement_01/revalidation/revalidation.json`.

입력 원본 파일은 실행 전후 SHA-256 일치와 v1 manifest 재검증을 완료했다. 모든 수치는 저장된 실제 실행 로그에서 산출했고 새로 측정하지 않은 성능은 기존 측정 시점의 값이다.
'''
    (AFTER.parent/'revalidation.md').write_text(report,encoding='utf-8')
    print(json.dumps({k:payload[k] for k in ('before','after','pytest_exit_code','v1_verification_exit_code','current_verification_exit_code','original_artifacts_unchanged')},indent=2))
    if pytest_exit or v1_exit or verify_exit:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
