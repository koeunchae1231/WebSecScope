"""Generate Korean baseline documentation solely from recorded results."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / 'docs/validation'
d = json.loads((DOC/'results/baseline_results.json').read_text(encoding='utf-8'))
runs = d['runs']
first = [r for r in runs if r['repeat'] == 1]
byid = {r['case_id']:r for r in first}
fmt = lambda x: 'N/A' if x is None else f'{100*x:.2f}%'

analysis = '''# WebSecScope Baseline — 코드 분석

이번 변경은 `tools/validation/`와 `docs/validation/`에만 추가한다. 진단 로직과 기존 테스트는 수정하지 않는다. 원본 SHA-256 목록 및 실행 전후 동일 여부는 [원시 결과](results/baseline_results.json)의 `source_hashes`, `production_and_existing_tests_unchanged`에 있다.

## 프로젝트 구조와 실행 흐름

`main.py` → `websecscope/cli/main.py` 및 `cli/commands/scan.py` → `scanner/orchestrator.py:run_scan`. scanner는 관측값, analyzer와 rules는 판정, models는 결과 모델, scoring은 감점 점수, reporter/visualizer는 JSON·HTML·LLM 보고, comparison은 전후 차이, guide/i18n/owasp는 설명·분류를 담당한다. `tests/`는 기존 단위 테스트이다. LLM 보고서는 진단 엔진이 아니다.

## 구현된 진단

|항목 / 파일·함수|관측·정상/취약 기준·범위|오탐·미탐 위험 / 기존 검증|
|---|---|---|
|헤더 `scanner/web.py:scan_web_target,_scan_security_headers`; `rules/web/headers.py:SECURITY_HEADERS`|루트 HEAD, 네트워크 오류일 때만 GET 재시도. HSTS/CSP/X-Content-Type-Options/X-Frame-Options/Referrer-Policy/Permissions-Policy 6개가 비어 있지 않으면 PASS, 없으면 FAIL|값 유효성·HTTPS 적용·실제 GET 문서·브라우저 효과 미검증. 기존 헤더 네트워크 정확도 테스트 없음; i18n/OWASP 테스트는 표현·분류만 검증|
|쿠키 `scanner/web.py:_scan_cookie_flags`; `analyzer/api_auth_analyzer.py:_analyze_cookie_security`|루트 및 API 후보 Set-Cookie에 secure/httponly/samesite 문자열이 모두 있으면 PASS, 하나라도 없으면 FAIL; 쿠키 없으면 PASS. API는 9개 경로를 집계|쿠키 이름·값의 키워드도 속성으로 오인; SameSite 값·쿠키 용도·Domain/Path·접두사·HTTPS 미검증. 기존 전용 테스트 없음|
|민감 경로 `scanner/web.py:_scan_sensitive_paths,_sensitive_path_observation,_sensitive_path_interpretation`; `rules/web/paths.py`|.git/HEAD, .env, backup.zip, admin, phpinfo.php HEAD, 리디렉션 미추적. 하나라도 200 또는 500이면 FAIL; 401/403/301/302만 존재하면 WARNING; 그 외 PASS. 하나의 집계 finding|SPA·공개 로그인·HEAD/GET 차이 오탐/미탐; 오류는 조용히 생략. 204/307/308 등 미집계. `tests/test_http_status.py` 5개는 리디렉션 표현, 403 해석, 200/403/404 mock 판정이며 실서버·오류·SPA 없음|
|API 노출 `scanner/api_scanner.py:scan_api_endpoints,request_observation`; `analyzer/api_auth_analyzer.py:_analyze_endpoint_exposure`|GET /api,/api/users,/api/login,/api/auth,/api/admin,/admin,/swagger,/api-docs,/openapi.json, 본문 최대 4096바이트. admin 포함 경로와 문서 3종이 200/201/202/204면 FAIL; 모두 없으면 API_ENDPOINT_EXPOSURE PASS|내용 확인 없이 상태 코드만 사용. 공개 문서·SPA 오탐, 후보 밖 경로·다른 코드 미탐. 기존 전용 테스트 없음|
|인증 `scanner/auth_scanner.py:scan_auth_controls,_is_auth_path`; analyzer `_analyze_auth_access`|API 관측값 중 login/auth/signin 경로 재사용 및 /login,/signin GET 추가. API/admin 2xx는 AUTH_MAY_BE_MISSING WARNING, 401/403은 PASS, 다른 코드는 인증 finding 없음|인증·권한 우회 확증 기능 없음, 정상 공개 API도 WARNING. 자격증명/역할 비교 없음. 기존 전용 테스트 없음|
|CORS analyzer `_analyze_cors`; API `scan_api_endpoints`|ACAO 있으면 https://websecscope.local Origin으로 추가 GET. wildcard+credentials true는 FAIL, 반사 또는 wildcard 단독은 WARNING, 그 외 PASS|단일 Origin만 테스트; OPTIONS/preflight/브라우저 실행 없음. wildcard+credentials는 구성 오류이며 브라우저의 credentialed 응답 읽기 성공 증거가 아님. 공개 wildcard/의도된 allowlist 반사 경고 가능. 기존 전용 테스트 없음|
|JWT analyzer `_analyze_jwt_usage,_decode_jwt,_jwt_issues`|응답 헤더·쿠키·4096바이트에서 JWT 정규식 탐색 후 서명 검증 없이 decode. alg none/exp 없음/1년 초과/민감 키는 WARNING; 관측 안 됨 또는 구조 신호 없으면 PASS|서명·만료 토큰 수용·실제 인증 취약점 검증 안 함. 샘플 밖 토큰 미탐, 키 이름만으로 경고 가능. 기존 전용 테스트 없음; 이번 정확도 미측정|
|IDOR analyzer `_analyze_idor_patterns`|숫자 object ID 경로 정규식이면 WARNING, 없으면 PASS|기본 API 후보에는 숫자 ID가 없음. 소유권·다중 사용자 접근 검증 없음. 실제 IDOR 정확도 미지원; 기존 전용 테스트 없음|
|속도 제한 analyzer `_analyze_rate_limit_headers`|인증 후보의 x-ratelimit* 또는 Retry-After 존재 시 PASS, 누락 후보 있으면 WARNING|반복 요청 없이 단순 헤더 관측. 헤더 부재는 제한 부재의 증거 아님; 404/오류 후보도 경고 대상. 실제 제한 정확도 미지원; 기존 전용 테스트 없음|
|Linux `scanner/linux_scanner.py:scan_linux_security,_collect_*`; `analyzer/linux_analyzer.py:analyze_linux_scan,_analyze_*`|Linux만 OS/SSH 설정·방화벽 도구·파일권한·계정·/proc 포트 관측. root SSH 허용, sticky 없는 world-write tmp, 추가 UID0은 FAIL. 패스워드 SSH/X11/MaxAuthTries/allowlist/파일권한/SUID/sudo/포트는 주로 WARNING|Include/Match·유효 sshd 설정·방화벽 외부 접근 확증 없음. 읽기 권한·기본값·root 실행이 오판에 영향. Windows는 SKIPPED 의미의 PASS. 이번 웹 fixture로 미측정, 기존 전용 테스트 없음|
|Docker `scanner/docker_scanner.py:scan_docker_security,_normalize_container`; `analyzer/docker_analyzer.py:_analyze_container,_analyze_mounts,_analyze_env,_analyze_ports`|docker ps/inspect 읽기 전용. privileged/host network·PID·IPC/위험 capability/socket mount FAIL, root·writable rootfs·cap drop·태그/digest·민감 mount·환경변수 키·외부 포트·DB는 WARNING|메타데이터 휴리스틱, 네트워크 실제 도달·secret 값 미검증. Docker 불가 시 skipped PASS. 정답 컨테이너 미구축으로 미측정; 기존 전용 테스트 없음|
|서비스 `scanner/linux.py:get_listening_ports`; `service_detector.py:detect_services`; `version_detector.py:detect_versions,normalize_version`; `analyzer/service_analyzer.py:analyze_services,_analyze_ssh`|/proc TCP 포트를 고정 표로 서비스 추정, 로컬 SSH banner/HTTP(S) HEAD 제품·버전 정규화. 위험 서비스 및 오래된 SSH banner는 WARNING|포트와 실제 서비스 불일치, 로컬 listen을 외부 노출처럼 해석할 위험, banner 조작·패치 backport 불명. 이번 미측정; 기존 전용 테스트 없음|
|CVE `analyzer/cve.py:analyze_cves,lookup_cves,normalize_nvd_response,build_cve_findings`|제품/버전 NVD 키워드 조회·캐시, CVSS 위험도. high confidence+HIGH/CRITICAL FAIL, 나머지 WARNING|CPE/환경/패치 적용 확증 아님. 캐시·외부 데이터에 영향. 외부 통신 방지를 위해 비활성, 정확도·시간 미측정; 기존 전용 테스트 없음|

기존 `test_score.py`는 감점·등급, `test_i18n.py`는 언어, `test_owasp.py`는 분류, `test_llm_report_generator.py`는 프롬프트·포맷·fallback·환경 설정을 검증한다. 테스트 통과는 실제 취약점 탐지 정확도를 의미하지 않는다.
'''
(DOC/'01_baseline.md').write_text(analysis, encoding='utf-8')

method = '''# 측정 방법과 사전 판정 정책

Python 표준 라이브러리 ThreadingHTTPServer를 매 회 127.0.0.1 임시 포트에 바인딩한다. 정답은 scanner 결과가 아닌 fixture의 응답 계약(아래 표 및 baseline.py Handler)으로 정의한다. 모든 데이터·secret은 합성값이다. 외부 운영 서버에 요청하지 않는다.

실행: 저장소 루트에서 `python tools/validation/baseline.py` 후 `python tools/validation/report.py`, `python tools/validation/verify.py`. pytest가 필요하며 다른 신규 서버 의존성은 없다. 이 환경의 실제 Python 경로·버전·OS·실행시각(UTC)은 JSON 최상위에 기록된다. 실행은 기존 결과 파일을 덮어쓴다. verify.py는 원본 해시, 반복 안정성, 루프백 요청, JSON/CSV 행과 지표 일치를 읽기 전용으로 확인한다. [검증 로그](results/verification.log)에 이번 실행 출력을 보존한다.

## 실행 및 집계 단위

기존 orchestrator.run_scan을 호출하며 API/Auth를 켜고 Linux/Docker/service/CVE는 명시적으로 끈다. 외부 래퍼는 원래 함수를 동일 인자·반환값으로 호출하여 시간과 관측값만 기록한다. 타임아웃·후보 경로·응답·진단 조건은 변경하지 않는다. web._request 및 API/auth request_observation 래퍼에는 각 논리 요청이 한 번 기록된다. 실제 서버 도착 기록은 server_events이다. 루트 GET/HEAD 차이 사례의 GET 정답은 fixture 계약이며 스캐너가 GET을 안 보낸 사실도 요청 로그에서 확인된다.

각 사례는 하나의 보안 주장과 대상 check를 갖는다. 여러 finding은 FAIL 우선, 다음 WARNING, 다음 PASS로 한 번만 집계한다. 관리자 노출은 API 결과만 사용하고 같은 /admin에 대한 web 결과는 정확도에 중복 가산하지 않는다. 민감 경로는 엔진 자체가 집계 finding 하나이므로 사례별 집계 주장 하나를 평가한다. API의 관리자 /admin 및 /api/admin 중복도 하나로 합친다. HSTS 사례는 HTTPS 운영 보장 대신 헤더 배포 설정만 측정한다.

**실행 전 코드에 정의한 정책:** FAIL=양성, 명시적 PASS=음성, WARNING=ABSTAIN으로 이진 분모에서 제외. 없거나 예외가 나면 ERROR로 제외하며 정상으로 치지 않는다. SKIPPED는 PASS로 보이더라도 제외한다. 가용성 장애는 보안 취약 여부가 정의되지 않아 EXCLUDED로 별도 집계한다. 미지원 U-01은 선언만 하고 실행하지 않으며 분모에 포함하지 않는다. 반복 3회 중 첫 회만 정확도 계산, 모든 반복은 안정성·시간에 사용한다. 분모 0은 JSON null, 문서 N/A이다. WARNING을 음성으로 취급하는 보조 결과도 별도 제공하여 보류로 recall이 높아 보이는 효과를 드러낸다.

Precision=TP/(TP+FP), Recall=TP/(TP+FN), FPR=FP/(FP+TN), Accuracy=(TP+TN)/(TP+FP+FN+TN). 이 수치는 인위적으로 구성한 표본의 조건부 성능이며 실서비스 일반화 수치가 아니다. Security Score는 모든 findings에 대한 기존 감점 점수로 각 실행 JSON/CSV에 별도 저장한다.

전체 시간은 run_scan 호출과 계측 overhead를 포함하고 서버 시작·종료·대기·파일 저장·pytest는 제외한다. 모듈 시간은 web/API/auth 수집/API-auth 분석/score 함수 벽시계이다. cve disabled 처리 등 나머지 orchestration 시간은 전체에만 포함한다. 평균은 산술평균, P95는 nearest-rank ceil(.95*n), warmup 제외 없이 3회 실행한다. 단일 사례 n=3의 P95는 최댓값이며 추정 신뢰도가 낮다. 전체 혼합 분포에는 의도적 장애도 포함하므로 정상 사례와 구분해야 한다.

요청 실패는 요청 관측 error 수, timeout은 error 문자열에 Timeout이 있는 수이다. 기존 코드가 URLError로 원인을 축약하면 timeout 총수는 하한일 수 있다. 진단 실패는 run_scan 예외와 별도로 사례 ERROR, WEB_REACHABILITY, 내부 요청 오류를 보고한다. HTTP 401/403/404/500은 전송 성공이며 네트워크 실패로 세지 않는다. 민감 경로 오류를 엔진이 숨겨도 외부 래퍼에 남긴다.

## 사례와 정답

|ID|항목|실제 상태|기대 결과|판정 근거|실행|
|---|---|---|---|---|---|
'''
for c in d['cases']:
    truth = '미정/가용성' if c['vulnerable'] is None else '취약' if c['vulnerable'] else '정상'
    expected = '별도 오류 관측' if c['vulnerable'] is None else '미지원' if c['family']=='unsupported' else c['expected']
    method += f"|{c['id']}|{c['family']}|{truth}|{expected}|{c['reason']}|{'미실행' if c['family']=='unsupported' else '3회'}|\n"
method += '''
## 한계

SQLi/XSS/RCE 등 능동 공격, 실제 IDOR·인증 우회·rate limiting, TLS 인증서/프로토콜, JWT 서명 취약점은 이 fixture의 정확도 대상이 아니다. JWT 구조 휴리스틱·API 쿠키 경로 집계·다중 쿠키·preflight·대용량 본문·교차 호스트 리디렉션·500 전반·모든 상태 코드를 포괄하지 않는다. 로컬 HTTP만 사용하므로 브라우저의 Secure 쿠키 전달이나 HSTS 효과를 재현하지 않는다. Linux/Docker/service/CVE는 구현되어 있으나 이번 실행에서는 정답 환경 부재 또는 외부 조회 제한으로 미측정이다. 서로 다른 모듈의 음성 PASS는 안전성 증명이 아니다. fixture 계약과 독립적인 브라우저/수동 oracle 검증은 향후 추가해야 한다.
'''
(DOC/'02_test_methodology.md').write_text(method, encoding='utf-8')

m = d['metrics']
report = f'''# 개선 전 실행 결과

실행 시각: {d['generated_at']} (UTC). 환경: {d['platform']}, Python {d['python'].split()[0]}.

근거: [전체 실행 JSON](results/baseline_results.json), [실행별 CSV](results/baseline_summary.csv), [기존 회귀 테스트 로그](results/regression.log). JSON `cases`는 정답 계약, `runs`는 case_id/repeat로 연결되는 실제 findings·선택 결과·모듈 시간·요청 및 서버 이벤트이다. 아래 표는 JSON 첫 회에서 생성하였다.

고유 실행 사례 {len(first)}개, 총 진단 실행 {len(runs)}회, 미지원 선언 {len(d['cases'])-len(first)}개 미실행. 보안 정답 사례 {sum(c['vulnerable'] is not None and c['family']!='unsupported' for c in d['cases'])}개, 가용성 별도 사례 {m['excluded']}개. 보류 {m['abstained']}개, 판정 오류 {m['errors']}개. 이진 coverage {fmt(m['coverage'])}.

|TP|FP|FN|TN|Precision|Recall|FPR|Accuracy|
|---|---|---|---|---|---|---|---|
|{m['TP']}|{m['FP']}|{m['FN']}|{m['TN']}|{fmt(m['precision'])}|{fmt(m['recall'])}|{fmt(m['fpr'])}|{fmt(m['accuracy'])}|

## 항목별 지표

|항목|TP|FP|FN|TN|보류|Precision|Recall|FPR|Accuracy|
|---|---|---|---|---|---|---|---|---|---|
'''
for family, v in d['by_family'].items():
    report += f"|{family}|{v['TP']}|{v['FP']}|{v['FN']}|{v['TN']}|{v['abstained']}|{fmt(v['precision'])}|{fmt(v['recall'])}|{fmt(v['fpr'])}|{fmt(v['accuracy'])}|\n"
report += '\n## 사례별 결과와 Security Score\n\n|ID|실제 판정|집계|Score (첫 회)|근거 위치|\n|---|---|---|---|---|\n'
for i, r in enumerate(first):
    report += f"|{r['case_id']}|{r['status']}|{r['classification']}|{r['security_score']}|JSON runs[{runs.index(r)}], selected/findings/requests/server_events|\n"
report += '\n## 성능\n\n|구간|n|평균(초)|P95(초)|\n|---|---|---|---|\n'
for name, v in {'total':d['timing']['total'], **d['timing']['modules']}.items():
    report += f"|{name}|{v['n']}|{v['mean']:.6f}|{v['p95']:.6f}|\n"
normal = sorted(r['seconds'] for r in runs if not r['case_id'].startswith('E-'))
report += f"\n의도적 가용성 장애 E-*를 제외한 {len(normal)}회: 전체 평균 {sum(normal)/len(normal):.6f}초, P95 {normal[__import__('math').ceil(.95*len(normal))-1]:.6f}초. 전체 혼합 분포와 구분한다.\n"
report += '\n|사례|전체 평균(초)|전체 P95(초)|\n|---|---|---|\n'
import math, statistics
for r in first:
    values = sorted(x['seconds'] for x in runs if x['case_id']==r['case_id'])
    report += f"|{r['case_id']}|{statistics.mean(values):.6f}|{values[math.ceil(.95*len(values))-1]:.6f}|\n"
report += f"\n총 요청 오류 {d['request_errors']}건, 명시적 timeout {d['timeout_errors']}건, 진단 예외 {d['scan_exceptions']}건. WEB_REACHABILITY 결과 실행 수 {sum(any(f['check_id']=='WEB_REACHABILITY' for f in r['findings']) for r in runs)}회. 반복 간 선택 상태·분류 불일치 사례 수 {sum(len({(r['status'],r['classification']) for r in runs if r['case_id']==c['id']})>1 for c in d['cases'])}개. 기존 pytest 종료 코드 {d['regression_exit_code']}. 원본 소스 및 기존 테스트 해시 동일: {d['production_and_existing_tests_unchanged']}.\n"
report += '\n회귀 테스트 실제 출력:\n\n```text\n' + (DOC/'results/regression.log').read_text(encoding='utf-8') + '\n```\n'
report += '\npytest 캐시 디렉터리 쓰기 권한 경고 1건은 테스트 실패가 아니다. 테스트 캐시 저장만 불가했고 실제 20개 테스트는 모두 통과했다.\n'
report += '\n## 오탐·미탐·보류\n\n'
for r in first:
    if r['classification'] in {'FP','FN','ABSTAIN','ERROR'}:
        c = next(c for c in d['cases'] if c['id']==r['case_id'])
        report += f"- {c['id']} {r['classification']} ({r['status']}): {c['reason']}. 실제 근거는 해당 runs의 selected와 server_events.\n"
abstain = [r for r in first if r['classification']=='ABSTAIN']
tp,fp,fn,tn = (m[k] for k in ('TP','FP','FN','TN'))
fn += sum(next(c for c in d['cases'] if c['id']==r['case_id'])['vulnerable'] for r in abstain)
tn += sum(not next(c for c in d['cases'] if c['id']==r['case_id'])['vulnerable'] for r in abstain)
report += f'\n보조 정책(WARNING을 비탐지 음성으로 간주): TP={tp}, FP={fp}, FN={fn}, TN={tn}, Recall={fmt(tp/(tp+fn) if tp+fn else None)}, Accuracy={fmt((tp+tn)/(tp+fp+fn+tn) if tp+fp+fn+tn else None)}. 주 지표와 혼합하지 않는다.\n'
report += '''
## 우선 개선 후보 5개와 다음 수정 대상

1. `scanner/web.py:_scan_sensitive_paths` 및 `analyzer/api_auth_analyzer.py:_analyze_endpoint_exposure`: SPA 제어 경로·본문 비교와 자원 유형 검증, HEAD 성공/실패와 실제 GET 접근을 대조한다. P-05/P-06/P-07/A-04의 오판을 줄이는 방향이다.
2. `scanner/web.py:_scan_security_headers` 및 `rules/web/headers.py`: 헤더별 값·구문·적용 스킴 검증과 GET 문서 표본을 추가한다. H-13/H-14 미탐을 목표로 한다.
3. 두 쿠키 검사 함수: substring 대신 Set-Cookie 속성 파싱, SameSite 허용값 및 cookie별 결과를 도입한다. C-03/C-04 미탐을 목표로 한다.
4. `_scan_sensitive_paths`, `request_observation`, `_analyze_endpoint_exposure`: timeout/연결 실패를 UNKNOWN/ERROR로 전달하여 무응답을 PASS로 집계하지 않는다. E-03 및 E-02 API baseline의 거짓 안심을 해소한다. HTTP 500을 민감 정보 노출 확증과 분리한다(P-08).
5. `_analyze_cors`, `_analyze_auth_access`, `_analyze_rate_limit_headers`: 구성 오류·검토 신호·확인 취약점을 분리하고 복수 Origin/credentials/preflight 및 공개 API 정책을 검증한다. O-03 보류·O-04 정상 경고를 구분하며 브라우저가 차단하는 wildcard+credentials를 실제 데이터 탈취로 설명하지 않는다.

위 후보는 기록만 하였으며 이번 단계에 수정하지 않았다. 다음 단계는 동일 oracle과 새 fixture로 개선 전후 비교하고, 별도 Linux/Docker 정답 환경 및 JWT 구조 검증을 확장하는 것이다. 기존 합격 사례와 보류율도 함께 비교하여 지표 개선을 확인해야 한다.
'''
(DOC/'03_results_before.md').write_text(report, encoding='utf-8')
print('Generated 3 validation documents from actual run data.')
