"""Preserve phase 1 and measure phase 2 using the unchanged baseline fixture."""
import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
from http.server import ThreadingHTTPServer

import baseline as b

ROOT = b.ROOT
OUT = ROOT/'docs/validation/improvement_02'
SNAP = OUT/'before'


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def preserve():
    assert not SNAP.exists(), 'Do not overwrite snapshot'
    files = [p for folder in ('websecscope','tests','tools/validation') for p in (ROOT/folder).rglob('*.py')]
    files += [p for folder in ('docs/validation/results','docs/validation/baseline_v1','docs/validation/improvement_01')
              for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    manifest = {}
    for p in files:
        rel = p.relative_to(ROOT)
        dst = SNAP/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,dst)
        manifest[str(rel)] = digest(p)
    (SNAP/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(f'Preserved {len(files)} source/test/tool and historical artifact files.')


def verify_frozen():
    manifest=json.loads((SNAP/'manifest.json').read_text(encoding='utf-8'))
    for rel,sha in manifest.items():
        assert digest(SNAP/rel)==sha, rel
        if rel.startswith('docs') or rel.endswith('baseline.py'):
            assert digest(ROOT/rel)==sha,rel


def run():
    verify_frozen()
    results=OUT/'results'
    assert not results.exists(), 'Do not overwrite results'
    b.OUT=results
    results.mkdir(parents=True)
    with (results/'execution.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        b.main()
    data=json.loads((results/'baseline_results.json').read_text(encoding='utf-8'))
    old=json.loads((ROOT/'docs/validation/improvement_01/results/baseline_results.json').read_text(encoding='utf-8'))
    assert data['cases']==old['cases']
    data['invocation']=[sys.executable,'tools/validation/optimize_requests.py','run']
    (results/'baseline_results.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    p=subprocess.run([sys.executable,'tools/validation/verify.py','--results',str(results)],cwd=ROOT,capture_output=True,text=True)
    (results/'verification.log').write_text(f'Exit code: {p.returncode}\n'+p.stdout+p.stderr,encoding='utf-8')
    verify_frozen()
    print(json.dumps(dict(metrics=data['metrics'],timing=data['timing'],regression_exit=data['regression_exit_code'],verify_exit=p.returncode),indent=2))
    assert p.returncode==data['regression_exit_code']==0


def perf():
    """30 interleaved pairs, web-only, same fixture server; excluded from accuracy."""
    verify_frozen()
    assert not (OUT/'performance.json').exists(), 'Do not overwrite performance experiment'
    spec=importlib.util.spec_from_file_location('web_phase1',SNAP/'websecscope/scanner/web.py')
    old=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    from websecscope.scanner import web
    rows=[]
    server=ThreadingHTTPServer(('127.0.0.1',0),b.Handler)
    server.cfg,server.events={},[]
    threading.Thread(target=server.serve_forever,daemon=True).start()
    target=f'http://127.0.0.1:{server.server_port}/'
    try:
        for repeat in range(30):
            for name,module in ([('before',old),('after',web)] if repeat%2==0 else [('after',web),('before',old)]):
                start=time.perf_counter()
                event_start=len(server.events)
                findings=module.scan_web_target(target)
                rows.append(dict(repeat=repeat+1,variant=name,seconds=time.perf_counter()-start,
                                 requests=len(server.events)-event_start,status=next(f.status for f in findings if f.check_id=='WEB_SENSITIVE_PATHS')))
    finally:
        server.shutdown()
        server.server_close()
    payload=dict(python=sys.version,platform=b.platform.platform(),generated_at=b.datetime.now(b.timezone.utc).isoformat(),
                 policy='Web-only; 30 interleaved pairs; no warmup discarded; absent sensitive resources; not accuracy samples',target=target,rows=rows,
                 summary={name:b.stats([r['seconds'] for r in rows if r['variant']==name]) for name in ('before','after')})
    (OUT/'performance.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    print(json.dumps(payload['summary'],indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['preserve','run','perf'])
    globals()[parser.parse_args().action]()
