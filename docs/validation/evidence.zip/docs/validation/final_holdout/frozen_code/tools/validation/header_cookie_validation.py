"""Phase 3 preservation and unchanged-loopback-fixture measurement."""
import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

import baseline as b

ROOT=b.ROOT
OUT=ROOT/'docs/validation/improvement_03'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def preserve():
    assert not OUT.exists(), 'Refusing to overwrite phase 3'
    files=[p for folder in ('websecscope','tests','tools/validation') for p in (ROOT/folder).rglob('*.py')]
    manifest={}
    for p in files:
        dest=OUT/'before'/p.relative_to(ROOT)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,dest)
        manifest[str(p.relative_to(ROOT))]=sha(p)
    history={str(p.relative_to(ROOT)):sha(p) for folder in ('results','baseline_v1','improvement_01','improvement_02')
             for p in (ROOT/'docs/validation'/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    (OUT/'before/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'history_manifest.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    print(f'Preserved {len(files)} sources and hashes of {len(history)} historical files.')


def frozen():
    for rel,digest in json.loads((OUT/'history_manifest.json').read_text(encoding='utf-8')).items():
        assert sha(ROOT/rel)==digest,rel
    for rel,digest in json.loads((OUT/'before/manifest.json').read_text(encoding='utf-8')).items():
        assert sha(OUT/'before'/rel)==digest,rel
        if rel.startswith('tests') or rel.endswith('baseline.py'):
            assert sha(ROOT/rel)==digest,rel


def run():
    frozen()
    results=OUT/'results'
    assert not results.exists(), 'Refusing to overwrite measurements'
    results.mkdir(parents=True)
    b.OUT=results
    with (results/'execution.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        b.main()
    data=json.loads((results/'baseline_results.json').read_text(encoding='utf-8'))
    old=json.loads((ROOT/'docs/validation/improvement_02/results/baseline_results.json').read_text(encoding='utf-8'))
    assert data['cases']==old['cases']
    data['invocation']=[sys.executable,'tools/validation/header_cookie_validation.py','run']
    (results/'baseline_results.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    p=subprocess.run([sys.executable,'tools/validation/verify.py','--results',str(results)],cwd=ROOT,capture_output=True,text=True)
    (results/'verification.log').write_text(f'Exit code: {p.returncode}\n'+p.stdout+p.stderr,encoding='utf-8')
    frozen()
    print(json.dumps(dict(metrics=data['metrics'],timing=data['timing'],pytest_exit=data['regression_exit_code'],verify_exit=p.returncode),indent=2))
    assert p.returncode==data['regression_exit_code']==0


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['preserve','run'])
    globals()[parser.parse_args().action]()
