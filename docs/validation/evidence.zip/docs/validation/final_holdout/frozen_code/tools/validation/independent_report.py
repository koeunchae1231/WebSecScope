"""Metrics from frozen labels and recorded runs; no scanner execution or relabeling."""
import csv
import json
import math
import statistics
from collections import Counter

from independent_evaluation import OUT, ROOT, read, sha, verify, write


def metrics(rows, warning_negative=False):
    rows=[r for r in rows if r['evaluable']]
    counts=Counter()
    for r in rows:
        label=r['classification']
        if warning_negative and label=='ABSTAIN':
            label='FN' if r['truth']=='vulnerable' else 'TN'
        counts[label]+=1
    tp,fp,fn,tn=(counts[k] for k in ('TP','FP','FN','TN'))
    ratio=lambda a,b:a/b if b else None
    binary=tp+fp+fn+tn
    return dict(n=len(rows),TP=tp,FP=fp,FN=fn,TN=tn,precision=ratio(tp,tp+fp),recall=ratio(tp,tp+fn),
                fpr=ratio(fp,fp+tn),accuracy=ratio(tp+tn,binary),coverage=ratio(binary,len(rows)),
                ABSTAIN=counts['ABSTAIN'],ERROR=counts['ERROR'],conservative_accuracy=ratio(tp+tn,len(rows)))


def stats(values):
    return dict(n=len(values),mean=statistics.mean(values),p95=sorted(values)[math.ceil(.95*len(values))-1])


def csv_write(name, rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    verify()
    assert read('completion.json')['runs']==216
    cases=read('cases.json')
    case_map={c['id']:c for c in cases}
    runs=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'runs').glob('*.json'))]
    assert len(runs)==216 and len({(r['case_id'],r['repeat']) for r in runs})==216
    first=[r for r in runs if r['repeat']==1]
    assert len(first)==72
    for r in runs:
        c=case_map[r['case_id']]
        assert r['truth']==c['security_state'] and r['evaluable']==c['evaluable']
        assert all(req['url'].startswith(r['target']) for req in r['requests'])
    agreements=[]
    for c in cases:
        group=[r for r in runs if r['case_id']==c['id']]
        assert {r['repeat'] for r in group}=={1,2,3}
        signatures={(r['status'],tuple(sorted((f['check_id'],f['status']) for f in r['selected']))) for r in group}
        agreements.append(dict(id=c['id'],consistent=len(signatures)==1))
    result=dict(metrics=metrics(first),warning_negative=metrics(first,True),
                by_area={area:metrics([r for r in first if r['area']==area]) for area in sorted({r['area'] for r in runs})},
                unknown_status_counts=dict(Counter(r['status'] for r in first if not r['evaluable'])),
                consistency=sum(g['consistent'] for g in agreements)/len(cases),agreements=agreements,
                timing=stats([r['seconds'] for r in runs]),http_requests=stats([r['http_requests'] for r in runs]),
                logical_requests=stats([r['logical_requests'] for r in runs]),
                request_errors=sum(r['errors'] for r in runs),timeouts=sum(r['timeouts'] for r in runs),
                scan_exceptions=sum(r['exception'] is not None for r in runs))
    result['by_area_warning_negative']={area:metrics([r for r in first if r['area']==area],True) for area in result['by_area']}
    write('summary.json',result)
    rows=[]
    for r in first:
        c=case_map[r['case_id']]
        rows.append(dict(id=c['id'],area=c['area'],name=c['name'],truth=r['truth'],evaluable=r['evaluable'],
                         observability=c['observability'],status=r['status'],classification=r['classification'],
                         check_ids=';'.join(f['check_id'] for f in r['selected']),
                         evidence=' | '.join(f['evidence'] for f in r['selected']),consistent=next(g['consistent'] for g in agreements if g['id']==r['case_id'])))
    csv_write('case_summary.csv',rows)
    csv_write('run_summary.csv',[{k:r[k] for k in ('case_id','area','repeat','truth','status','classification','seconds','http_requests','logical_requests','errors','timeouts','exception')} for r in runs])
    csv_write('area_summary.csv',[dict(area=area,**value) for area,value in result['by_area'].items()])
    historical=json.loads((ROOT/'docs/validation/improvement_04/results/baseline_results.json').read_text(encoding='utf-8'))
    old=[r for r in historical['runs'] if r['repeat']==1 and r['classification']!='EXCLUDED']
    old_eval=[dict(r,evaluable=True,truth='vulnerable' if next(c for c in historical['cases'] if c['id']==r['case_id'])['vulnerable'] else 'safe') for r in old]
    comparison=dict(fixed_38=metrics(old_eval),fixed_warning_negative=metrics(old_eval,True),independent_60=result['metrics'],
                    independent_warning_negative=result['warning_negative'],
                    qualification='Different constructed case mix and requirements, not matched random samples; no causal improvement/degradation claim.')
    write('comparison.json',comparison)
    pct=lambda v:'N/A' if v is None else f'{v*100:.2f}%'
    report='''# 독립 검증 및 일반화 성능 평가

## 1. 사례 구성

6개 영역 × 12개 = 72개 신규 서비스 시나리오를 사전에 확정했다. 각 영역은 정상 5개, 취약 5개, 근거 부족 2개로 구성되어 총 정상 30개·취약 30개·정답 미확정 12개이다. 이진 정답이 있는 60개를 모두 주 지표에 포함하며 스캐너의 관측 범위를 벗어난 사례도 사후 제외하지 않았다.
[사례·입력·정답·근거·관측 가능성](cases.json), [사전 정책](policy.json), [고정 해시와 시각](preregistration.json)을 보존했다. 실행 전 스캐너로 새 corpus를 시험하지 않았다.
기존 fixture와 본문·쿠키 조합을 복제하지 않았고 독립 Handler를 작성했다. /.env, /admin, /api/users 등 고정 후보 URL은 제품 인터페이스상 필요한 겹침이다. 표준 헤더의 개별 지시어도 의미상 재사용이 불가피하지만 서비스 계약과 응답 조합·구조는 새로 작성했다.

## 2. 코드·환경·무결성

평가 대상은 `improve/sensitive-path-validation`의 4차 완료 작업 트리다. 커밋 ID만으로 수정 파일을 식별할 수 없으므로 [target_hashes.json](target_hashes.json)의 전체 Python 소스·테스트 및 pytest.ini SHA-256을 버전 식별자로 사용한다.
[초기 Git 상태와 diff](git_before.log), [종료 Git 상태](git_after.log), [실행 환경](environment.json)을 기록했다. Baseline v1 및 1~4차 결과 447개 파일의 [해시](history_hashes.json)를 고정하고 이전 보존 manifest와 소스 해시 1093건을 대조했다.
각 trial 시작 및 종료, 보고서 생성 시 코드·과거 결과·사전 확정된 fixture/정답/정책/평가 도구의 해시를 검사한다. 원시 실행 결과도 별도 manifest로 고정한다. 스캐너·분석기·규칙·판정 정책과 기존 fixture/테스트는 수정하지 않았다.

## 3. 기존 pytest

'''
    report+='```text\n'+(OUT/'pytest_before.log').read_text(encoding='utf-8').strip()+'\n```\n'
    report+='''
## 4. 집계 방법과 신규 성능

같은 사례의 3회 반복은 별도 독립 사례로 계산하지 않는다. 첫 반복만 정확도에 사용하고, 216회 전체로 시간·요청·일치율을 계산한다. FAIL=양성, PASS=음성, WARNING=ABSTAIN이며 예외 또는 선택된 Finding 부재는 ERROR다. 여러 대상 Finding은 FAIL > WARNING > PASS로 집계한다. unrelated Finding은 정확도에 섞지 않는다. selector는 실행 전에 고정했다.
Precision=TP/(TP+FP), Recall=TP/(TP+FN), FPR=FP/(FP+TN), 기본 Accuracy=(TP+TN)/(TP+FP+FN+TN), Coverage=이진 판정 수/60이다. WARNING=음성 Accuracy는 WARNING을 정상 TN/취약 FN으로 바꾸고 ERROR는 여전히 분리한다. 보수적 Accuracy=(TP+TN)/60으로 모든 보류·오류를 오답 처리한다. 분모 0은 N/A다. 취약 WARNING은 TP가 아니다.
주 지표는 60개 라벨 사례를 대상으로 한다. unknown 12개는 TP/TN으로 보상하지 않고 실제 판정 분포를 별도로 보고한다. 정책 자체를 모르는 경우 PASS/FAIL이 나왔다고 바로 FP/FN이라고 단정할 수 없다.

|지표|기존 고정 38개|신규 독립 60개|
|---|---:|---:|
'''
    for key in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','ABSTAIN','ERROR','conservative_accuracy'):
        fmt=pct if key in {'precision','recall','fpr','accuracy','coverage','conservative_accuracy'} else str
        report+=f"|{key}|{fmt(comparison['fixed_38'][key])}|{fmt(result['metrics'][key])}|\n"
    report+=f"|WARNING=음성 Accuracy|{pct(comparison['fixed_warning_negative']['accuracy'])}|{pct(result['warning_negative']['accuracy'])}|\n"
    report+=f"\n미확정 12개 실제 판정: `{result['unknown_status_counts']}`. 반복 판정 일치율은 **{pct(result['consistency'])}**이다.\n"
    report+='''
## 5. 기존 평가와의 비교 해석

기존 38개에서는 4차의 이진 FP/FN이 0이었다. 신규 사례는 공개 데이터 계약, JavaScript 접근이 필요한 비민감 쿠키, nonce가 바뀌는 SPA, 일반적인 업무 필드명의 비공개 데이터, 완전한 CSP/권한 정책 강도처럼 단순 구성 여부를 넘어서는 요구를 포함한다.
사례 구성과 난이도·정책이 다르고 무작위 실서비스 표본도 아니므로 점수 차이만으로 과거 개선의 인과적 성능 저하/향상을 단정하지 않는다. 이 corpus는 특정 구조와 정책에 대한 일반화 한계를 드러내는 구성 평가다. 평가 도중 제품이나 정답을 고쳐 점수를 높이지 않았다.

## 6. FP/FN/WARNING과 ERROR

아래에는 새 정답과 실제 판정이 다른 사례 및 모든 보류·오류를 원래 판정 그대로 기록한다. 전체 Finding·check_id·evidence·HTTP 관측은 [runs/](runs/)에 있다.

|사례|영역/이름|정답|실제|집계|
|---|---|---|---|---|
'''
    for r in rows:
        if r['classification'] in {'FP','FN','ABSTAIN','ERROR'} or not r['evaluable']:
            report+=f"|{r['id']}|{r['area']}: {r['name']}|{r['truth']}|{r['status']}|{r['classification']}|\n"
    report+='''
구체적 원인은 [case_summary.csv](case_summary.csv)의 evidence와 사전 ground_truth_reason을 함께 읽어 판단한다. 전체 정확도만으로 보류를 탐지 성공으로 해석하지 않는다. ERROR가 없는 결과와 HTTP 요청 오류가 없는 결과도 다르다. HTTP timeout은 WARNING으로 처리되거나 검사 결과 부재(ERROR)로 이어질 수 있다.

## 7. 영역별 성능과 일반화 한계

|영역|TP/FP/FN/TN|ABSTAIN/ERROR|조건부 Accuracy|Coverage|보수적 Accuracy|
|---|---|---|---:|---:|---:|
'''
    for area,m in result['by_area'].items():
        report+=f"|{area}|{m['TP']}/{m['FP']}/{m['FN']}/{m['TN']}|{m['ABSTAIN']}/{m['ERROR']}|{pct(m['accuracy'])}|{pct(m['coverage'])}|{pct(m['conservative_accuracy'])}|\n"
    report+='''
- 헤더: 기본 구문/존재 검사는 CSP source 허용 강도, unsafe-url 개인정보 노출, Permissions-Policy의 서비스별 제한을 대신하지 못한다. HSTS는 HTTP fixture에서 설정만 관측하며 실제 HTTPS/브라우저 보호 효과를 검증하지 않는다.
- 쿠키: 모든 쿠키에 일괄 HttpOnly 등을 요구하면 JavaScript 접근이 필요한 비민감 선호 쿠키를 오탐할 수 있다. 속성 문법과 쿠키 용도·앱 정책을 분리해야 한다.
- 민감 경로: 파일 형식·본문 서명과 샘플 길이 의존성이 있다. JSON 설정, detached Git HEAD, 다양하게 렌더링된 진단 페이지에 대한 실제 결과를 본문과 대조해야 한다. 보호/리디렉션 상태만으로 최종 노출을 확정할 수 없다.
- SPA/관리자: exact HTML 대조는 동적 nonce를 포함한 공개 SPA를 확정하지 못한다. secret-named 문서 예시는 오탐 위험이 있고 일반 업무 JSON·HTML의 민감 데이터는 키워드만으로 확정하기 어렵다. Cache-Control private는 인증 필요성 자체를 증명하지 않는다.
- CORS: 공개/비공개 계약과 인증 컨텍스트가 필요하다. 반사+credentials만으로 실제 기밀 유출을 확정할 수 없고 null-origin도 별도 검토가 필요하다. wildcard+credentials는 설정 결함이지만 브라우저 credentialed 읽기는 차단된다.
- API 인증: unauthenticated HTTP 200은 공개 엔드포인트와 취약 접근 통제를 구분하지 못한다. 404 또는 Finding 부재를 안전으로 자동 치환하지 않았다. 사용자/역할 간 권한 검사와 로그인 후 흐름은 평가하지 않았다.

## 8. 비용

'''
    report+=f"216회 평균 scan 시간 **{result['timing']['mean']:.6f}초**, P95 **{result['timing']['p95']:.6f}초**. 평균 실제 HTTP 요청 **{result['http_requests']['mean']:.3f}회**, P95 **{result['http_requests']['p95']}회**. 평균 논리 호출 **{result['logical_requests']['mean']:.3f}회**. HTTP 오류 합계 **{result['request_errors']}**, timeout **{result['timeouts']}**, scan 예외 **{result['scan_exceptions']}**.\n"
    report+='''
P95는 nearest-rank이며 fixture 생성·정리, 초기 pytest·해시 검사는 scan 시간에서 제외했다. root HEAD/GET, 민감 경로 GET, SPA control, CORS Origin 확인 및 리디렉션 hop이 요청 비용에 포함된다. 요청 실패는 시간 비용은 있지만 서버 HTTP 이벤트가 없을 수도 있으므로 논리 호출도 함께 보존했다. timeout 사례가 새 corpus에 포함되므로 기존 38개 시간과 직접적인 속도 우열을 주장하지 않는다.
모든 스캔 대상은 127.0.0.1이며 socket connect에 loopback guard를 적용했다. 본문의 외부 예시 URL과 Origin 문자열은 요청 대상이 아니다. 외부 문서는 요구사항 참고용으로만 열었고 외부 서비스에 스캔하지 않았다.

## 9. 후속 개선 후보

1. 공개/비공개 API, 관리자 데이터, 쿠키 용도 등 명시적 앱 정책 입력과 관측 신뢰도를 분리한다. 공개 예제 필드와 실제 기밀의 구분을 우선 검토한다.
2. API 인증의 다중 사용자/역할 컨텍스트와 CORS credentialed browser 검증을 별도 승인된 로컬 환경에 추가한다.
3. 정책 강도(CSP/Referrer/Permissions), JSON·HTML·바이너리 민감 파일과 sample-boundary에 대한 판정을 확장한다.
4. 동적 SPA 비교와 오류/timeout/판정 부재 표현을 개선하되 보류를 안전 또는 탐지 성공으로 바꾸지 않는다.

이번에는 후보만 기록했으며 제품 수정은 하지 않았다. 후속 개선 단계로 진행할 수 있으나 main 병합은 사용자 승인 전 수행하지 않는다. 이 평가 결과는 현재 구현의 한계를 포함해 그대로 보존한다.

## 10. 독립성·수정 이력·재현성

동일 작성자가 제품 개선과 corpus 작성 모두를 수행했으므로 완전한 외부 블라인드 검증은 아니다. 관측 가능한 구조를 알고 설계한 구성 시험이며 통계적 모집단 일반화 신뢰구간을 제공하지 않는다. TLS·브라우저·실제 로그인·실제 개인정보를 사용하지 않았다. 모든 자격 증명과 레코드는 합성이다.
초기 무결성 도구가 2차 결과에 존재하지 않는 history_manifest 경로를 가정해 사전 준비 단계에서 중단됐다. [수정 전 runner](runner_before_initialization_fix.py), [수정 이유](harness_changes.log)를 보존했다. 존재하는 과거 history manifest와 별도 before snapshot을 확인하도록 고쳤고 초기 해시를 유지해 재개했다. 이 오류는 사전 등록 및 신규 스캐너 실행 전에 발생했으며 fixture·정답·집계 정책과 결과에 영향을 주지 않았다. 이후 평가 중 도구 수정은 수행하지 않았다.

재현 순서: `python tools/validation/independent_evaluation.py initialize`, `... freeze`, `... run`, `python tools/validation/independent_report.py`.
이미 존재하는 trial은 덮어쓰지 않도록 중단한다. 재실행은 저장소 사본에서 기존 평가 디렉터리를 별도로 보존한 후 수행한다. `verify`는 현재 대상·기존 결과·고정 입력을 다시 검사한다. 랜덤 포트·임의 경로와 타이밍은 달라질 수 있다.
원시 결과 [runs/](runs/), [반복 로그](execution.log), [시행 CSV](run_summary.csv), [사례 CSV](case_summary.csv), [영역 CSV](area_summary.csv), [지표 JSON](summary.json), [비교 JSON](comparison.json), [완료 기록](completion.json)을 함께 보존한다.
'''
    (OUT/'README.md').write_text(report,encoding='utf-8')
    (OUT/'methodology.md').write_text('사전 평가 정책과 정답: [policy.json](policy.json), [cases.json](cases.json), [사전 해시](preregistration.json).\n'
                                     '집계 수식·분모·미확정 사례·관측 가능성·한계 및 재현 절차는 [보고서](README.md)에 기록한다.\n',encoding='utf-8')
    raw=[p for p in (OUT/'runs').glob('*.json')]+[OUT/'execution.log',OUT/'completion.json',OUT/'summary.json',OUT/'case_summary.csv',OUT/'run_summary.csv']
    write('result_hashes.json',{str(p.relative_to(OUT)):sha(p) for p in raw})
    verify()
    (OUT/'verification.log').write_text('PASS: target/test/config hashes, all 447 prior artifacts, preregistered inputs unchanged.\n'
                                       'PASS: 72 distinct cases, 60 binary labels, 12 unknown; 216 distinct case/repeat pairs.\n'
                                       'PASS: truth and selected scopes from preregistration; all logical targets loopback.\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('metrics','warning_negative','by_area','unknown_status_counts','consistency','timing','http_requests','request_errors','timeouts','scan_exceptions')},indent=2))


if __name__=='__main__':
    main()
