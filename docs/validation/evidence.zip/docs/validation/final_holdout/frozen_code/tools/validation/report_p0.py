"""Compare frozen policies without counting review signals as detections."""
import csv
from dataclasses import asdict
import json
import shutil

from independent_report import metrics, stats
from p0_validation import ROOT, OUT, check
import independent_evaluation as ie
from websecscope.analyzer.cve import analyze_cves
from websecscope.models import Finding

DOWNSTREAM=[]


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')


def summarize_independent(rows):
    first=[r for r in rows if r['repeat']==1]
    return dict(metrics=metrics(first),warning_negative=metrics(first,True),
                timing=stats([r['seconds'] for r in rows]),http_requests=stats([r['http_requests'] for r in rows]),
                logical_requests=stats([r['logical_requests'] for r in rows]),
                total_http=sum(r['http_requests'] for r in rows),total_logical=sum(r['logical_requests'] for r in rows),
                errors=sum(r['errors'] for r in rows),timeouts=sum(r['timeouts'] for r in rows),
                scan_exceptions=sum(r['exception'] is not None for r in rows),
                unknown=[dict(id=r['case_id'],status=r['status']) for r in first if not r['evaluable']],
                by_area={a:metrics([r for r in first if r['area']==a]) for a in sorted({r['area'] for r in rows})})


def summarize_fixed(data):
    cases={c['id']:c for c in data['cases']}
    first=[dict(r,evaluable=cases[r['case_id']]['vulnerable'] is not None,
                truth='vulnerable' if cases[r['case_id']]['vulnerable'] else 'safe')
           for r in data['runs'] if r['repeat']==1]
    return dict(metrics=metrics(first),warning_negative=metrics(first,True),timing=data['timing'],
                non_fault=stats([r['seconds'] for r in data['runs'] if not r['case_id'].startswith('E-')]),
                total_http=sum(len(r['server_events']) for r in data['runs']),
                total_logical=sum(len(r['requests']) for r in data['runs']),
                errors=data['request_errors'],timeouts=data['timeout_errors'],scan_exceptions=data['scan_exceptions'])


def audit_findings(old,new):
    """Only intended 404 findings and null CORS substitution may differ."""
    null=any(f['check_id'].startswith('CORS_NULL_ORIGIN_') for f in new['findings'])
    old_retained=[f for f in old['findings'] if not (null and f['check_id']=='CORS_BASELINE')]
    new_retained=[f for f in new['findings'] if f.get('metadata',{}).get('reason_code')!='NOT_FOUND_AUTH_UNASSESSED'
                  and not f['check_id'].startswith('CORS_NULL_ORIGIN_')]
    old_inventory=[f for f in old_retained if f['check_id']=='CVE_SERVICE_INVENTORY']
    new_inventory=[f for f in new_retained if f['check_id']=='CVE_SERVICE_INVENTORY']
    if old_inventory!=new_inventory:
        # Prove the downstream difference using the unchanged analyzer with lookup
        # disabled. This is pure replay of recorded findings, with no HTTP.
        for row,inventory in ((old,old_inventory),(new,new_inventory)):
            _,expected=analyze_cves([Finding(**f) for f in row['findings'] if f['category']!='cve'],enabled=False)
            assert [asdict(f) for f in expected]==inventory
        DOWNSTREAM.append(dict(id=new['case_id'],repeat=new['repeat'],before=old_inventory,after=new_inventory))
        old_retained=[f for f in old_retained if f['check_id']!='CVE_SERVICE_INVENTORY']
        new_retained=[f for f in new_retained if f['check_id']!='CVE_SERVICE_INVENTORY']
    assert old_retained==new_retained,(new['case_id'],new['repeat'])


def compare_rows(old,new):
    lookup={(r['case_id'],r['repeat']):r for r in old}
    assert len(lookup)==len(new)
    changes=[]
    for r in new:
        prev=lookup[r['case_id'],r['repeat']]
        audit_findings(prev,r)
        if (prev['status'],prev['classification'])!=(r['status'],r['classification']):
            changes.append(dict(id=r['case_id'],repeat=r['repeat'],before_status=prev['status'],after_status=r['status'],
                                before_classification=prev['classification'],after_classification=r['classification']))
    return changes


def main():
    check()
    assert not (OUT/'comparison.json').exists(),'No overwrite'
    old_fixed=load(ROOT/'docs/validation/improvement_04/results/baseline_results.json')
    new_fixed=load(OUT/'fixed/baseline_results.json')
    assert old_fixed['cases']==new_fixed['cases']
    fixed_changes=compare_rows(old_fixed['runs'],new_fixed['runs'])
    assert fixed_changes==[]
    old_dir=ROOT/'docs/validation/independent_evaluation'
    new_dir=OUT/'independent'
    assert ie.sha(old_dir/'cases.json')==ie.sha(new_dir/'cases.json')
    assert ie.sha(old_dir/'policy.json')==ie.sha(new_dir/'policy.json')
    old=[load(p) for p in sorted((old_dir/'runs').glob('*.json'))]
    new=[load(p) for p in sorted((new_dir/'runs').glob('*.json'))]
    assert len(old)==len(new)==216
    changes=compare_rows(old,new)
    assert {c['id'] for c in changes}=={'IE-AUTH-05','IE-CORS-10'}
    assert len(changes)==6
    for r in new:
        prev=next(p for p in old if p['case_id']==r['case_id'] and p['repeat']==r['repeat'])
        assert r['truth']==prev['truth'] and r['evaluable']==prev['evaluable']
    stable=0
    for cid in {r['case_id'] for r in new}:
        group=[r for r in new if r['case_id']==cid]
        stable+=len({(r['status'],tuple(sorted((f['check_id'],f['status']) for f in r['selected']))) for r in group})==1
    before=summarize_independent(old)
    after=summarize_independent(new)
    fb,fa=summarize_fixed(old_fixed),summarize_fixed(new_fixed)
    assert before['metrics']['TP']==after['metrics']['TP']==16
    assert before['metrics']['conservative_accuracy']==after['metrics']['conservative_accuracy']
    assert before['total_http']==after['total_http'] and fb['total_http']==fa['total_http']
    changed_existing=[rel.replace('\\','/') for rel,h in load(OUT/'before_hashes.json').items() if ie.sha(ROOT/rel)!=h]
    assert changed_existing==['websecscope/analyzer/api_auth_analyzer.py']
    score_changes=[dict(id=r['case_id'],before=next(p['security_score'] for p in old_fixed['runs'] if p['repeat']==1 and p['case_id']==r['case_id']),
                        after=r['security_score']) for r in new_fixed['runs'] if r['repeat']==1]
    score_changes=[c for c in score_changes if c['before']!=c['after']]
    payload=dict(fixed=dict(before=fb,after=fa,changes=fixed_changes),
                 independent_development_regression=dict(before=before,after=after,changes=changes,consistency=stable/72),
                 changed_existing_sources=changed_existing,score_changes=score_changes,
                 unchanged_fixtures_truth_selectors_metrics=True,
                 unrelated_findings_identical_except_documented_cve_inventory=True,downstream_cve_inventory_changes=DOWNSTREAM,
                 historical_artifacts_unchanged=True,no_additional_http=True)
    write('comparison.json',payload)
    rows=[]
    for r in new:
        p=next(x for x in old if x['case_id']==r['case_id'] and x['repeat']==r['repeat'])
        rows.append(dict(id=r['case_id'],repeat=r['repeat'],truth=r['truth'],evaluable=r['evaluable'],before=p['status'],after=r['status'],
                         before_classification=p['classification'],after_classification=r['classification'],
                         seconds=r['seconds'],http_requests=r['http_requests'],logical_requests=r['logical_requests'],
                         errors=r['errors'],timeouts=r['timeouts'],check_ids=';'.join(f['check_id'] for f in r['selected'])))
    with (OUT/'independent_summary.csv').open('w',encoding='utf-8-sig',newline='') as file:
        w=csv.DictWriter(file,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    pct=lambda v:'N/A' if v is None else f'{v*100:.2f}%'
    report='''# P0 개선: HTTP 404 인증 관측 및 literal null CORS 검토

## 변경 범위와 근거

브랜치 `improve/sensitive-path-validation`에서 P0 두 분기만 수정했다. 기존 코드·테스트·도구 87개 소스와 과거 자료 773개 파일의 해시를 보존했다. 기존 153개 pytest는 수정 전에 통과했고 기존 테스트 소스는 변경하지 않았다.

변경한 기존 제품 파일은 `websecscope/analyzer/api_auth_analyzer.py` 하나다. `_analyze_auth_access`는 404 관측이 수집·분석됐으나 어느 상태 분기에서도 Finding을 만들지 않았고, `_analyze_cors`는 ACAO 문자열 null이 wildcard/반사 분기를 지나 baseline PASS가 되는 문제가 있었다.

- 인증404: 기존 `AUTH_MAY_BE_MISSING_{path}` ID로 WARNING을 생성한다. 제목과 description은 경로 없음으로 인증을 판단하지 못했다는 의미이며 http_status=404/path/reason_code=NOT_FOUND_AUTH_UNASSESSED/authentication_assessed=false를 metadata에 기록한다. 다른 불완전 응답/401/403/200 분기는 유지한다.
- literal null: `CORS_NULL_ORIGIN_{path}` WARNING을 생성한다. 응답 ACAO 문자열 null과 요청 Origin 부재를 구분하며, 기록된 probe Origins와 실제 Origin:null 요청 기록 여부, 브라우저 악용 미검증을 남긴다. credentials/민감 데이터만으로 FAIL을 자동 확정하지 않는다.
- 새 literal-null HTTP probe는 추가하지 않았다. 기존 collector가 보내던 HTTPS Origin probe는 그대로이며 `Origin: null`을 실제 전송/검증했다고 주장하지 않는다.
- 쿠키·헤더 강도·민감 경로·SPA·인증 정책 입력·수집·orchestrator·Finding 모델·score 규칙은 변경하지 않았다.

[P0만의 diff](p0_only.patch)를 변경 검토에 사용한다. [전체 작업 트리 diff](changes.patch)는 앞선 개선도 포함하므로 이번 P0 범위와 혼동하지 않는다. 수정 전 소스는 [before/](before/), 측정 버전 해시는 [measured_source_hashes.json](measured_source_hashes.json), 환경/Git은 [environment.json](environment.json), [git_before.log](git_before.log)에 있다.

## check_id와 결과 호환성

인증은 기존 ID를 재사용해 frozen auth_access selector가 그대로 WARNING을 선택한다. CORS는 literal null을 반사라고 표현하지 않도록 새 `CORS_NULL_ORIGIN_*` ID를 추가했다. 기존 selector가 category=cors 전체를 선택하므로 매핑 변경은 필요하지 않았다. 기존 Finding/JSON 필드와 모델은 유지하고 metadata만 추가했다.
신규 CORS ID를 외부 시스템이 고정 allowlist로 필터링하면 별도 등록이 필요하다. 표준 category와 generic Finding 직렬화에는 호환된다.

## 테스트

새 `tests/test_p0_auth_null_origin.py`의20개 테스트는 인증404/401/403/200·비대상 경로, ACAO literal null/누락, Origin 요청 부재, 임의 반사, 공개 CORS, 혼합 결과 및 frozen selector 호환을 검증한다. loopback 테스트에서 null 응답을 받아도 추가 literal-null 요청이 발생하지 않는지 확인한다.
직접 수행한 전체 pytest는173개 통과했다. 고정 corpus 실행 끝에도 전체 pytest를 수행했다.

'''
    report+='```text\n'+(OUT/'fixed/regression.log').read_text(encoding='utf-8').strip()+'\n```\n'
    report+='''
## 평가 정책과 재현

고정38개 보안+가용성3개를 각3회(123회), 원래 독립72개를 각3회(216회) 실행했다. 72개는 이미 설계에 사용됐으므로 **개발·회귀 세트**이며 새 미사용 holdout이 아니다. raw fixture/정답/관측 가능성/selector/정책은 변경하지 않았다. 미확정12개는 이진 지표에서 제외한다.
정확도는 첫 반복, 시간·요청과 일치율은 전체 반복 기준이다. FAIL=양성/PASS=음성/WARNING=ABSTAIN/빈 결과 또는 예외=ERROR, 분모0=N/A이다. 조건부 Accuracy/Recall은 보류·오류를 제외하고, Coverage는 이진 판정/라벨 수, 보수적 Accuracy=(TP+TN)/라벨 수이다. ERROR→WARNING 및 FN→WARNING은 탐지 성공이 아니다.

기존 runner/fixture/계산 함수는 파일을 고치지 않고 재사용했다. `p0_validation.py` adapter는 출력 경로와 무결성 guard만 런타임에 교체하며 새 측정 소스 해시와 과거 전체 파일 해시를 검사한다. 원래 독립 runner의 guard는 제품 변경 후 실패하는 것이 정상이며 기존 manifest를 고치지 않았다. copied cases.json/policy.json은 원본 SHA와 같다. 기존 사전등록 원문도 original_preregistration.json으로 함께 보존했다.

재현 명령은 `python tools/validation/p0_validation.py initialize`, `... freeze`, `... fixed`, `... independent`, `python tools/validation/report_p0.py`다. 이미 있는 결과는 덮어쓰지 않는다. 새 작업 디렉터리/저장소 사본에서 해당 버전과 snapshot을 보존하여 재현한다. 모든 스캔은 loopback이다.

## 기존 고정38개 회귀

|지표|4차|P0|
|---|---:|---:|
'''
    for k in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','ABSTAIN','ERROR','conservative_accuracy'):
        fmt=pct if k in {'precision','recall','fpr','accuracy','coverage','conservative_accuracy'} else str
        report+=f"|{k}|{fmt(fb['metrics'][k])}|{fmt(fa['metrics'][k])}|\n"
    report+='\n38개 selected 판정과 가용성3개 판정은 세 반복 모두 동일하다. O-01=PASS, O-02=FAIL, O-03=WARNING, O-04=WARNING을 유지했다.\n'
    report+='''
## 독립72개 개발·회귀 재평가

|지표(라벨60개)|원래 독립 평가|P0|
|---|---:|---:|
'''
    for k in ('TP','FP','FN','TN','precision','recall','fpr','accuracy','coverage','ABSTAIN','ERROR','conservative_accuracy'):
        fmt=pct if k in {'precision','recall','fpr','accuracy','coverage','conservative_accuracy'} else str
        report+=f"|{k}|{fmt(before['metrics'][k])}|{fmt(after['metrics'][k])}|\n"
    report+='''
|사례|이전|P0|해석|
|---|---|---|---|
|IE-AUTH-05|ERROR / 결과 없음|WARNING / ABSTAIN|인증 안전성을 확인한 것이 아니라404 관측 결과 누락 해소|
|IE-CORS-10|PASS / FN|WARNING / ABSTAIN|null 허용을 검토로 남기며 기밀 유출을 확정하지 않음|

나머지70개 판정은 그대로이며 미확정12개 모두 WARNING을 유지했다. 반복 판정 일치율은100%다. TP는16으로 그대로이고 보수적 Accuracy도35/60 그대로다. 조건부 Accuracy/Recall 상승은 FN1개가 보류로 빠진 효과가 포함되므로 탐지력 향상으로 쓰지 않는다. 이진 Coverage는 오히려1/60 감소한다. 기존 FP2와 나머지FN3은 이번 범위 밖으로 그대로 남는다.

## 성능과 요청 수

|항목|이전|P0|
|---|---:|---:|
'''
    for label,b,a in [('고정123회 평균 초',fb['timing']['total']['mean'],fa['timing']['total']['mean']),
                      ('고정123회 P95 초',fb['timing']['total']['p95'],fa['timing']['total']['p95']),
                      ('고정 장애 제외 평균 초',fb['non_fault']['mean'],fa['non_fault']['mean']),
                      ('고정 장애 제외 P95 초',fb['non_fault']['p95'],fa['non_fault']['p95']),
                      ('72개216회 평균 초',before['timing']['mean'],after['timing']['mean']),
                      ('72개216회 P95 초',before['timing']['p95'],after['timing']['p95']),
                      ('72개 평균 HTTP 요청',before['http_requests']['mean'],after['http_requests']['mean'])]:
        report+=f'|{label}|{b:.6f}|{a:.6f}|\n'
    for label,b,a in [('고정 실제 HTTP',fb['total_http'],fa['total_http']),('고정 논리 호출',fb['total_logical'],fa['total_logical']),
                      ('72개 실제 HTTP',before['total_http'],after['total_http']),('72개 논리 호출',before['total_logical'],after['total_logical']),
                      ('고정 오류/timeout',(fb['errors'],fb['timeouts']),(fa['errors'],fa['timeouts'])),
                      ('72개 오류/timeout',(before['errors'],before['timeouts']),(after['errors'],after['timeouts']))]:
        report+=f'|{label}|{b}|{a}|\n'
    report+='''
기존 측정과 동일한 candidate/timeout/반복/계측 조건이다. 추가 HTTP는0이며 기존 collector 소스도 동일하다. 시간은 fixture 생성/정리를 제외한 scan 시간이지만 서로 다른 시각의 측정이므로 스케줄링·실행 환경 변동이 있다. 작은 시간 차이를 두 분기의 인과적 성능 비용으로 단정하지 않는다. nearest-rank P95를 사용했다.

## 회귀 범위와 부수 영향

모든 trial의 기존 Finding을 대조했다. P0 직접 변화 외에 새404 evidence의 Server 제품/버전이 기존 CVE inventory 추출에 공급되는 부수 변화가 있었다. lookup은 disabled지만 기존 CVE 분석기는 후보 목록을 먼저 구성하므로 inventory status/서비스 목록이 달라질 수 있다. 이전/이후 raw Finding을 각각 변경되지 않은 analyze_cves(enabled=False)에 순수 재입력해 해당 부수 결과를 재현했다. 이 검증에는 네트워크 요청이 없었다. 그 변화와 P0 직접 Finding을 제외한 결과는 완전히 동일하다.
최초 보고 도구는 부수 변화까지 동일하다고 가정한 assertion에서 중단됐다. 수정 전 보고 도구와 이유를 report_before_audit_fix.py/report_audit_failure.log로 보존하고 감사 항목만 보완했다. raw trials·제품·정답·집계 정책은 고치거나 재실행하지 않았다. 부수 변화 전체는 comparison.json에 별도 기록했다.
404 LOW WARNING을 추가했으므로 Finding 개수와 security score도 과거와 같지 않다. 기존 score 규칙은 수정하지 않았다. CVE inventory는 실제 취약점 lookup/검증 성공이 아니며 그 PASS를 보안 개선으로 해석하면 안 된다.
'''
    report+='\n고정 첫 반복의 score 변경: `'+json.dumps(score_changes,ensure_ascii=False)+'`.\n'
    report+='''
## 남은 한계와 다음 단계

404는 라우팅·의도적 은닉·보호 여부를 구별하지 못하며 WARNING으로만 관측한다. 이 요청이 인증을 통과했다거나 안전하다고 하지 않는다. 모든 다른 상태의 결과 완전성까지 확장하지 않았다.
literal null은 설정 검토 신호다. 공개/비공개 정책·실제 Origin:null·인증 credential·브라우저 CORS 읽기 검증은 수행하지 않았다. 중첩 probe 정보가 없는 과거 외부 입력은 실제 요청 수행 여부를 알 수 없으므로 기록된 probe 기준의 한계로 표현한다.
정책 입력, 쿠키 용도, CSP 강도, 데이터 의미, 동적SPA 및 샘플 경계 개선은 이번에 하지 않았다. 후속 설계는 가능하나 기존72개 결과를 새 일반화 점수로 주장하지 않는다. main 병합은 사용자 확인 전 수행하지 않는다.

원시 데이터: [고정 JSON](fixed/baseline_results.json), [고정 CSV](fixed/baseline_summary.csv), [고정 실행 로그](fixed/execution.log), [고정 검증](fixed/verification.log), [개발회귀216개 raw](independent/runs/), [반복 로그](independent/execution.log), [개발회귀 CSV](independent_summary.csv), [비교 JSON](comparison.json).
'''
    (OUT/'README.md').write_text(report,encoding='utf-8')
    # Preserve the final target/tests and new harness for reproducibility.
    for rel,h in load(OUT/'measured_source_hashes.json').items():
        dest=OUT/'after'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/rel,dest)
        assert ie.sha(dest)==h
    for name in ('p0_validation.py','report_p0.py'):
        dest=OUT/'harness'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'tools/validation'/name,dest)
    check()
    write('audit.json',dict(history_files=len(load(OUT/'history_hashes.json')),all_historical_hashes_unchanged=True,
          changed_existing=changed_existing,fixed_trials=123,development_trials=216,selector_policy_unchanged=True,
          unrelated_findings_unchanged_except_documented_cve_inventory=True,
          downstream_cve_inventory_changed_trials=len(DOWNSTREAM),additional_http=0,regression_exit=new_fixed['regression_exit_code']))
    files=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='artifact_manifest.json']
    write('artifact_manifest.json',{str(p.relative_to(OUT)):ie.sha(p) for p in files})
    print(json.dumps(dict(fixed=fa['metrics'],independent=after['metrics'],before_independent=before['metrics'],
                         timing=dict(fixed=fa['timing']['total'],independent=after['timing']),
                         requests=dict(fixed=fa['total_http'],independent=after['total_http']),score_changes=score_changes),indent=2))


if __name__=='__main__':
    main()
