"""Audit unchanged v1 contracts and generate a before/after report from logs."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import subprocess
import sys
from pathlib import Path

from improvement import ROOT, DOC, ARCHIVE, AFTER, check_archive
from baseline import metrics


def summary(values):
    values = sorted(values)
    return dict(n=len(values), mean=statistics.mean(values), p95=values[math.ceil(.95*len(values))-1])


def main():
    manifest = check_archive()
    archived_verify = subprocess.run([sys.executable, str(ARCHIVE/'tools/validation/verify.py')],
                                     cwd=ROOT, capture_output=True, text=True)
    (AFTER/'verification_v1_archived.log').write_text(
        f'Exit code: {archived_verify.returncode}\n'+archived_verify.stdout+archived_verify.stderr, encoding='utf-8')
    assert archived_verify.returncode == 0, archived_verify.stderr
    before = json.loads((ARCHIVE/'docs/validation/results/baseline_results.json').read_text(encoding='utf-8'))
    after = json.loads((AFTER/'baseline_results.json').read_text(encoding='utf-8'))
    assert before['cases'] == after['cases']
    assert after['production_and_existing_tests_unchanged']
    changed = []
    for name, digest in manifest.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != digest:
            changed.append(name)
    assert set(changed) == {'websecscope/scanner/web.py','tools/validation/verify.py'}, changed
    for name, digest in after['source_hashes'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest, name
    assert 'HTTP_TIMEOUT_SECONDS = 1' in (ROOT/'websecscope/scanner/web.py').read_text(encoding='utf-8')
    first = [r for r in after['runs'] if r['repeat']==1]
    assert metrics(first) == after['metrics']
    assert len(after['runs']) == len(before['runs']) == 123
    assert len({(r['case_id'],r['repeat']) for r in after['runs']}) == 123
    for c in after['cases']:
        rows = [r for r in after['runs'] if r['case_id']==c['id']]
        assert len(rows) == (0 if c['config'].get('unsupported') else 3)
        assert len({(r['status'],r['classification']) for r in rows}) <= 1
    with (AFTER/'baseline_summary.csv').open(encoding='utf-8-sig', newline='') as file:
        csvrows = list(csv.DictReader(file))
    assert len(csvrows) == 123
    for row, r in zip(csvrows, after['runs']):
        assert (row['case_id'], int(row['repeat']), row['classification'], float(row['seconds'])) == (r['case_id'], r['repeat'], r['classification'], r['seconds'])
    assert sum(r['request_errors'] for r in after['runs']) == after['request_errors']
    assert sum(r['timeout_errors'] for r in after['runs']) == after['timeout_errors']
    # Check the native API/Auth observation semantics separately from web changes.
    api_auth_changed = []
    for old, new in zip(before['runs'], after['runs']):
        assert (old['case_id'], old['repeat']) == (new['case_id'], new['repeat'])
        if not old['case_id'].startswith(('P-', 'E-')):
            assert (old['status'], old['classification']) == (new['status'],new['classification'])
        # API/Auth requests have their own timings/ports; compare findings by semantic content.
        old_f = [f for f in old['findings'] if f['category'] != 'web']
        new_f = [f for f in new['findings'] if f['category'] != 'web']
        if old_f != new_f:
            api_auth_changed.append((new['case_id'],new['repeat']))
    assert not api_auth_changed, api_auth_changed
    fmt = lambda x: 'N/A' if x is None else f'{x*100:.2f}%'
    data = dict(before_metrics=before['metrics'], after_metrics=after['metrics'],
                changed_original_files=changed, unchanged_contract=True, unchanged_api_auth_findings=True,
                before_timing=before['timing'], after_timing=after['timing'])
    report = '''# 민감 경로 1차 개선 — 실제 재측정 비교

## 변경 범위와 원본 보존

작업 시작 시 main 브랜치였고 `docs/validation/`, `tools/`만 untracked였다. 작업 브랜치는 `improve/sensitive-path-validation`이며 커밋·main 병합은 수행하지 않았다. [v1 보존 manifest](../baseline_v1/manifest.json)는 원본 결과 JSON/CSV·문서·로그·검증 도구·프로덕션 소스·기존 테스트 73개 파일의 SHA-256을 포함한다. `baseline_v1/verification_before_changes.log`는 소스 변경 전 verify.py 성공 기록이다. 원래 `docs/validation/results/`와 v1 문서는 덮어쓰지 않았다.

변경한 진단 파일은 `websecscope/scanner/web.py` 하나다. `_request`는 GET 본문을 최대 4096바이트 읽고 HTTP 상태·본문 읽기 실패를 구분한다. HEAD는 본문을 읽지 않는다. `_scan_sensitive_paths`는 기존 5개 후보 각각 HEAD와 GET을 요청하고, 루트 GET 및 무작위 존재하지 않는 경로 GET을 대조군으로 추가한다. 후보·대조군 모두 리디렉션을 따라가지 않는다. 기존 타임아웃 1초와 후보 경로는 유지한다.

신규 `_classify_sensitive_response`는 .env 할당문, Git HEAD 참조/객체 ID, ZIP 매직, phpinfo 진단 표식에 대한 일반 형식 검사를 한다. 특정 fixture 문자열이나 사례 ID는 사용하지 않는다. 두 대조군과 동일한 HTML이면 SPA로 분리한다. 다른 성공 응답·관리자 로그인 UI는 근거 부족 WARNING이다. 401/403·리디렉션은 WARNING을 유지한다. 500 등 서버 오류는 WARNING이며 전송 실패와 구분한다. 오류를 조용히 생략하지 않는다. GET 404/410은 부재 근거이며 HEAD 200을 노출로 확정하지 않는다. HEAD 404 뒤 GET에서도 내용 검증을 수행한다.

Finding 모델·check_id·orchestrator 인터페이스는 그대로다. metadata.paths에 HEAD/GET별 상태·오류·Location·표본 길이/해시·상태 차이 여부 및 판정 이유, metadata.controls에 대조군 관측, complete에 네트워크 검사 완료 여부를 추가했다. 민감 본문 원문은 finding에 넣지 않는다. 다른 API/Auth 모듈의 코드와 이번 전체 123회 API/Auth finding 내용이 모두 동일함을 비교했다.

측정 도구 `baseline.py`와 `report.py`는 byte 단위로 동일하다. `verify.py`에는 결과 디렉터리를 선택하는 `--results` 인자만 추가했고 기존 검증 조건은 유지했다. 신규 `improvement.py`는 보존/실행, `compare_improvement.py`는 계약·해시·지표·반복·API/Auth 결과 비교와 문서 생성을 담당한다. `pytest.ini`는 보존된 과거 tests 중복 수집을 막기 위해 실제 `tests/`를 수집 대상으로 지정한다.

## 정량 결과

양쪽 모두 동일한 41개 사례 × 3회 = 123회, 보안 정답 38개/가용성 3개, 미지원 선언 1개 미실행이다. 첫 회만 정확도 집계하며 WARNING=ABSTAIN, ERROR 및 가용성 제외, 분모 0=N/A 정책을 변경하지 않았다. 불리한 사례를 삭제하지 않았다.

|지표|v1|개선 후|
|---|---|---|
'''
    for key in ('TP','FP','FN','TN','abstained','errors','excluded','coverage','precision','recall','fpr','accuracy'):
        f = fmt if key in {'coverage','precision','recall','fpr','accuracy'} else str
        report += f"|{key}|{f(before['metrics'][key])}|{f(after['metrics'][key])}|\n"
    report += '\n|항목|전 TP/FP/FN/TN/ABSTAIN|후 TP/FP/FN/TN/ABSTAIN|전 Accuracy|후 Accuracy|\n|---|---|---|---|---|\n'
    for family in before['by_family']:
        b, a = before['by_family'][family], after['by_family'][family]
        counts = lambda v: '/'.join(str(v[k]) for k in ('TP','FP','FN','TN','abstained'))
        report += f"|{family}|{counts(b)}|{counts(a)}|{fmt(b['accuracy'])}|{fmt(a['accuracy'])}|\n"
    report += '\n## P-01부터 P-09까지 개별 판정\n\n|사례|정답|v1|개선 후|개선 후 상세 판정|\n|---|---|---|---|---|\n'
    for r in first:
        if r['case_id'].startswith('P-'):
            old = next(v for v in before['runs'] if v['case_id']==r['case_id'] and v['repeat']==1)
            c = next(c for c in after['cases'] if c['id']==r['case_id'])
            path_results = ', '.join(f"{p['path']}={p['outcome']}" for p in r['selected'][0]['metadata']['paths'])
            report += f"|{r['case_id']}|{'취약' if c['vulnerable'] else '정상'}|{old['status']} / {old['classification']}|{r['status']} / {r['classification']}|{path_results}|\n"
    report += '\n500의 FP 제거는 정상 PASS 확정이 아니라 WARNING 보류 전환이다. coverage와 ABSTAIN을 함께 봐야 하며, 이진 지표만으로 해결을 과장하지 않는다.\n'
    report += '\n## 실행 성능과 추가 요청 비용\n\n|구간|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|평균 증가율|\n|---|---|---|---|---|---|\n'
    for name in ['total'] + list(before['timing']['modules']):
        b = before['timing']['total'] if name=='total' else before['timing']['modules'][name]
        a = after['timing']['total'] if name=='total' else after['timing']['modules'][name]
        report += f"|{name}|{b['mean']:.6f}|{a['mean']:.6f}|{b['p95']:.6f}|{a['p95']:.6f}|{(a['mean']/b['mean']-1)*100:.1f}%|\n"
    bnorm = summary([r['seconds'] for r in before['runs'] if not r['case_id'].startswith('E-')])
    anorm = summary([r['seconds'] for r in after['runs'] if not r['case_id'].startswith('E-')])
    data['before_non_fault_timing'], data['after_non_fault_timing'] = bnorm, anorm
    report += f"\n의도적 장애 E-* 제외한 각 {bnorm['n']}회: 평균 {bnorm['mean']:.6f} → {anorm['mean']:.6f}초 ({(anorm['mean']/bnorm['mean']-1)*100:.1f}% 증가), P95 {bnorm['p95']:.6f} → {anorm['p95']:.6f}초. 동일 사례 3회라 P95는 nearest-rank, 사례별로는 최댓값이며 통계적 신뢰도는 제한된다.\n"
    old_q, new_q = sum(len(r['requests']) for r in before['runs']), sum(len(r['requests']) for r in after['runs'])
    data['request_counts'] = dict(before=old_q,after=new_q,additional=new_q-old_q)
    report += f"\n논리 HTTP 요청 총수 {old_q} → {new_q}건 (+{new_q-old_q}). 루트 도달 가능한 실행마다 추가 GET 7건(후보 5건 + 대조군 2건)이다. HEAD를 제거하지 않아 이 비용이 그대로 추가된다. 소켓 timeout은 바꾸지 않았으며 느린 후보에 HEAD/GET 각각 timeout이 누적된다.\n"
    report += '\n|항목|v1|개선 후|\n|---|---|---|\n'
    for key in ('request_errors','timeout_errors','scan_exceptions'):
        report += f"|{key}|{before[key]}|{after[key]}|\n"
    report += '\n|사례|전 평균(초)|후 평균(초)|전 P95(초)|후 P95(초)|\n|---|---|---|---|---|\n'
    for r in first:
        b = summary([v['seconds'] for v in before['runs'] if v['case_id']==r['case_id']])
        a = summary([v['seconds'] for v in after['runs'] if v['case_id']==r['case_id']])
        report += f"|{r['case_id']}|{b['mean']:.6f}|{a['mean']:.6f}|{b['p95']:.6f}|{a['p95']:.6f}|\n"
    report += '''
## 회귀 테스트와 검증 결과

신규 `tests/test_sensitive_paths_content.py`는 v1 fixture와 다른 Git release 참조/해시, DATABASE_URL 환경 할당, ZIP 바이트, PHP 진단 HTML, 로그인 UI, 텍스트 catch-all, 405/410/503/307/206, 대조군 실패, HEAD/GET 오류·불일치, 4096바이트 읽기 제한, HTTP 응답 이후 본문 timeout을 검사한다. 기존 테스트 파일은 수정하지 않았다.

`python -m pytest -q` 실제 출력:

```text
'''
    report += (AFTER/'regression.log').read_text(encoding='utf-8') + '\n```\n'
    report += '''
기존 `test_sensitive_path_200_is_exposed`는 본문 없는 mock 200 응답에 FAIL/HIGH를 요구한다. 새 요구사항인 “200만으로 노출 확정 금지”와 충돌하므로 WARNING이 나온다. 이 테스트를 삭제·기대값 변경·xfail 처리하지 않았다. 따라서 전체 회귀는 통과 상태가 아니며 이 충돌을 합의해 수정하기 전 병합 준비 완료로 보지 않는다.

`verify.py --results docs/validation/improvement_01/results` 실제 출력:

```text
'''
    report += (AFTER/'verification.log').read_text(encoding='utf-8')+'\n```\n'
    report += '''
verify.py는 지표·해시·반복·CSV 검사 이후 regression_exit_code==0 조건에서 실패한다. 실패를 성공으로 바꾸지 않았다. 보존된 v1 자체는 `python docs/validation/baseline_v1/tools/validation/verify.py`로 다시 검증해 통과했다([로그](results/verification_v1_archived.log)). 별도 비교 감사는 원본 보존·계약·후보·타임아웃·반복 안정성·CSV/JSON·해시·API/Auth 결과 일치를 검증하며 회귀 통과를 주장하지 않는다. 자세한 감사 출력은 [comparison_verification.log](results/comparison_verification.log)에 있다.

## 남은 오탐·미탐과 한계

'''
    for r in first:
        if r['classification'] in {'FP','FN','ABSTAIN','ERROR'}:
            report += f"- {r['case_id']}: {r['status']} / {r['classification']} (원시 결과 runs[{after['runs'].index(r)}]).\n"
    report += '''
헤더 값·쿠키 파싱·API 관리자 SPA 오탐·CORS 정책은 이번 변경 대상이 아니므로 남아 있다. 401/403·로그인 리디렉션과 서버 오류는 보류한다. E-03의 민감 경로 timeout은 이제 WEB_SENSITIVE_PATHS WARNING/complete=false이며 정확도 분모에는 원래 정책대로 포함하지 않는다. E-01/E-02는 여전히 루트 도달 실패로 WEB_REACHABILITY WARNING이다. v1의 E-03 설명과 달리 원본 Handler는 /admin GET에도 지연을 적용하므로 API 1건 timeout도 발생하며 fixture를 바꾸지 않았다.

본문 형식은 휴리스틱이다. 환경 할당문이 예시 문서/공개 파일인 경우, 공개 ZIP, 의도된 phpinfo 같은 정책 차이는 오탐 가능성이 남는다. 4096바이트 이후의 증거·다른 파일 형식·인코딩/압축·동적 HTML·토큰이 매번 달라지는 SPA는 놓치거나 WARNING이 될 수 있다. 관리자 데이터의 의미를 확증하는 일반 파서는 도입하지 않았다. 동일 HTML의 catch-all은 이번 비인증 표본에 대한 판단이며 애플리케이션 전체의 안전성을 보장하지 않는다. HEAD와 GET은 순차 요청이므로 중간 상태 변경도 가능하다.

공통 `_request`의 GET 본문 읽기는 루트 HEAD 실패 후 GET fallback에도 적용된다. 따라서 헤더 전송 뒤 본문만 지연되는 서버는 이전과 달리 도달성 경고로 이어질 수 있다. 본문 읽기는 4096바이트로 제한하지만 기존 1초 값은 소켓 동작 timeout이며 전체 진단의 절대 deadline이 아니다. 매우 느리게 스트리밍하는 서버에 대한 전체 시간 상한을 이번 단계에서 새로 도입하지 않았다.

다음 개선은 기존 200 단위 테스트의 목적을 보존하면서 “근거 없는 성공은 WARNING, 실제 자원 형식은 FAIL”로 기대를 갱신하는 합의, 대조군·후보 요청의 중복 비용 최적화, 파일 형식별 긍정/부정 실제 HTTP 테스트 확장 순이다. 후보/타임아웃·fixture 계약을 바꾸는 최적화는 별도 비교 실험으로 진행해야 한다.

## 재현 및 근거

저장소 루트에서 `python tools/validation/verify.py --results docs/validation/improvement_01/results` 및 `python tools/validation/compare_improvement.py`를 실행한다. 전체 재측정은 `improvement.py run`이며 기존 개선 후 결과가 있으면 덮어쓰기를 거부한다. 새 실험에는 improvement.py의 출력 디렉터리 상수만 별도 위치로 지정하고 baseline.py는 유지한다. v1 preserve 역시 기존 아카이브 덮어쓰기를 거부한다. Python/OS/시각은 각 JSON에 기록했다. 소스 변경 후 이전 결과 verify의 해시 불일치는 정상적인 provenance 보호 동작이다.

모든 수치는 원래 [v1 JSON](../baseline_v1/docs/validation/results/baseline_results.json), [개선 후 JSON](results/baseline_results.json), [개선 후 CSV](results/baseline_summary.csv), [전체 실행 로그](results/execution.log), [pytest 로그](results/regression.log), [verify 로그](results/verification.log)에서 산출했다. 성능은 서로 다른 시점의 같은 로컬 환경 벽시계 측정으로 부하 변동·계측 overhead를 포함하며 인과적 정밀 벤치마크로 해석하지 않는다.
'''
    (AFTER.parent/'comparison.md').write_text(report, encoding='utf-8')
    (AFTER/'comparison.json').write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    log = 'PASS: v1 archive and original results unchanged; cases/fixture/harness/candidate paths/timeout preserved; 123 unique stable runs; CSV/JSON and source hashes consistent; API/Auth findings unchanged.\n'
    log += f"Regression exit code: {after['regression_exit_code']} (reported, not overridden). See regression.log and verification.log.\n"
    (AFTER/'comparison_verification.log').write_text(log, encoding='utf-8')
    print(log)
    print(json.dumps(data, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
