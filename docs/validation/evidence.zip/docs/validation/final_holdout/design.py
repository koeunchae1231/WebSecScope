"""New service scenarios authored after code freeze, before any holdout scan."""
from collections import Counter
from datetime import datetime, timezone
import base64
import hashlib
import io
import json
from pathlib import Path
import zipfile

OUT=Path(__file__).resolve().parent
assert (OUT/'freeze.json').exists()
CASES=[]
CSP='Content-Security-Policy';REF='Referrer-Policy';PERM='Permissions-Policy'
BASE={'Strict-Transport-Security':'max-age=63072000; includeSubDomains',CSP:"default-src 'none'; base-uri 'none'",
      'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY',REF:'strict-origin-when-cross-origin',
      PERM:'camera=(), microphone=(), geolocation=()','Content-Type':'text/html; charset=utf-8'}
HOME='<html><head><title>Atlas dispatch gateway</title></head><body><main>Regional delivery console</main></body></html>'


def response(body='',status=200,headers=None,**extra):
    return dict(status=status,body=body,headers=headers or {},**extra)


def header_selector(name):return ['WEB_HEADER_'+name.upper().replace('-','_')]


def header_rule(name,strength=None):
    rule=dict(path='/',required_headers=[name])
    if strength is not None:rule['strength']={name:strength}
    return rule


def add(group,name,truth,selector,reason,*,root=None,routes=None,resources=None,cookies=None,requirements=None,context=None,novelty=None):
    index=1+sum(c['area']==group for c in CASES)
    fixture=dict(root=response(HOME,headers=BASE| (root or {})),routes=routes or {})
    # Null overrides deliberately remove an otherwise present default field.
    case=dict(id=f'FH-{group}-{index:02d}',area=group,scenario=name,truth=truth,
              expected='WARNING' if truth=='unknown' else 'FAIL' if truth=='vulnerable' else 'PASS',
              rationale=reason,security_context=context or reason,
              indeterminate_reason=reason if truth=='unknown' else None,
              difference_from_prior=novelty or f'New Atlas service composition: {name}. Fixed probe names reflect the scanner contract; response structure and service requirement are newly authored.',
              selector=selector,fixture=fixture,policy_p1=dict(resources=resources or [],cookies=cookies or []),
              header_requirements=requirements or [],policy_needed=bool(resources or cookies or requirements),
              claim_scope='Recorded configuration or unauthenticated content/declared requirement; not browser exploitability')
    CASES.append(case)


# Header configuration: method-sensitive gateways and explicit configuration scope.
add('HDR','Stylesheet gateway omits MIME-sniffing defense','vulnerable',header_selector('X-Content-Type-Options'),
    'This upload-serving gateway requires an explicit nosniff response header; both methods omit it.',root={'X-Content-Type-Options':None,'Content-Type':'text/css'})
add('HDR','Retired frame allow-origin directive on payroll page','vulnerable',header_selector('X-Frame-Options'),
    'Payroll requires DENY or SAMEORIGIN; ALLOW-FROM is not an accepted deployment configuration.',root={'X-Frame-Options':'ALLOW-FROM https://portal.partner.invalid'})
add('HDR','HSTS duration has negative integer after gateway templating','vulnerable',header_selector('Strict-Transport-Security'),
    'The configured persistence duration must be positive; a negative max-age is not valid. This assesses syntax only over loopback HTTP.',root={'Strict-Transport-Security':'max-age=-3600; includeSubDomains'})
add('HDR','HEAD hardened but document GET disables persistence','vulnerable',header_selector('Strict-Transport-Security'),
    'A positive HEAD configuration cannot satisfy the requirement on the delivered GET document.',routes={'GET /':response(HOME,headers=BASE|{'Strict-Transport-Security':'max-age=0; includeSubDomains'})})
add('HDR','Asset proxy uses case-insensitive nosniff token','safe',header_selector('X-Content-Type-Options'),
    'HEAD and GET use different case spellings of the same nosniff token; both representations satisfy the MIME defense contract.',root={'X-Content-Type-Options':'NoSnIfF','Content-Type':'application/javascript'},routes={'GET /':response(HOME,headers=BASE|{'X-Content-Type-Options':'NOSNIFF','Content-Type':'application/javascript'})})
add('HDR','HSTS quoted persistence with unknown extension','safe',header_selector('Strict-Transport-Security'),
    'A positive quoted decimal duration and ignored extension satisfy the configuration requirement; TLS behavior is outside this test.',root={'Strict-Transport-Security':'max-age="86400"; includeSubDomains; atlas-rollout'})
add('HDR','Same-origin framing needed for embedded help panel','safe',header_selector('X-Frame-Options'),
    'The help panel permits its own origin to frame it; HEAD SAMEORIGIN and GET sameorigin are semantically equivalent configurations.',root={'X-Frame-Options':'SAMEORIGIN'},routes={'GET /':response(HOME,headers=BASE|{'X-Frame-Options':'sameorigin'})})
add('HDR','Whitespace normalization at nosniff boundary','safe',header_selector('X-Content-Type-Options'),
    'Method-specific HTTP field whitespace does not change the nosniff token; HEAD whitespace and GET canonical spelling satisfy the same contract.',root={'X-Content-Type-Options':'  nosniff  ','Cache-Control':'public, max-age=120'},routes={'GET /':response(HOME,headers=BASE|{'Cache-Control':'public, max-age=120'})})
add('HDR','Method-dependent framing without a deployment contract','unknown',header_selector('X-Frame-Options'),
    'HEAD uses DENY and GET uses SAMEORIGIN; each is meaningful but the intended consistency contract is unavailable.',routes={'GET /':response(HOME,headers=BASE|{'X-Frame-Options':'SAMEORIGIN'})})
add('HDR','Duplicate conflicting HSTS durations through two proxies','unknown',header_selector('Strict-Transport-Security'),
    'Conflicting duplicate max-age values require review; do not assume which gateway configuration is intended.',root={'Strict-Transport-Security':'max-age=300; max-age=0'})

# CSP: independent requirements describe restrictions, not successful XSS.
cs=header_selector(CSP);cstrong=[header_rule(CSP,'p2-restricted-script-object')]
add('CSP','Broad script execution combined with object wildcard','vulnerable',cs,
    'The document permits arbitrary script origins, inline handlers and eval despite a restrictive-script/object requirement.',root={CSP:"script-src * 'unsafe-inline' 'unsafe-eval'; object-src *"},requirements=cstrong)
add('CSP','Report-only rollout leaves required enforcing header absent','vulnerable',cs,
    'An enforcing header is explicitly required; a report-only policy cannot satisfy it.',root={CSP:None,CSP+'-Report-Only':"default-src 'none'"},requirements=cstrong)
add('CSP','Nonce-bound scripts but unrestricted embedded objects','vulnerable',cs,
    'The application requires restricted object loading too; object-src * violates that fact independently of nonce-bound scripts.',root={CSP:"script-src 'nonce-YXRsYXMtc2NyaXB0LWtleQ=='; object-src *; base-uri 'none'"},requirements=cstrong)
add('CSP','Split script element restriction leaves inline attributes open','vulnerable',cs,
    'The declared script restriction covers arbitrary inline event handlers; script-src-attr unsafe-inline violates it.',root={CSP:"default-src 'none'; script-src-elem 'self'; script-src-attr 'unsafe-inline'; object-src 'none'"},requirements=cstrong)
add('CSP','Two enforcing fields intersect broad and deny policies','safe',cs,
    'All enforcing policies apply; the deny policy removes broad capabilities allowed by the other policy.',root={CSP:["script-src * 'unsafe-inline' 'unsafe-eval'; object-src *","default-src 'none'; base-uri 'none'"]},requirements=cstrong)
add('CSP','Separate element and attribute restrictions with default denial','safe',cs,
    'Explicit element allowlist, attribute denial and default denial restrict scripts and objects.',root={CSP:"default-src 'none'; script-src-elem https://assets.atlas.invalid; script-src-attr 'none'; base-uri 'none'"},requirements=cstrong)
add('CSP','Hash-authorized script with ignored unsafe-inline fallback','safe',cs,
    'For the stated CSP3 model, a valid hash source prevents unsafe-inline from enabling arbitrary inline scripts; no eval or broad object source is allowed.',root={CSP:"script-src 'sha256-YXRsYXMtc3ludGhldGljLWhhc2g=' 'unsafe-inline'; object-src 'none'; base-uri 'none'"},requirements=cstrong)
add('CSP','Strict-dynamic nonce policy with closed object scope','safe',cs,
    'Nonce trust and strict-dynamic restrict script initiation in the CSP3 configuration model; nonce entropy/reuse is not the assessed claim.',root={CSP:"script-src 'nonce-QXRsYXNEaXNwYXRjaDIwMjY=' 'strict-dynamic' https:; object-src 'none'; base-uri 'self'"},requirements=cstrong)
add('CSP','Tenant wildcard origin requires missing ownership context','unknown',cs,
    'Whether every allowed tenant subdomain is trusted is unknown; wildcard syntax alone cannot establish the intended trust boundary.',root={CSP:"script-src https://*.tenants.atlas.invalid; object-src 'none'"})
add('CSP','Sandbox constraints interact with broad script fallback','unknown',cs,
    'The sandbox execution and embedding context is outside this HTTP-only evaluation, so no complete execution conclusion is assigned.',root={CSP:"sandbox allow-forms; script-src * 'unsafe-inline' 'unsafe-eval'; object-src *"})

# Referrer: URL privacy contract is stable across all three policy conditions.
rs=header_selector(REF);rstrong=[header_rule(REF,'no-cross-origin-full-url')]
add('REF','Invoice query URL sent under unsafe-url','vulnerable',rs,
    'The invoice service forbids transmitting full cross-origin URLs; unsafe-url violates that configuration requirement.',root={REF:'unsafe-url'},requirements=rstrong)
add('REF','Fallback list ends with downgrade-only restriction','vulnerable',rs,
    'The last recognized token sends full URLs to secure cross-origin destinations, contrary to the stated requirement.',root={REF:'no-referrer, no-referrer-when-downgrade'},requirements=rstrong)
add('REF','Later unsafe token overrides earlier strict field','vulnerable',rs,
    'Ordered repeated fields select the last recognized policy, which is unsafe-url.',root={REF:['strict-origin','unsafe-url']},requirements=rstrong)
add('REF','Missing response policy on mandated privacy endpoint','vulnerable',rs,
    'The deployment requires an explicit policy header; reliance on browser defaults does not meet that service requirement.',root={REF:None},requirements=rstrong)
add('REF','Last recognized fallback ignores future token','safe',rs,
    'Unknown fallback tokens are ignored; strict-origin remains the last recognized policy and never sends full cross-origin URLs.',root={REF:'unsafe-url, strict-origin, atlas-future'},requirements=rstrong)
add('REF','Same-origin detailed referrers with cross-origin origin only','safe',rs,
    'The privacy contract prohibits full cross-origin URLs, not origin-only disclosure.',root={REF:'origin-when-cross-origin'},requirements=rstrong)
add('REF','Strict cross-origin policy on redirect landing document','safe',rs,
    'The landing document explicitly restricts cross-origin referrers; this test assesses the returned header, not a browser navigation.',root={REF:'strict-origin-when-cross-origin','Vary':'Accept-Language'},requirements=rstrong)
add('REF','Same-origin referrers only for embedded billing widget','safe',rs,
    'same-origin suppresses cross-origin referrers and satisfies the declared URL privacy condition.',root={REF:'same-origin'},requirements=rstrong)
add('REF','Origin-only disclosure without an owner privacy contract','unknown',rs,
    'Origin disclosure may be intended or forbidden; no service privacy contract is available.',root={REF:'origin'})
add('REF','Strict but method-dependent privacy policies','unknown',rs,
    'Both method policies suppress cross-origin full URLs, but deployment consistency and the intended document policy are unspecified.',root={REF:'no-referrer'},routes={'GET /':response(HOME,headers=BASE|{REF:'strict-origin'})})

# Permissions: explicit service denials, not actual permission grants.
ps=header_selector(PERM)
def deny(*features):return [header_rule(PERM,dict(deny_features=list(features)))]
add('PERM','Camera self grant on camera-free invoice viewer','vulnerable',ps,
    'The declared requirement explicitly denies camera to every origin; self is a nonempty allowance.',root={PERM:'camera=(self), microphone=()'},requirements=deny('camera'))
add('PERM','Microphone delegated to conferencing partner on silent kiosk','vulnerable',ps,
    'The kiosk deployment mandates an empty microphone allowlist, so even a named trusted partner is forbidden.',root={PERM:'microphone=("https://meet.partner.invalid"), camera=()'},requirements=deny('microphone'))
add('PERM','Camera directive omitted from explicit denial contract','vulnerable',ps,
    'This service requires an explicit empty camera list; an omitted feature does not meet the deployment contract.',root={PERM:'microphone=(), geolocation=()'},requirements=deny('camera'))
add('PERM','Geolocation wildcard combined with camera denial','vulnerable',ps,
    'The requirement denies geolocation; an unrestricted allowlist violates it even though camera is denied.',root={PERM:'camera=(), geolocation=*'},requirements=deny('geolocation'))
add('PERM','Multi-feature deny list for offline manifest viewer','safe',ps,
    'All three mandated sensitive features have explicit empty allowlists.',root={PERM:'camera=(), microphone=(), geolocation=(), fullscreen=(self)'},requirements=deny('camera','microphone','geolocation'))
add('PERM','Microphone permitted while camera and location are forbidden','safe',ps,
    'The service contract permits microphone and requires only camera and geolocation denial.',root={PERM:'camera=(), geolocation=(), microphone=(self)'},requirements=deny('camera','geolocation'))
add('PERM','Separate header fields carry disjoint feature denials','safe',ps,
    'Disjoint structured dictionary members combine without conflicting keys; both declared denials are explicit.',root={PERM:['camera=()','microphone=(), geolocation=(self)']},requirements=deny('camera','microphone'))
add('PERM','Required camera denial alongside unrelated future feature','safe',ps,
    'The assessed contract concerns camera only, whose empty allowlist is explicit; no claim is made about the future feature.',root={PERM:'camera=(), atlas-sensor=()'},requirements=deny('camera'))
add('PERM','Duplicate camera declarations cross proxy trust boundary','unknown',ps,
    'The sender intent and deployed browser resolution of conflicting declarations are outside the bounded observation.',root={PERM:'camera=(), camera=(self), microphone=()'})
add('PERM','Unsupported wildcard origin expression in allowlist','unknown',ps,
    'The intended wildcard origin scope and browser acceptance cannot be established from this declaration.',root={PERM:'camera=("https://*.capture.atlas.invalid")'})

# Resource confidentiality: novel structures, public artifacts and diagnostic markup.
ss=['WEB_SENSITIVE_PATHS']
add('CONFIG','Dotenv multiline secret and service identity exposed','vulnerable',ss,
    'The real deployment environment file contains a synthetic live service credential and must not be anonymously retrievable.',routes={'/.env':response('export SERVICE_LOGIN=dispatch-worker\nSERVICE_SECRET="line-one\nline-two"\nREGION=ap-northeast\n',headers={'Content-Type':'text/plain'})})
add('CONFIG','Nested connection catalog in an environment JSON resource','vulnerable',ss,
    'The fixture is an actual private connection catalog, with a concrete credential under a nested connection object, not a documentation example.',routes={'/.env':response(json.dumps({'connectionCatalog':[{'engine':'postgres','identity':'dispatch-prod','accessKey':'synth-k8q24-x7v'}]}),headers={'Content-Type':'application/json'})})
add('CONFIG','BOM-prefixed detached repository object reference','vulnerable',ss,
    'The repository metadata file discloses a concrete detached object reference; the UTF-8 BOM is a transport representation detail.',routes={'/.git/HEAD':response('\ufeff'+'4b7a29d1'*8+'\n',headers={'Content-Type':'text/plain; charset=utf-8'})})
add('CONFIG','Diagnostic definition list contains database credential','vulnerable',ss,
    'A live PHP diagnostic resource reveals its synthetic database password in a definition list rather than a table.',routes={'/phpinfo.php':response('<html><title>PHP runtime configuration</title><dl><dt>DATABASE_PASSWORD</dt><dd>atlas-live-synth-47</dd></dl></html>',headers={'Content-Type':'text/html'})})
add('CONFIG','Public ZIP distribution happens to use backup filename','safe',ss,
    'The ZIP is an intentionally public release note archive, not a private backup. The filename and ZIP signature alone do not imply confidentiality.',routes={'/backup.zip':response('PUBLIC_ZIP_PLACEHOLDER',headers={'Content-Type':'application/zip','Cache-Control':'public'})},resources=[dict(path='/backup.zip',visibility='public')])
add('CONFIG','Environment tutorial rendered as escaped code','safe',ss,
    'The intentionally public tutorial contains example assignments inside HTML code, not an operational environment file.',routes={'/.env':response('<html><title>Environment tutorial</title><pre><code>export DB_PASSWORD=&lt;your-password&gt;</code></pre></html>',headers={'Content-Type':'text/html','Cache-Control':'public'})},resources=[dict(path='/.env',visibility='public')])
add('CONFIG','Git teaching page discusses a reference without exposing one','safe',ss,
    'A prose teaching page at the legacy URL discusses Git references; it is not a standalone repository HEAD file.',routes={'/.git/HEAD':response('<html><title>Version control lesson</title><p>A HEAD may use ref: refs/heads/topic to name a branch.</p></html>',headers={'Content-Type':'text/html'})},resources=[dict(path='/.git/HEAD',visibility='public')])
add('CONFIG','Retired resource routes return gone without content','safe',ss,
    'All five former resource locations return HTTP 410 with no private content; this claim is absence of disclosure, not proof of authentication.',routes={p:response('',410) for p in ('/.env','/.git/HEAD','/backup.zip','/admin','/phpinfo.php')})
add('CONFIG','Partial-range environment fragment lacks identity context','unknown',ss,
    'A 206 fragment containing an incomplete secret assignment cannot establish the full resource or whether it is an example.',routes={'/.env':response('SECRET_FRAGMENT="ab',206,{'Content-Type':'text/plain','Content-Range':'bytes 0-18/9000'})})
add('CONFIG','Unavailable environment route with gateway incident JSON','unknown',ss,
    'The upstream returns 503; resource identity and confidentiality cannot be established.',routes={'/.env':response('{"incident":"upstream-disconnected"}',503,{'Content-Type':'application/json'})})

# Documentation: public/private facts are authored independently of heuristic names.
ds=['API_DOCS_EXPOSED','API_ENDPOINT_EXPOSURE']
add('DOCS','Private OpenAPI callback inventory returned anonymously','vulnerable',ds,
    'The callback inventory is an internal document; a complete unauthenticated response violates its private designation.',routes={'/openapi.json':response(json.dumps({'openapi':'3.1.0','info':{'title':'Dispatch callback inventory','version':'7'},'paths':{},'webhooks':{'dispatchFinished':{'post':{'responses':{'204':{'description':'accepted'}}}}}}),headers={'Content-Type':'application/json'})},resources=[dict(path='/openapi.json',visibility='private')])
add('DOCS','Internal Swagger UI with private caching marker','vulnerable',ds,
    'The internal UI exposes an operation catalog and is explicitly private, despite being rendered as ordinary HTML.',routes={'/swagger':response('<html><title>Atlas operator API</title><div id="swagger-ui">internal dispatch reset operation</div></html>',headers={'Content-Type':'text/html','Cache-Control':'private'})},resources=[dict(path='/swagger',visibility='private')])
add('DOCS','Public API document accidentally carries a deployment credential','vulnerable',ds,
    'Public documentation may not contain the operational synthetic credential under deploymentCredentials; public visibility does not waive that fact.',routes={'/api-docs':response(json.dumps({'docs':{'title':'Public integration guide'},'deploymentCredentials':{'password':'atlas-runtime-pw-735'}}),headers={'Content-Type':'application/json'})},resources=[dict(path='/api-docs',visibility='public')])
add('DOCS','Public OpenAPI server extension embeds an operational token','vulnerable',ds,
    'The concrete operational token is outside any examples container and must not be published in a public server extension.',routes={'/openapi.json':response(json.dumps({'openapi':'3.1.0','info':{'title':'Fleet','version':'2'},'servers':[{'url':'https://dispatch.atlas.invalid','x-deployment':{'token':'synth-op-41b8'}}],'paths':{}}),headers={'Content-Type':'application/json'})},resources=[dict(path='/openapi.json',visibility='public')])
add('DOCS','Public OpenAPI example uses an explicit token placeholder','safe',ds,
    'A named example contains only a placeholder token; the public contract permits this documentation.',routes={'/openapi.json':response(json.dumps({'openapi':'3.1.0','info':{'title':'Public callback guide','version':'1'},'paths':{},'components':{'examples':{'access':{'value':{'token':'<token>'}}}}}),headers={'Content-Type':'application/json','Cache-Control':'public'})},resources=[dict(path='/openapi.json',visibility='public')])
add('DOCS','Public UI shells reference documentation bundles','safe',ds,
    'The static public API landing page lists only an asset bundle and public documentation title.',routes={'/swagger':response('<html><title>Public carrier API</title><main id="docs"></main><script src="/assets/docs-v7.js"></script></html>',headers={'Content-Type':'text/html','Cache-Control':'public'})},resources=[dict(path='/swagger',visibility='public')])
add('DOCS','Public machine-readable changelog at old docs route','safe',ds,
    'A complete public changelog contains no credentials or private record and is intended for anonymous access.',routes={'/api-docs':response(json.dumps({'releases':[{'version':'2026.11','changes':['new public webhook schema']}]}),headers={'Content-Type':'application/json','Cache-Control':'public,max-age=60'})},resources=[dict(path='/api-docs',visibility='public')])
add('DOCS','Private document authentication challenge returns no content','safe',ds,
    'The document route responds 401 without revealing its contents; the private resource requirement is satisfied for this request.',routes={'/swagger':response('',401,{'WWW-Authenticate':'Bearer realm="operators"'})},resources=[dict(path='/swagger',visibility='private')])
add('DOCS','OpenAPI response ends before the schemas object closes','unknown',ds,
    'The incomplete JSON document does not establish whether unpublished content contains sensitive details.',routes={'/openapi.json':response('{"openapi":"3.1.0","components":{"schemas":',headers={'Content-Type':'application/json'})},resources=[dict(path='/openapi.json',visibility='public')])
add('DOCS','Documentation upstream returns bad gateway','unknown',ds,
    'A 502 response does not establish the document visibility or compliance with its declared access rule.',routes={'/api-docs':response('documentation backend unavailable',502)},resources=[dict(path='/api-docs',visibility='private')])

# Cookies: scoped purpose and independent attributes, no actual browser storage claim.
ks=['WEB_COOKIE_FLAGS','AUTH_COOKIE_ATTRIBUTES']
def cookie_rule(name,purpose='session',javascript=False,path='/'):
    return dict(name=name,purpose=purpose,javascript_access_required=javascript,path=path)
add('COOKIE','Cross-site session omits Secure','vulnerable',ks,
    'SameSite=None on an authentication session requires Secure; HttpOnly alone is insufficient.',root={'Set-Cookie':'atlas_session=synth1; HttpOnly; SameSite=None; Path=/'},cookies=[cookie_rule('atlas_session')])
add('COOKIE','Session cookie lacks the JavaScript isolation flag','vulnerable',ks,
    'A session credential must be HttpOnly; this service has no JavaScript access exception.',root={'Set-Cookie':'dispatch_sid=synth2; Secure; SameSite=Lax; Path=/'},cookies=[cookie_rule('dispatch_sid')])
add('COOKIE','Template emits an invalid SameSite enumeration','vulnerable',ks,
    'SameSite=AtlasOnly is not a recognized configuration value.',root={'Set-Cookie':'dispatch_sid=synth3; Secure; HttpOnly; SameSite=AtlasOnly'},cookies=[cookie_rule('dispatch_sid')])
add('COOKIE','API login adds a weak cookie alongside a hardened web session','vulnerable',ks,
    'The independently issued API authentication cookie lacks SameSite and Secure, even though the web cookie is hardened.',root={'Set-Cookie':'web_sid=synth4; Secure; HttpOnly; SameSite=Strict'},routes={'/api/login':response('{"result":"login-form"}',headers={'Content-Type':'application/json','Set-Cookie':'api_sid=synth5; HttpOnly'})},cookies=[cookie_rule('web_sid'),cookie_rule('api_sid')])
add('COOKIE','Script-readable display preference is explicitly nonsensitive','safe',ks,
    'The declared display preference needs JavaScript access; Secure and SameSite remain present.',root={'Set-Cookie':'dispatch_density=compact; Secure; SameSite=Lax; Path=/'},cookies=[cookie_rule('dispatch_density','preference',True)])
add('COOKIE','Expiring strict session preserves Expires comma','safe',ks,
    'A single cookie has the required flags and a valid Expires date containing a comma; that comma is not a cookie separator.',root={'Set-Cookie':'operator_sid=synth6; Secure; HttpOnly; SameSite=Strict; Expires=Wed, 01 Dec 2027 12:00:00 GMT; Path=/'},cookies=[cookie_rule('operator_sid')])
add('COOKIE','Same-name sessions at two declared paths are both hardened','safe',ks,
    'Both independently scoped session cookies carry Secure, HttpOnly and recognized SameSite values.',root={'Set-Cookie':['atlas_sid=root-v; Secure; HttpOnly; SameSite=Lax; Path=/','atlas_sid=api-v; Secure; HttpOnly; SameSite=Strict; Path=/api']},cookies=[cookie_rule('atlas_sid'),cookie_rule('atlas_sid',path='/api')])
add('COOKIE','Case-insensitive flags on a cross-site session','safe',ks,
    'Case-insensitive flag names and a Secure SameSite=None credential satisfy the observed attribute contract.',root={'Set-Cookie':'carrier_sid=synth7; sEcUrE; hTtPoNlY; sAmEsItE=nOnE'},cookies=[cookie_rule('carrier_sid')])
add('COOKIE','Conflicting SameSite fields on an otherwise hardened cookie','unknown',ks,
    'Duplicate conflicting attributes require browser-resolution and deployment-intent review.',root={'Set-Cookie':'atlas_sid=synth8; Secure; HttpOnly; SameSite=Lax; SameSite=None'})
add('COOKIE','Malformed cookie field cannot be assigned a trustworthy purpose','unknown',ks,
    'The header lacks the cookie name/value separator, so neither purpose nor flags can be trusted.',root={'Set-Cookie':'atlas-cookie-without-value; Secure; HttpOnly; SameSite=Strict'})

# CORS: configuration validity and public/private response intent are distinct claims.
corss=['CORS_']
def cors_route(body,headers=None,**extra):return {'/api/users':response(body,headers={'Content-Type':'application/json'}|(headers or {}),**extra)}
add('CORS','Reflected arbitrary credentialed origins expose private dispatch data','vulnerable',corss,
    'The endpoint reflects arbitrary request origins with credential permission and returns explicitly private nested data.',routes=cors_route('{"dispatch":{"confidential":"synthetic shift roster"}}',{'Cache-Control':'private'},cors_mode='reflect',cors_credentials='true'))
add('CORS','Wildcard credentials on a public integration route','vulnerable',corss,
    'The deployment requires a valid credentialed CORS configuration; wildcard plus credentials is invalid even though browsers block credentialed reading.',routes=cors_route('{"integration":"public catalog"}',{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Credentials':'true','Cache-Control':'public'}))
add('CORS','Reflected credentialed private HTML fragment','vulnerable',corss,
    'Arbitrary reflected origins receive credential permission for a nonempty response explicitly marked private, independent of JSON field names.',routes=cors_route('<html><title>Private dispatch</title><p>operator roster</p></html>',{'Content-Type':'text/html','Cache-Control':'private,max-age=0'},cors_mode='reflect',cors_credentials='true'))
add('CORS','Anonymous wildcard reading of a private customer record','vulnerable',corss,
    'The fixture contains a real synthetic confidential record and allows anonymous cross-origin reading; lack of credential permission does not make that record public.',routes=cors_route('{"customer":{"confidential":"synthetic invoice address"}}',{'Access-Control-Allow-Origin':'*','Cache-Control':'private'}))
add('CORS','Public carrier catalog allows anonymous wildcard access','safe',corss,
    'The partial-range catalog is explicitly public and sends no credential permission; HTTP 206 does not make the public content private.',routes={'/api/users':response('{"carriers":["north","south"]}',206,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Cache-Control':'public,max-age=3600','Content-Range':'bytes 0-29/120'})})
add('CORS','Single trusted widget origin receives credentialed access','safe',corss,
    'The endpoint emits CORS headers only for the operator-owned widget origin; no-Origin and unrelated-origin requests receive no sharing permission.',routes=cors_route('{"private":"synthetic user preferences"}',{'Cache-Control':'private'},cors_mode='allowlist',allowed_origins=['https://widget.atlas.invalid'],cors_credentials='true'))
add('CORS','Origin reflection on a public noncredentialed badge resource','safe',corss,
    'The service intentionally shares a public badge with arbitrary origins and does not permit credentials.',routes=cors_route('{"badge":"public-delivery-status"}',{'Cache-Control':'public'},cors_mode='reflect'))
add('CORS','Protected API emits no CORS sharing permission','safe',corss,
    'An unauthenticated 401 response has no sharing permission and discloses no private content.',routes={'/api/users':response('',401,{'WWW-Authenticate':'Bearer'})})
add('CORS','Literal null allowance without a tested null request context','unknown',corss,
    'The response permits null but no explicit Origin:null browser request or intended embedding context is established.',routes=cors_route('{"message":"opaque embedding context"}',{'Access-Control-Allow-Origin':'null','Access-Control-Allow-Credentials':'true'}))
add('CORS','Second reflected-origin probe is incomplete','unknown',corss,
    'The second origin-specific response is delayed beyond the request deadline; complete cross-origin configuration evidence is missing.',routes=cors_route('{"confidential":"synthetic dispatch board"}',{'Cache-Control':'private'},cors_mode='reflect',cors_credentials='true',second_origin_delay=1.6))

# Authentication: rejection, private data, shell controls, redirects and unknown routes.
admins=['API_ADMIN_PATH_EXPOSED','API_ENDPOINT_EXPOSURE']
add('AUTH','Administrative JSON returns a nested deployment secret','vulnerable',admins,
    'A private administrative API returns an operational synthetic secret to an unauthenticated request.',routes={'/api/admin':response('{"configuration":{"secret":"synth-worker-secret-84"}}',headers={'Content-Type':'application/json'})},resources=[dict(path='/api/admin',visibility='private')])
add('AUTH','Administrative HTML private record differs from public shell','vulnerable',admins,
    'The returned private operational record is not the public shell and is available without authentication.',routes={'/admin':response('<html><title>Shift ledger</title><p>Operator 47 assigned to confidential dispatch</p></html>',headers={'Content-Type':'text/html','Cache-Control':'private'})},resources=[dict(path='/admin',visibility='private')])
add('AUTH','User API discloses private records without an auth challenge','vulnerable',['AUTH_MAY_BE_MISSING_API_USERS','AUTH_PROTECTED_API_USERS'],
    'This endpoint is contractually private; a successful unauthenticated response contains concrete synthetic personal records.',routes={'/api/users':response('{"accounts":[{"displayName":"Synthetic Operator","homeAddress":"synthetic road 7"}]}',headers={'Content-Type':'application/json'})},resources=[dict(path='/api/users',visibility='private')])
add('AUTH','Administrative business-data schema lacks heuristic secret labels','vulnerable',admins,
    'The owner designates the account ledger private; confidentiality does not depend on a field named secret or private.',routes={'/api/admin':response('{"accountLedger":[{"ledgerId":47,"balance":9031,"costCentre":"restricted"}]}',headers={'Content-Type':'application/json'})},resources=[dict(path='/api/admin',visibility='private')])
add('AUTH','Administrative candidates reject anonymous requests','safe',admins,
    'Both administrative routes reject unauthenticated requests without returning their protected content.',routes={'/admin':response('',403),'/api/admin':response('',401,{'WWW-Authenticate':'Bearer realm="dispatch"'})},resources=[dict(path='/api/admin',visibility='private'),dict(path='/admin',visibility='private')])
add('AUTH','User API returns explicit forbidden response','safe',['AUTH_PROTECTED_API_USERS','AUTH_MAY_BE_MISSING_API_USERS'],
    'The unauthenticated user request is rejected with no record content.',routes={'/api/users':response('',403)},resources=[dict(path='/api/users',visibility='private')])
add('AUTH','Public application shell matches both independent controls','safe',admins,
    'An edge-transformed 203 administrative representation matches public root and missing-route HTML controls; HEAD separately reports 404 and no private content is returned.',routes={'/admin':response(HOME,203,{'Content-Type':'text/html'}),'HEAD /admin':response('',404),'*':response(HOME,headers={'Content-Type':'text/html'})})
add('AUTH','Administrative login redirect exposes only public sign-in UI','safe',admins,
    'The private admin resource redirects to a public sign-in form and returns no administrative content in this fixture.',routes={'/api/admin':response('',302,{'Location':'/identity/sign-in'}),'/identity/sign-in':response('<html><title>Carrier sign in</title><form>account</form></html>',headers={'Content-Type':'text/html'})},resources=[dict(path='/api/admin',visibility='private')])
add('AUTH','Masked user route fails before authorization decision','unknown',['AUTH_MAY_BE_MISSING_API_USERS','AUTH_PROTECTED_API_USERS'],
    'An upstream 500 response does not establish whether authentication is enforced.',routes={'/api/users':response('{"error":"identity-provider unavailable"}',500,{'Content-Type':'application/json'})})
add('AUTH','Route negotiation rejects an unsupported user API representation','unknown',['AUTH_MAY_BE_MISSING_API_USERS','AUTH_PROTECTED_API_USERS'],
    'A 406 content-negotiation rejection does not establish the endpoint authentication rule.',routes={'/api/users':response('Accept header required',406,{'Vary':'Accept'})})

# Body and failure boundaries: encoding, truncation, MIME wrapping and transport errors.
add('BODY','UTF-16 credential JSON with a declared charset','vulnerable',ss,
    'A private environment response contains complete concrete database credentials; declared UTF-16 encoding does not make the disclosure safe.',routes={'/.env':response('',headers={'Content-Type':'application/json; charset=utf-16'},body_b64=base64.b64encode(json.dumps({'database':{'username':'atlas-job','password':'synth-db-57'}}).encode('utf-16')).decode())})
add('BODY','UTF-8 BOM precedes the only environment assignment','vulnerable',ss,
    'The environment file contains a real synthetic credential assignment after a BOM; it is not a public example.',routes={'/.env':response('\ufeffDISPATCH_API_KEY=synth-f9a21\n',headers={'Content-Type':'text/plain; charset=utf-8'})})
add('BODY','Multipart response wraps a private environment part','vulnerable',ss,
    'A successful response contains a private environment part with concrete credentials; MIME wrapping does not authorize disclosure.',routes={'/.env':response('--atlas\r\nContent-Type: text/plain\r\n\r\nWORKER_PASSWORD=synth-part-764\r\n--atlas--\r\n',headers={'Content-Type':'multipart/mixed; boundary=atlas'})})
add('BODY','Credential begins after the 16KiB collection boundary','vulnerable',ss,
    'The full served resource contains a private credential beyond the bounded sample. Ground truth uses the fixture, not the scanner sample.',routes={'/.env':response('# deployment commentary\n'*800+'API_PASSWORD=synth-tail-849\n',headers={'Content-Type':'text/plain'})})
add('BODY','Complete public configuration example uses only placeholders','safe',ss,
    'The explicitly public JSON example has placeholder credentials rather than operational values.',routes={'/.env':response('{"database":{"username":"example","password":"placeholder"}}',headers={'Content-Type':'application/json','Cache-Control':'public'})},resources=[dict(path='/.env',visibility='public')])
add('BODY','JSON string tutorial is mislabeled as text but contains no secret','safe',ss,
    'The public resource is a quoted teaching sentence, not repository metadata or a credential object; MIME mismatch alone is not disclosure.',routes={'/.git/HEAD':response('"Tutorial: detached HEAD identifiers are content hashes, not passwords."',headers={'Content-Type':'text/plain','Cache-Control':'public'})},resources=[dict(path='/.git/HEAD',visibility='public')])
add('BODY','Compressed public environment syntax reference','safe',ss,
    'The owner publishes an innocuous syntax guide; unsupported compression requires care but does not turn public text into a private disclosure.',routes={'/.env':response('GZIP_PUBLIC_GUIDE_PLACEHOLDER',headers={'Content-Type':'text/plain','Content-Encoding':'gzip','Cache-Control':'public'})},resources=[dict(path='/.env',visibility='public')])
add('BODY','HEAD unsupported but GET provides valid nosniff header','safe',header_selector('X-Content-Type-Options'),
    'The actual GET response has the required MIME defense; method-not-allowed on HEAD is a collection boundary, not missing GET protection.',routes={'HEAD /':response('',405,{'Allow':'GET'}),'GET /':response(HOME,headers=BASE)})
add('BODY','Connection closes before environment response headers','unknown',ss,
    'No response headers or body can be collected, so resource confidentiality cannot be assessed.',routes={'/.env':response('',disconnect=True)})
add('BODY','Document GET stalls after a successful HEAD policy observation','unknown',header_selector(CSP),
    'The actual document policy cannot be confirmed because GET exceeds the unchanged one-second deadline.',routes={'GET /':response(HOME,headers=BASE,delay=1.6)})


def main():
    import gzip
    assert len(CASES)==100
    assert Counter(c['truth'] for c in CASES)==dict(vulnerable=40,safe=40,unknown=20)
    assert all(v==10 for v in Counter(c['area'] for c in CASES).values())
    # Real ZIP and gzip payloads are generated deterministically; they contain no real secrets.
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,'w',compression=zipfile.ZIP_STORED) as z:
        entry=zipfile.ZipInfo('PUBLIC-RELEASE-NOTES.txt',date_time=(2026,1,1,0,0,0))
        z.writestr(entry,'Atlas public delivery integration release notes. No private backup content.')
    for c in CASES:
        for r in c['fixture']['routes'].values():
            if r['body']=='PUBLIC_ZIP_PLACEHOLDER':r.update(body='',body_b64=base64.b64encode(bio.getvalue()).decode())
            if r['body']=='GZIP_PUBLIC_GUIDE_PLACEHOLDER':r.update(body='',body_b64=base64.b64encode(gzip.compress(b'Environment variable names are public interface documentation.',mtime=0)).decode())
    path=OUT/'cases.json';assert not path.exists()
    path.write_text(json.dumps(CASES,indent=2,ensure_ascii=False),encoding='utf-8')
    print('Authored 100 new scenarios, 40 vulnerable / 40 safe / 20 indeterminate; no scanner run.')


if __name__=='__main__':main()
