"""Preregister first; run each trial in a fresh process with loopback-only sockets."""
from contextlib import ExitStack
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from unittest.mock import patch

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
sys.path.insert(0,str(OUT/'frozen_code'))


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):
    assert not p.exists(),p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')


def check_code():
    for rel,digest in read(OUT/'source_hashes.json').items():
        assert sha(ROOT/rel)==sha(OUT/'frozen_code'/rel)==digest,rel


def verify_inputs():
    for rel,digest in read(OUT/'preregistration.json')['input_hashes'].items():
        assert sha(OUT/rel)==digest,rel


def preregister():
    check_code()
    assert not (OUT/'04_raw_results').exists()
    from websecscope.policy import ScanPolicy
    cases=read(OUT/'cases.json')
    assert len(cases)==len({c['id'] for c in cases})==100
    for c in cases:
        for mode in ('p1','headers'):
            data=dict(policy_version=1,target_origin='$LOOPBACK_ORIGIN',**c['policy_p1'])
            if mode=='headers':data['header_requirements']=c['header_requirements']
            ScanPolicy(dict(data,target_origin='http://127.0.0.1:12345/'),'http://127.0.0.1:12345/')
            save(OUT/'policies'/f'{c["id"]}-{mode}.json',data)
    # A structural digest ignores metadata/labels; never collapse cases after results.
    signatures=[hashlib.sha256(json.dumps(dict(fixture=c['fixture'],policy=c['policy_p1'],requirements=c['header_requirements']),sort_keys=True).encode()).hexdigest() for c in cases]
    assert len(set(signatures))==100
    files=[OUT/name for name in ('cases.json','design.py','fixture.py','run.py','analyze.py','sources.json')]
    files+=sorted((OUT/'policies').glob('*.json'))
    save(OUT/'preregistration.json',dict(registered_at=datetime.now(timezone.utc).isoformat(),
        designation='코드 동결 후 생성한 신규 합성 홀드아웃 평가',
        externally_independent=False,capability_aware_design=True,code_tuning_after_results=False,
        cases=100,evaluable=80,vulnerable=40,safe=40,indeterminate=20,
        modes=['none','p1','headers'],repeats=[1,2,3],expected_trials=900,
        options=dict(include_api_auth=True,include_linux=False,include_docker=False,include_service_detect=False,include_cve=False),
        python=sys.version,dependencies=read(OUT/'freeze.json')['dependencies'],
        timeouts='Frozen web/api 1 second, body cap 16KiB; no production override',
        order='mode, case declaration order, repeat 1..3; fresh interpreter and server for every trial',
        selectors='Prefix matching against check_id, frozen per case. Any FAIL -> FAIL; else any WARNING -> WARNING; else all PASS -> PASS; no matching Finding -> ERROR. No post-result selector changes.',
        mapping='Known vulnerable: FAIL=TP, PASS=FN, WARNING=ABSTAIN; known safe: FAIL=FP, PASS=TN, WARNING=ABSTAIN. Unknown: excluded from confusion matrix; WARNING adequacy reported separately.',
        errors='Worker/scanner exception, missing selected finding, invalid policy or nonzero worker exit -> ERROR. Timeout observation without scan exception is a request timeout, not automatically ERROR.',
        metrics='First repeat per case is primary; repeats assess stability, not independent n. Conditional precision/recall/F1/accuracy exclude abstentions/errors; coverage=decisions/80; conservative accuracy=(TP+TN)/80; vulnerable detection=TP/40; safe correctness=TN/40; zero denominators=null/N/A.',
        rss='Fresh worker process: current RSS before/after scan and PeakWorkingSetSize via Windows GetProcessMemoryInfo. Includes imports, fixture server and instrumentation; not scanner-only RSS. Unavailable -> null.',
        origin_binding='Only replace target_origin placeholder with allocated loopback origin; exact bound policy retained in every raw result.',
        input_hashes={str(p.relative_to(OUT)):sha(p) for p in files},
        structural_case_signatures=signatures))
    print('Preregistered immutable 100 cases, 200 policy templates, runner, fixture, analysis, 3 modes x 3 repeats.')


def rss():
    if os.name!='nt':return None
    import ctypes
    from ctypes import wintypes
    class Counters(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(name,ctypes.c_size_t) for name in (
            'PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage',
            'QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    psapi=ctypes.WinDLL('psapi',use_last_error=True)
    kernel.GetCurrentProcess.restype=wintypes.HANDLE
    psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
    counters=Counters();counters.cb=ctypes.sizeof(counters)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(counters),counters.cb):return None
    return dict(current_bytes=counters.WorkingSetSize,peak_bytes=counters.PeakWorkingSetSize)


def worker(case_id,mode,repeat):
    verify_inputs()
    from fixture import start,stop
    from websecscope.policy import ScanPolicy
    from websecscope.scanner import orchestrator,web,api_scanner,auth_scanner
    from websecscope.scoring import calculate_score_details
    case=next(c for c in read(OUT/'cases.json') if c['id']==case_id)
    server,thread=start(case['fixture'])
    target=f'http://127.0.0.1:{server.server_port}/'
    policy_data=None;policy=None
    if mode!='none':
        policy_data=read(OUT/'policies'/f'{case_id}-{mode}.json')
        policy_data['target_origin']=target
        policy=ScanPolicy(policy_data,target)
    traces=[];denied=[]
    connect=socket.socket.connect
    def guarded(sock,address):
        if address[0] not in ('127.0.0.1','::1','localhost'):
            denied.append(str(address));raise OSError('Non-loopback connection forbidden')
        return connect(sock,address)
    def traced(fn,default_method):
        def call(url,*args,**kwargs):
            began=time.perf_counter();obs=fn(url,*args,**kwargs)
            headers=obs.get('headers',{})
            traces.append(dict(url=url,method=kwargs.get('method',args[0] if args else default_method),
                seconds=time.perf_counter()-began,status=obs.get('status_code',obs.get('status')),
                error=obs.get('error'),headers_list=list(headers.items()) if hasattr(headers,'items') else [],
                body_evidence=obs.get('body_evidence'),body_truncated=obs.get('body_truncated')))
            return obs
        return call
    error=None;scan=None;rss_before=rss();began=time.perf_counter()
    try:
        with ExitStack() as stack:
            stack.enter_context(patch.object(socket.socket,'connect',guarded))
            for module,name,method in ((web,'_request','HEAD'),(api_scanner,'request_observation','GET'),(auth_scanner,'request_observation','GET')):
                stack.enter_context(patch.object(module,name,traced(getattr(module,name),method)))
            scan=orchestrator.run_scan(target,include_linux=False,include_docker=False,include_service_detect=False,include_cve=False,
                                       **({'policy':policy} if policy is not None else {}))
    except Exception as exc:error=f'{type(exc).__name__}: {exc}'
    seconds=time.perf_counter()-began;rss_after=rss()
    stop(server,thread)
    findings=scan.findings if scan else []
    chosen=[f for f in findings if any(f.check_id.startswith(prefix) for prefix in case['selector'])]
    if error or not chosen:status='ERROR'
    else:status='FAIL' if any(f.status=='FAIL' for f in chosen) else 'WARNING' if any(f.status=='WARNING' for f in chosen) else 'PASS'
    if scan:assert calculate_score_details(findings)==scan.score_details
    assert not denied,denied
    value=dict(case_id=case_id,mode=mode,repeat=int(repeat),truth=case['truth'],expected=case['expected'],
        status=status,error=error,error_kind='scanner_exception' if error else 'missing_selected_finding' if not chosen else None,
        seconds=seconds,rss_before=rss_before,rss_after=rss_after,policy=policy_data,
        policy_sha256=policy.digest if policy else None,target=target,selected=[f.to_dict('en') for f in chosen],
        scan=scan.to_dict('en') if scan else None,requests=traces,http_events=server.events,
        logical_requests=len(traces),http_requests=len(server.events),
        request_timeouts=sum('timeout' in (q['error'] or '').lower() for q in traces),
        incomplete_bodies=sum(bool(q.get('body_evidence')) and not q['body_evidence'].get('complete',False)
                              and q['method']!='HEAD' for q in traces),
        denied_connections=denied,pid=os.getpid(),python=sys.version)
    save(OUT/'04_raw_results'/mode/f'{case_id}-{repeat}.json',value)


def run():
    check_code();verify_inputs()
    registration=read(OUT/'preregistration.json')
    cases=read(OUT/'cases.json')
    (OUT/'04_raw_results').mkdir(exist_ok=False)
    failures=[]
    for mode in registration['modes']:
        for case in cases:
            for repeat in registration['repeats']:
                result=subprocess.run([sys.executable,str(OUT/'run.py'),'worker',case['id'],mode,str(repeat)],
                    cwd=ROOT,capture_output=True,text=True,timeout=90)
                if result.returncode:
                    failures.append(dict(case_id=case['id'],mode=mode,repeat=repeat,exit_code=result.returncode))
                    destination=OUT/'04_raw_results'/mode/f'{case["id"]}-{repeat}.json'
                    if not destination.exists():save(destination,dict(case_id=case['id'],mode=mode,repeat=repeat,
                        truth=case['truth'],expected=case['expected'],status='ERROR',error_kind='worker_failure',
                        error=result.stderr,selected=[],requests=[],http_events=[],seconds=None,rss_before=None,rss_after=None,
                        logical_requests=0,http_requests=0,request_timeouts=0))
                    (OUT/'04_raw_results'/f'{case["id"]}-{mode}-{repeat}-failure.log').write_text(result.stdout+result.stderr,encoding='utf-8')
                row=read(OUT/'04_raw_results'/mode/f'{case["id"]}-{repeat}.json')
                print(mode,case['id'],repeat,row['status'],row.get('seconds'),flush=True)
    check_code();verify_inputs()
    save(OUT/'execution_complete.json',dict(completed_at=datetime.now(timezone.utc).isoformat(),trials=900,worker_failures=failures))


if __name__=='__main__':
    action=sys.argv[1]
    if action=='worker':worker(*sys.argv[2:])
    else:{'preregister':preregister,'run':run}[action]()
