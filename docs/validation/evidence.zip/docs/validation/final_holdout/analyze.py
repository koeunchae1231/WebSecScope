"""Frozen mapping, metrics, complete anomaly inventory and final evidence reports."""
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=OUT/name;assert not p.exists(),p
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')
def write(name,value):
    p=OUT/name;assert not p.exists(),p
    p.write_text(value,encoding='utf-8')
def ratio(n,d):return n/d if d else None
def fmt(v):return 'N/A' if v is None else f'{v:.4f}' if isinstance(v,float) else str(v)


def classification(r):
    if r['status']=='ERROR':return 'ERROR'
    if r['truth']=='unknown':return 'EXCLUDED'
    if r['status']=='WARNING':return 'ABSTAIN'
    if r['truth']=='vulnerable':return 'TP' if r['status']=='FAIL' else 'FN'
    return 'FP' if r['status']=='FAIL' else 'TN'


def metrics(rows):
    known=[r for r in rows if r['truth']!='unknown']
    unknown=[r for r in rows if r['truth']=='unknown']
    counts=Counter(classification(r) for r in known)
    tp,fp,fn,tn=(counts[k] for k in ('TP','FP','FN','TN'))
    decided=tp+fp+fn+tn
    v=[r for r in known if r['truth']=='vulnerable'];s=[r for r in known if r['truth']=='safe']
    return dict(n=len(known),total_cases=len(rows),vulnerable=len(v),safe=len(s),unknown=len(unknown),
        TP=tp,FP=fp,FN=fn,TN=tn,ABSTAIN=counts['ABSTAIN'],ERROR=counts['ERROR'],
        precision=ratio(tp,tp+fp),recall=ratio(tp,tp+fn),accuracy=ratio(tp+tn,decided),
        f1=ratio(2*tp,2*tp+fp+fn),coverage=ratio(decided,len(known)),
        conservative_accuracy=ratio(tp+tn,len(known)),vulnerable_detection=ratio(tp,len(v)),safe_correctness=ratio(tn,len(s)),
        vulnerable_abstain=sum(r['status']=='WARNING' for r in v),safe_abstain=sum(r['status']=='WARNING' for r in s),
        unknown_statuses=dict(Counter(r['status'] for r in unknown)),
        appropriate_unknown_warning_rate=ratio(sum(r['status']=='WARNING' for r in unknown),len(unknown)),
        all_warning=sum(r['status']=='WARNING' for r in rows),all_error=sum(r['status']=='ERROR' for r in rows),
        execution_failure_rate=ratio(sum(r['status']=='ERROR' for r in rows),len(rows)))


def stats(values):
    values=sorted(v for v in values if v is not None)
    if not values:return dict(n=0,mean=None,p50=None,p95=None,max=None)
    return dict(n=len(values),mean=statistics.mean(values),p50=statistics.median(values),
                p95=values[math.ceil(.95*len(values))-1],max=values[-1])


def design_docs():
    cases=read(OUT/'cases.json');freeze=read(OUT/'freeze.json');reg=read(OUT/'preregistration.json')
    write('01_freeze_manifest.md',f'''# 코드 동결

- 명칭: **코드 동결 후 생성한 신규 합성 홀드아웃 평가**. 외부 독립 평가가 아니다.
- 동결 시각 UTC: {freeze['frozen_at']} (신규 cases 생성 전).
- 브랜치: `{freeze['branch']}`. commit: `{freeze['commit']}`.
- 미커밋 변경 포함 실제 소스: frozen_code/, source_hashes.json. commit만으로 평가 코드를 재현할 수 없다.
- Python: {freeze['python']}. 실행 파일: `{freeze['executable']}`.
- OS: {freeze['platform']}. 의존성: freeze.json의 dependencies.
- 정책 schema 1, 점수 정책 `{freeze['score_policy']}`.
- pytest: pytest_frozen.log, 407개 통과. 기존 변경·tests·규칙·점수·CVE 코드는 수정하지 않는다.
- 기존 작업 트리 상태는 freeze.json의 dirty_status에 원문 보존. 과거 검증 자료는 historical_hashes.json으로 보존.

재현: 같은 Python/의존성을 준비하고 동결 소스를 root에 복원한 별도 복사본에서 실행한다. run.py는 frozen_code를 우선 import하며 실제 root와 frozen 사본 해시도 검사한다. 실행 옵션·시간 제한·선택자는 preregistration.json에 고정했다.
''')
    write('02_evaluation_design.md','''# 평가 설계

10개 영역 각각 10개, 총 100개: 취약·서비스 요구 위반 40, 정상·요구 충족 40, 맥락 부족 20. 정답 확정 분모는 80이다. HEADER/HSTS, CSP, Referrer, Permissions, 민감 경로, 문서, 쿠키, CORS, 인증, 본문·오류 경계를 포함한다. 반복을 독립 사례로 세지 않는다.

새 fixture.py는 기존 baseline/independent_fixture의 Handler·Service·selector를 import하거나 복제하지 않았다. 선언적 method/path 응답, 반복 헤더, origin-dependent 응답, 인코딩, 지연·연결 중단을 직접 구현했다. 기존 38·72 사례를 실행 입력으로 읽지 않는다. 한계: 동일 작성자가 제품의 지원 영역을 검토한 뒤 사례와 정답을 작성했으므로 capability-aware 내부 합성 평가이며 블라인드·외부 독립성은 없다. 기존 평가와 동일한 보안 원리·고정 probe 경로가 일부 겹치는 것은 피할 수 없고, 사례별 새 구성은 cases.json의 difference_from_prior에 명시했다. 표본 수 자체로 독립성을 주장하지 않는다.

정답은 실제 fixture가 반환하는 전체 콘텐츠와 사전 작성한 서비스 계약으로 정한다. 예: public ZIP은 형식만으로 비밀이 아니며, private JSON은 field 이름에 secret이 없더라도 공개해서는 안 된다. 16KiB 밖의 실제 비밀도 전체 fixture 기준 취약이다. HTTP 위의 HSTS·Secure는 문법/관측 attribute 평가이며 실제 TLS·브라우저 강제를 증명하지 않는다. CSP3·Permissions의 제한된 모델과 브라우저 상호작용/알려지지 않은 feature는 구분한다.

세 조건은 동일 사례에 대해 none, p1(resources/cookies), headers(P1+service header requirements)다. 정책을 숨겨도 정답은 바뀌지 않는다. 알려진 정답에서 WARNING은 ABSTAIN으로 따로 측정하며 FP/FN으로 강제하지 않는다. 정책이 필요한 경우와 필요 없는 경우를 별도 집계한다. 정책 JSON에는 사례 ID·정답 레이블·우회 조건이 없고, 사례에 맞는 실제 운영 선언만 들어간다. 런타임 target_origin만 할당된 loopback origin으로 치환한다.

각 조건 3회 반복, 총 900회. fresh Python process와 HTTP server를 실행마다 만든다. 원래 1초 timeout과 16KiB cap 및 후보 요청 계획을 유지하고 외부 socket connect를 거부한다. Linux/Docker/service/CVE 조회는 끄고 API/Auth는 켠다. 실행순서는 조건→사례 선언순→반복 1..3. 메모리는 Windows GetProcessMemoryInfo의 current/peak working set을 기록하며 scanner만이 아니라 import·fixture·instrumentation도 포함한다.

최초 반복 100개를 주 지표로 사용한다. 알려진 80개에서 선택 Finding 중 FAIL 우선, 이어 WARNING, 모두 PASS면 PASS; 선택 Finding이 없거나 worker/scan 예외는 ERROR. missing finding을 PASS로 가정하지 않는다. 전체 규칙은 preregistration.json 참조. 20 unknown은 confusion matrix에서 제외하고 WARNING 비율 및 과도한 PASS/FAIL을 별도 보고한다. 분모 0은 N/A다.

조건부 Precision=TP/(TP+FP), Recall=TP/(TP+FN), F1=2TP/(2TP+FP+FN), Accuracy=(TP+TN)/(TP+FP+FN+TN). Coverage=판정수/80, 보수적 Accuracy=(TP+TN)/80, 전체 취약 탐지율=TP/40, 전체 정상 올바른 비율=TN/40. Timeout은 요청 관측과 영향 실행 수를 모두 구분하고 ERROR와 중복 여부를 숨기지 않는다.
''')
    lines=['# Ground Truth 확정 기록\n',f"등록 시각 UTC: {reg['registered_at']}. 코드 동결 후, 평가 전 정답·fixture·정책·실행/분석 도구 해시 확정.\n",
           '등록 후 결과에 맞춘 정답·정책·selector 수정은 금지한다. 오류 발견 시 원본을 보존하고 별도 correction과 전후 지표를 작성한다. 현재 정정 없음.\n',
           'cases.json이 전체 fixture와 Ground Truth 원본이다. 정책 template 200개는 policies/에 있으며 placeholder origin 외에는 실행 시 변경하지 않는다. 전체 해시는 preregistration.json의 input_hashes.\n',
           '| 자료 | SHA-256 |','|---|---|']
    for rel,h in reg['input_hashes'].items():lines.append(f'| {rel} | `{h}` |')
    lines+=['\n## 사례별 정답 근거\n','| ID | 영역 | 정답 | 시나리오·근거 |','|---|---|---|---|']
    for c in cases:lines.append(f"| {c['id']} | {c['area']} | {c['truth']} | {c['scenario']}: {c['rationale']} |")
    lines+=['\n## 해석 근거\n']
    for name,url in read(OUT/'sources.json').items():
        lines.append(f'- [{name}]({url})' if url.startswith('http') else '- '+url)
    write('03_ground_truth_manifest.md','\n'.join(lines))


def cause(case,row):
    status=row['status'];truth=case['truth'];mode=row['mode']
    evidence='; '.join(f['check_id']+': '+f['evidence'] for f in row.get('selected',[]))
    if status=='ERROR':return 'No selected Finding or scan/worker failure; this is retained as ERROR, not interpreted as protection. '+str(row.get('error_kind'))
    if truth=='unknown':return 'Indeterminate truth: '+case['indeterminate_reason']+(' Returned WARNING is appropriate.' if status=='WARNING' else ' The selected bounded Finding is more conclusive than the whole scenario warrants; its claim scope must be reviewed.')
    if classification(row)=='FP':
        if case['area']=='COOKIE':return 'Generic cookie hardening cannot infer the declared JavaScript preference exception without matching P1 context.'
        if case['area']=='DOCS':return 'Reachable documentation is treated as exposure without the public-content contract, or a content heuristic overrides it.'
        if case['area']=='CONFIG':return 'Resource-format signature is treated as exposure despite intentionally public artifact/content; explicit public policy may not waive a signature.'
        return 'The selected rule flags an observed configuration that the predeclared bounded service contract permits. See exact evidence and fixture.'
    if classification(row)=='FN':return 'The selected rule returned PASS although the fixture violates the service contract; the rule/heuristic did not represent this confidentiality or configuration condition.'
    if row.get('request_timeouts'):return 'Request deadline prevented complete evidence; retained as ABSTAIN, not a negative finding.'
    if case['area']=='BODY':return 'Bounded format/encoding/parse/truncation handling cannot establish the full resource facts from its sample; inspect body_evidence and the predeclared full-body truth.'
    if case['area']=='AUTH':return 'Status/redirect/record labels or public-shell controls do not establish the private access contract conclusively in this Finding.'
    if case['area']=='CONFIG':return 'Specific resource signatures or HTTP status handling leave the novel representation/public artifact uncertain.'
    if case['area']=='DOCS':return 'Document visibility or sensitive-content conflict is unresolved, or incomplete/error response prevents the declared resource conclusion.'
    if case['area']=='CORS':return 'Credential permission, origin probes or public/private response facts are insufficient for the implemented CORS confirmation rule.'
    if case['area']=='COOKIE':return 'Cookie syntax/scope/attribute conflict prevents a trustworthy purpose or security-attribute conclusion.'
    return 'Bounded header semantics, method mismatch or absent explicit service requirement prevents a conclusive classification; see the preserved selected evidence.'


def analyze():
    import run
    run.check_code();run.verify_inputs()
    assert read(OUT/'execution_complete.json')['trials']==900
    cases=read(OUT/'cases.json');byid={c['id']:c for c in cases}
    rows=[read(p) for p in sorted((OUT/'04_raw_results').glob('*/*.json'))]
    assert len(rows)==900 and len({(r['case_id'],r['mode'],r['repeat']) for r in rows})==900
    summaries={};anomalies=[];transitions=[];allpaths=Counter()
    for mode in ('none','p1','headers'):
        group=[r for r in rows if r['mode']==mode];first=[r for r in group if r['repeat']==1]
        assert len(first)==100
        consistency=ratio(sum(len({r['status'] for r in group if r['case_id']==c['id']})==1 for c in cases),len(cases))
        methods=Counter(q['method'] for r in group for q in r['http_events'])
        paths=Counter((q['method'],q['path']) for r in group for q in r['http_events'])
        allpaths.update(paths)
        summaries[mode]=dict(metrics=metrics(first),by_area={area:metrics([r for r in first if byid[r['case_id']]['area']==area]) for area in sorted({c['area'] for c in cases})},
            policy_context={str(needed):metrics([r for r in first if byid[r['case_id']]['policy_needed']==needed]) for needed in (True,False)},
            repetition_consistency=consistency,repeat_metrics={str(i):metrics([r for r in group if r['repeat']==i]) for i in (1,2,3)},
            seconds=stats([r['seconds'] for r in group]),http_requests=sum(r['http_requests'] for r in group),logical_requests=sum(r['logical_requests'] for r in group),
            http_requests_per_trial=stats([r['http_requests'] for r in group]),methods=dict(methods),request_timeout_observations=sum(r['request_timeouts'] for r in group),
            trials_with_request_timeout=sum(bool(r['request_timeouts']) for r in group),
            scan_exceptions=sum(r.get('error_kind') in ('scanner_exception','worker_failure') for r in group),
            all_error_trials=sum(r['status']=='ERROR' for r in group),
            rss_current_before=stats([r['rss_before']['current_bytes'] for r in group if r.get('rss_before')]),
            rss_current_after=stats([r['rss_after']['current_bytes'] for r in group if r.get('rss_after')]),
            rss_peak=stats([r['rss_after']['peak_bytes'] for r in group if r.get('rss_after')]))
        for row in first:
            label=classification(row)
            if label in ('FP','FN','ABSTAIN','ERROR') or row['truth']=='unknown':
                c=byid[row['case_id']]
                anomalies.append(dict(case_id=c['id'],mode=mode,truth=c['truth'],classification=label,status=row['status'],
                    scenario=c['scenario'],rationale=c['rationale'],security_context=c['security_context'],policy=row.get('policy'),
                    evidence=row.get('selected'),cause=cause(c,row),novelty=c['difference_from_prior'],
                    repeat_statuses=[r['status'] for r in group if r['case_id']==c['id']],
                    improvement='Follow-up only: clarify scope or add general evidence handling after this frozen evaluation; do not tune to the case ID.'))
    for c in cases:
        selected={r['mode']:r for r in rows if r['case_id']==c['id'] and r['repeat']==1}
        if len({r['status'] for r in selected.values()})>1:
            transitions.append(dict(case_id=c['id'],truth=c['truth'],policy_needed=c['policy_needed'],statuses={m:r['status'] for m,r in selected.items()}))
    old=read(ROOT/'docs/validation/post_independent/final_refactoring/equivalence.json')['summaries']['after']
    comparison={}
    for mode,previous in [('none','without_policy'),('p1','with_policy'),('headers','with_headers')]:
        comparison[mode]=dict(fixed38=old[previous+'_fixed38'],development72=old[previous+'_development72'],holdout=summaries[mode]['metrics'])
    save('metrics.json',summaries);save('anomalies.json',anomalies);save('policy_transitions.json',transitions);save('comparison.json',comparison)
    save('request_patterns.json',[dict(method=m,path=p,count=n) for (m,p),n in sorted(allpaths.items())])
    lines=['# 최종 합성 홀드아웃 지표\n','각 조건 100개 중 정답 확정 80개(취약40/정상40), 불확정20. 아래 주 지표는 반복1, 실행 비용은 조건당300회 기준이다. 반복은 독립 사례가 아니다.\n',
           '| 조건 | TP | FP | FN | TN | AB(80) | ERROR(80) | Precision | Recall | F1 | Accuracy | Coverage | 보수적 Accuracy | TP/40 | TN/40 |',
           '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for mode,s in summaries.items():
        m=s['metrics'];keys=('TP','FP','FN','TN','ABSTAIN','ERROR','precision','recall','f1','accuracy','coverage','conservative_accuracy','vulnerable_detection','safe_correctness')
        lines.append('| '+mode+' | '+' | '.join(fmt(m[k]) for k in keys)+' |')
    lines+=['\n조건부 지표는 ABSTAIN/ERROR를 제외하며, 보수적 지표는 이들을 분모에 남긴다. 분모 0은 N/A. 불확정20은 confusion matrix에서 제외한다.\n',
            '| 조건 | unknown WARNING/20 | unknown PASS | unknown FAIL | unknown ERROR | 반복 일치율 | 전체 ERROR 실행/300 | Timeout 관측/영향 실행 |',
            '|---|---:|---:|---:|---:|---:|---:|---|']
    for mode,s in summaries.items():
        u=s['metrics']['unknown_statuses'];lines.append(f"| {mode} | {u.get('WARNING',0)}/20 | {u.get('PASS',0)} | {u.get('FAIL',0)} | {u.get('ERROR',0)} | {fmt(s['repetition_consistency'])} | {s['all_error_trials']}/300 | {s['request_timeout_observations']}/{s['trials_with_request_timeout']} |")
    lines+=['\n## 실행 비용\n','| 조건 | 평균 초 | P50 초 | P95 초 | 최대 초 | HTTP 요청/300 | Logical 요청/300 | RSS peak 평균 MiB | RSS peak P95 MiB |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for mode,s in summaries.items():
        t=s['seconds'];memory=s['rss_peak']
        lines.append(f"| {mode} | {fmt(t['mean'])} | {fmt(t['p50'])} | {fmt(t['p95'])} | {fmt(t['max'])} | {s['http_requests']} | {s['logical_requests']} | {fmt(memory['mean']/1048576 if memory['mean'] else None)} | {fmt(memory['p95']/1048576 if memory['p95'] else None)} |")
    lines+=['\nRSS는 각 실행 fresh Windows worker 프로세스의 working set이며 import, fixture, instrumentation을 포함한다. baseline/current-after/peak 원시값은 모든 실행 JSON에 있다. 실행 시간은 run_scan과 instrumentation을 포함하며 프로세스 시작·import·server 준비/종료는 제외한다. nearest-rank P95, P50은 median. HTTP 요청은 실제 server event 수이며 logical은 collector 호출 수다. 경로·메서드·origin·상태는 원본 이벤트와 request_patterns.json에 보존한다.\n',
            '영역별·정책 맥락 필요 여부별 지표와 각 반복 지표는 metrics.json에 있다. 오류를 이유로 제외한 알려진 사례는 없다.\n']
    write('05_metrics.md','\n'.join(lines))
    lines=['# FP·FN·ABSTAIN·ERROR 전수 분석\n',f'최초 반복에서 조건별 분석 행 {len(anomalies)}개. 알려진 정답의 모든 FP/FN/ABSTAIN/ERROR 및 불확정20 전체를 보존한다. 반복 상태는 anomalies.json에서 확인한다. 코드·정답·정책은 수정하지 않았다.\n',
           '| ID | 조건 | 정답 | 실제/분류 | 원인 및 한계 |','|---|---|---|---|---|']
    for a in anomalies:lines.append(f"| {a['case_id']} | {a['mode']} | {a['truth']} | {a['status']}/{a['classification']} | {a['cause']} |")
    lines+=['\n각 행의 원시 선택 Finding 전체(evidence·metadata), 적용 정책, 사전 근거, 맥락, 기존 사례와의 차이 및 개선 가능 여부는 anomalies.json에 들어 있다. case ID를 이용한 우회 개선은 금지하며 다음 작업에서 일반 조건별 regression으로 다룬다.\n',
            '후속 작업: 공개 아카이브와 실제 비밀 구분; 문서/인증의 PASS 주장 범위; 알려지지 않은 HTTP 상태의 명시적 미평가 표현; BOM·중첩 JSON·새 진단 markup; header requirement 위반과 단순 불확실의 구분; 압축·multipart·본문 제한의 관측 경계 문서화. 이번 평가에서는 수정하지 않는다.\n']
    write('06_error_analysis.md','\n'.join(lines))
    lines=['# 최종 평가 및 코드 동결 판단\n','이 결과는 **코드 동결 후 생성한 신규 합성 홀드아웃 평가**이며 외부 독립 평가나 실제 서비스 정확도 측정이 아니다. 동일 작성자가 지원 범위를 아는 상태에서 사례와 정답을 작성했다. 100개 중 80개 정답 확정, 20개 불확정; 세 조건 각3회, 총900회.\n',
           '| 조건 | 기존 고정38 TP/FP/FN/TN/AB | 기존 개발 평가가능60 TP/FP/FN/TN/AB | 신규 평가가능80 TP/FP/FN/TN/AB/ERROR |','|---|---|---|---|']
    for mode,c in comparison.items():
        f=c['fixed38']['metrics'];d=c['development72']['metrics'];h=c['holdout']
        values=lambda x:'/'.join(str(x[k]) for k in ('TP','FP','FN','TN','ABSTAIN'))
        lines.append(f"| {mode} | {values(f)} | {values(d)} | {values(h)}/{h['ERROR']} |")
    lines+=['\n기존72 중12개는 EXCLUDED이며 신규100 중20개는 불확정이다. 구성과 취약 비율이 다르므로 accuracy·coverage 수치 차이를 인과 효과로 해석하지 않는다. 신규 FP/FN과 ABSTAIN은 실제 관측 한계를 드러내며, 기존 개발 세트에서 좋은 조건부 수치만으로 일반화를 보장할 수 없다. 개발 세트 과적합 가능성을 이번 내부 합성 평가만으로 배제할 수 없으며 별도 블라인드 외부 평가가 필요하다.\n',
            '정책 효과는 policy_transitions.json과 metrics.json의 맥락 필요 여부별 집계로 확인한다. 정책 제공은 일부 FP/ABSTAIN을 해소할 수 있으나 표현하지 못하는 서비스 의미와 불완전 본문을 해결하지 않는다. 정책에 정답/ID 조건을 넣지 않았다.\n',
            '코드 동결은 유지한다. 이번 평가의 실패를 수정으로 숨기지 않는다. 광범위한 안전 보증·실서비스 100% 정확도·외부 독립성은 주장하지 않는다. 알려진 한계가 있는 제한된 증거 기반 진단 도구로만 해석해야 한다. 발견된 이슈는 06 문서에 후속 작업으로 기록했다.\n',
            '외부 도구 비교 준비: 동결 소스, 실행 옵션, fixture/정답/정책, raw HTTP, 메모리·시간 및 지표 계산은 재현 가능하게 보존했다. 그러나 실제 외부 도구 실행·버전 고정·검사 의미 정합·사전 승인된 비교 대상 선정과 독립 검토는 아직 수행하지 않았다. 비교 우열이나 결과는 없다. Linux/Docker/CVE·브라우저 exploit·TLS enforcement·서버-side 권한 우회/IDOR는 본 평가 범위가 아니다.\n',
            '증거: source_hashes.json, historical_hashes.json, preregistration.json, cases.json, policies/, 04_raw_results/, metrics.json, anomalies.json, comparison.json, integrity.json. 재현 명령은 동일 환경에서 `python docs/validation/final_holdout/run.py run` 및 `python docs/validation/final_holdout/analyze.py analyze`이며 기존 결과를 덮어쓰지 않으므로 별도 빈 복사본을 사용한다.\n']
    write('07_final_assessment.md','\n'.join(lines))
    # Verify every protected historical artifact and source after all evaluation work.
    manifest=read(OUT/'historical_hashes.json')
    with ThreadPoolExecutor(max_workers=8) as pool:
        changed=[rel for rel,actual in pool.map(lambda rel:(rel,sha(ROOT/rel)),manifest) if actual!=manifest[rel]]
    assert not changed,changed
    run.check_code();run.verify_inputs()
    save('integrity.json',dict(historical_files_checked=len(manifest),changed_historical=[],code_unchanged=True,
        inputs_unchanged=True,raw_rows=len(rows),unique_trials=900,raw_metrics_recomputed=True,
        known_cases_excluded_after_results=0,truth_corrections=0,
        raw_hashes={str(p.relative_to(OUT)):sha(p) for p in sorted((OUT/'04_raw_results').rglob('*')) if p.is_file()}))
    print(json.dumps({mode:s['metrics'] for mode,s in summaries.items()},indent=2))


if __name__=='__main__':{'design':design_docs,'analyze':analyze}[sys.argv[1]]()
