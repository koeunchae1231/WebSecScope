"""Independent arithmetic/raw-record audit; does not alter the frozen evaluator."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    registration=read(OUT/'preregistration.json')
    for rel,digest in registration['input_hashes'].items():assert sha(OUT/rel)==digest,rel
    for rel,digest in read(OUT/'source_hashes.json').items():
        assert sha(ROOT/rel)==sha(OUT/'frozen_code'/rel)==digest,rel
    cases={c['id']:c for c in read(OUT/'cases.json')}
    rows=[read(p) for p in (OUT/'04_raw_results').glob('*/*.json')]
    assert len(rows)==900
    summaries=read(OUT/'metrics.json')
    findings_audited=0;policy_bindings=0
    for row in rows:
        case=cases[row['case_id']]
        assert row['truth']==case['truth'] and row['expected']==case['expected']
        if row.get('scan'):
            findings=row['scan']['all_findings']
            selected=[f for f in findings if any(f['check_id'].startswith(prefix) for prefix in case['selector'])]
            assert selected==row['selected'],row['case_id']
            actual='ERROR' if not selected else 'FAIL' if any(f['status']=='FAIL' for f in selected) else 'WARNING' if any(f['status']=='WARNING' for f in selected) else 'PASS'
            assert actual==row['status']
            findings_audited+=len(findings)
            ledger=row['scan']['score_details']
            assert ledger['score']==100-sum(e['final_penalty'] for e in ledger['entries'])
        assert row['http_requests']==len(row['http_events'])
        assert row['logical_requests']==len(row['requests'])
        assert not row.get('denied_connections')
        for q in row['requests']:
            assert q['url'].startswith('http://127.0.0.1:')
            assert q['method'] in ('HEAD','GET')
            body=q.get('body_evidence')
            if body:assert body['sample_bytes']<=16384
        if row.get('policy'):
            template=read(OUT/'policies'/f"{row['case_id']}-{row['mode']}.json")
            assert row['policy']==dict(template,target_origin=row['target'])
            digest=hashlib.sha256(json.dumps(row['policy'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
            assert row['policy_sha256']==digest
            assert not ({'id','case_id','truth','expected'} & row['policy'].keys())
            policy_bindings+=1
        if row.get('rss_after'):assert row['rss_after']['peak_bytes']>=row['rss_after']['current_bytes']
    for mode in ('none','p1','headers'):
        first=[r for r in rows if r['mode']==mode and r['repeat']==1]
        assert len(first)==100
        known=[r for r in first if r['truth']!='unknown']
        v=[r for r in known if r['truth']=='vulnerable'];s=[r for r in known if r['truth']=='safe']
        assert len(known)==80 and len(v)==len(s)==40
        tp=sum(r['status']=='FAIL' for r in v);fp=sum(r['status']=='FAIL' for r in s)
        fn=sum(r['status']=='PASS' for r in v);tn=sum(r['status']=='PASS' for r in s)
        abstain=sum(r['status']=='WARNING' for r in known);error=sum(r['status']=='ERROR' for r in known)
        m=summaries[mode]['metrics']
        assert (tp,fp,fn,tn,abstain,error)==tuple(m[k] for k in ('TP','FP','FN','TN','ABSTAIN','ERROR'))
        assert tp+fp+fn+tn+abstain+error==80
        arithmetic=dict(precision=(tp,tp+fp),recall=(tp,tp+fn),f1=(2*tp,2*tp+fp+fn),accuracy=(tp+tn,tp+fp+fn+tn),
                        coverage=(tp+fp+fn+tn,80),conservative_accuracy=(tp+tn,80),vulnerable_detection=(tp,40),safe_correctness=(tn,40))
        for name,(n,d) in arithmetic.items():
            assert m[name] is None if not d else math.isclose(m[name],n/d),name
        group=[r for r in rows if r['mode']==mode]
        assert summaries[mode]['http_requests']==sum(len(r['http_events']) for r in group)
        assert summaries[mode]['request_timeout_observations']==sum('timeout' in (q['error'] or '').lower() for r in group for q in r['requests'])
        for repeat in (1,2,3):assert len([r for r in group if r['repeat']==repeat])==100
    result=dict(raw_trials=900,case_denominators_verified=True,independent_arithmetic_matched=True,
                findings_audited=findings_audited,policy_bindings_verified=policy_bindings,
                body_cap_verified=True,external_connections=0,code_and_inputs_unchanged=True)
    p=OUT/'verification.json';assert not p.exists()
    p.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
